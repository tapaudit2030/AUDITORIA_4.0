# Encargos

Aquí se crea una carpeta por cliente y ejercicio (`/nuevo-encargo`). **Nada de lo
que está aquí se sube a GitHub** (ver `.gitignore`): es información confidencial
del cliente. Para trabajar en equipo sobre un mismo encargo, sincronice la carpeta
por OneDrive/SharePoint o compártala por el canal que defina la firma.
