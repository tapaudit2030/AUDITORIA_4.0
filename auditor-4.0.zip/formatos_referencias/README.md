# Formatos de referencia

Modelos propios de cada firma que AUDITOR_4.0 usa como base (nunca los sobrescribe):
programas de auditoría, carta de encargo, memorando de planificación, carta de
control interno, carta de representación, informe del auditor, papeles modelo.

- `thepoweraudit/` — modelos de ThePowerAudit S.A.
- `globalauditors/` — modelos de GLOBALAUDITORS CÍA. LTDA.
- `comunes/` — modelos que usan ambas firmas.

Nombre sugerido: `<tipo>_<descripcion>.docx|xlsx`, p. ej. `carta_encargo.docx`,
`carta_representacion.docx`, `informe_auditor_sin_salvedades.docx`,
`programa_inventarios.xlsx`. Si falta un modelo, el agente lo pide; no lo inventa.
