# Modelos comunes a ambas firmas
