# Modelos de thepoweraudit

Coloque aquí los modelos Word/Excel de la firma: carta de encargo, carta de representación, informe del auditor, carta de control interno, memorando de planificación, programas de auditoría.
AUDITOR_4.0 los usa como base y nunca los sobrescribe.
