# Formato de los papeles de trabajo (ambas firmas)

Tomado de los papeles modelo de la firma (A-1 Balance General, A-4 Mayores,
B-1 Estado de Resultados mensualizado, B-2 acumulado y P-01 Determinación de la
Materialidad). **Las dos firmas usan el mismo formato**; solo cambian la
tipografía, el logotipo y los colores.

| | GLOBALAUDITORS CÍA. LTDA. | ThePowerAudit S.A. |
|---|---|---|
| Tipografía | Open Sans | Arial Rounded MT Bold |
| Tamaño | Títulos 12 · resto 10 | Títulos 12 · resto 10 |
| Color principal | Azul `#0E2C59` (manual de marca) | Negro `#231F20` (logotipo) |
| Color de acento | Dorado `#FFB600` (manual de marca) | Ámbar `#F8B617` (logotipo) |
| Logotipo | `firmas/globalauditors/logo.png` | `firmas/thepoweraudit/logo.png` |

Los colores de ThePowerAudit se tomaron del logotipo oficial porque el manual
de marca llegó incompleto; confirmar con el manual.

## Anatomía del papel en Excel

1. **Logotipo** arriba a la izquierda (filas 1 a 6).
2. **Sello** arriba a la derecha, recuadro gris: Ref. · Elaborado por · Fecha de
   elaboración · Actualizado por · Revisado por · Aprobado por.
3. Desde la fila 8: **razón social del cliente** (título, negrita, color principal),
   **nombre del papel** (título), **fecha de corte** (negrita), *( Expresado en U.S.
   dólares )* en cursiva, y el marco contable; filete inferior.
4. Secciones en cursiva negrita del color principal: Objetivo → Procedimiento →
   Análisis → Marcas → Referencia → Observaciones → Conclusión.
5. **Encabezados de tabla**: relleno de acento con texto del color principal en
   negrita. Columnas **Ref.** y celdas de resultado: relleno del color principal
   con texto de acento.
6. Sin líneas de cuadrícula; impresión horizontal ajustada al ancho de la página.
7. Amarillo puro `#FFFF00` solo para celdas que completa el auditor.

## Índice de referencias de la firma

| Ref. | Papel |
|---|---|
| A-1 | Balance General comparativo (mensual) |
| A-4 | Mayores |
| B-1 | Estado de Resultados mensualizado |
| B-2 | Estado de Resultados acumulado |
| P-01 | Determinación de la materialidad (planificación) |
| P-01.1 | Materialidad — revisión con cifras interinas (preliminar) |
| P-01.2 | Materialidad — reevaluación con cifras finales (final) |

## Rangos de referencia de materialidad (P-01 de la firma)

Utilidad antes de participación e impuestos 3% al 10% · Ingresos ordinarios 0,5% al 2% ·
Total activos 1% al 3% · Activos corrientes 1% al 3% · Patrimonio 1% al 5%.
El porcentaje de cada cliente lo decide el auditor según el tipo de cliente.

## Word (cartas e informes)

Misma tipografía de la firma, títulos 12 y texto 10, logotipo en el encabezado,
colores de la firma solo en títulos y líneas. Sin PDF.
