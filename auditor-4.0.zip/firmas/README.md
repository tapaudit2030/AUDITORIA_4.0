# Identidad de las firmas

Cada carpeta contiene `firma.json` (nombre, RUC, paleta) y los logotipos.
Los generadores de papeles leen la firma desde `encargo.json` → `firma_id`.

| Firma | RUC | Logos |
|---|---|---|
| ThePowerAudit S.A. | 1793197900001 | `thepoweraudit/logo.png` |
| GLOBALAUDITORS CÍA. LTDA. | 1791771745001 | `globalauditors/logo.png` (fondo blanco, para Excel), `logo_transparente.png` (Word sobre fondo claro), `logo_blanco.png` (sobre fondo azul marino) |

La paleta de GLOBALAUDITORS está muestreada del logotipo oficial: azul `0D2C5A` y dorado `FFAD01`.
