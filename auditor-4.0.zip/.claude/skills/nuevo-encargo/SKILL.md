---
name: nuevo-encargo
description: Abre o retoma un encargo de auditoría en AUDITOR_4.0. Hace las preguntas bloqueantes (firma, cliente, tipo de cliente, marco NIIF completas o NIIF para las PYMES, ejercicio, materialidad, ciclos), crea la carpeta del encargo y su encargo.json. Usar SIEMPRE al empezar un cliente nuevo, al decir "nuevo encargo", "abre el encargo", "empecemos la auditoría de", o cuando no exista encargo.json.
---

# Apertura del encargo — AUDITOR_4.0

## 1. ¿Nuevo o existente?

Lista las carpetas de `encargos/`. Si el usuario nombra un cliente que ya tiene
carpeta, **retómalo**: lee su `encargo.json` y `avance.md`, resume en qué fase
está y qué queda pendiente, y no vuelvas a preguntar lo ya confirmado.

## 2. Preguntas bloqueantes (encargo nuevo)

Hazlas **agrupadas en una sola interacción** (usa la herramienta de preguntas si
está disponible). No construyas ningún papel antes de tenerlas.

1. **Firma que emite el informe**: ThePowerAudit S.A. (`thepoweraudit`) o
   GLOBALAUDITORS CÍA. LTDA. (`globalauditors`).
2. **Cliente**: razón social y RUC.
3. **Tipo de cliente**: servicios · comercial · industrial · otro (indicar:
   construcción, agrícola, inmobiliaria, financiero, cooperativa, emisor de
   valores, sin fines de lucro…). Pregunta también la actividad principal.
4. **Marco contable**: **NIIF completas** o **NIIF para las PYMES**. Nunca lo
   deduzcas. Ver `.claude/skills/motor-auditoria-nia/references/marco-contable.md`.
5. **Ejercicio** auditado, **fecha de corte interino** (visita preliminar) y si
   es **primera auditoría** (NIA 510 saldos de apertura) o **recurrente**.
6. **Materialidad de este cliente**: depende siempre del tipo de cliente, así
   que se pregunta **en cada encargo** y no hay % por defecto de la firma:
   base (activos, ingresos, utilidad antes de impuestos, patrimonio, gastos),
   % global, % de ejecución y % del umbral de errores claramente triviales.
   Puedes sugerir la base más habitual según el tipo (§4), pero los % los da
   el auditor. Lo que no se defina queda vacío y marcado
   `REQUIERE REVISIÓN DEL AUDITOR RESPONSABLE`.
7. **Ciclos y cuentas en alcance** (sugiere según el tipo de cliente, ver §4).
8. **Equipo**: socio, gerente, preparado / revisado / aprobado por.

## 3. Crear la carpeta y encargo.json

Prefijo: `<NOMBRE_CORTO_CLIENTE>_<EJERCICIO>` en mayúsculas, sin espacios.

```
encargos/<PREFIJO>/
├── encargo.json          ← desde plantillas/encargo.plantilla.json
├── avance.md             ← lista de avance de las tres fases (§5)
├── 00_Insumos_cliente/   ← copias de lo que entrega el cliente (nunca se editan)
├── 01_Planificacion/
├── 02_Preliminar/
└── 03_Final/
```

Escribe en `encargo.json` solo lo confirmado. `firma` toma el nombre de
`firmas/<firma_id>/firma.json`. Lo que falte queda `PENDIENTE DE CONFIRMACIÓN`.

Para que los generadores de Python encuentren el encargo, ejecútalos con el
directorio de trabajo en la carpeta de la fase, y la variable
`ENCARGO_JSON=../encargo.json` (o copia `encargo.json` a esa carpeta).

## 4. Enfoque según el tipo de cliente

Sugiere el alcance y los riesgos significativos de partida; el auditor decide.

| Tipo | Ciclos que suelen ser clave | Riesgos típicos a evaluar |
|---|---|---|
| Servicios | Ingresos y CxC, nómina y beneficios, gastos, impuestos | Reconocimiento de ingresos (NIIF 15 / Sección 23), servicios en proceso, cortes, provisiones laborales (jubilación patronal y desahucio) |
| Comercial | Inventarios y costo de ventas, compras y CxP, ingresos y CxC, efectivo | Existencia y valuación de inventarios (VNR), cortes de compras y ventas, deterioro de cartera, descuentos y devoluciones |
| Industrial | Inventarios (MP, PP, PT), costos de producción, PPE, nómina, compras | Costeo y absorción de costos indirectos, obsolescencia, depreciación y deterioro de PPE, capitalización |
| Otro | Según actividad | Normativa sectorial específica: identifícala y márcala `PENDIENTE DE VERIFICACIÓN NORMATIVA` si no puedes confirmarla |

Rangos de referencia de la firma (formato P-01): utilidad antes de participación e
impuestos 3% al 10% · ingresos ordinarios 0,5% al 2% · total activos 1% al 3% · activos
corrientes 1% al 3% · patrimonio 1% al 5%. Muéstralos al preguntar; el % exacto lo decide
el auditor para cada cliente.

Base de materialidad que suele usarse (solo sugerencia; decide el auditor): servicios y
comerciales con utilidad estable → utilidad antes de impuestos o ingresos; comerciales con
márgenes bajos o pérdidas → ingresos; industriales intensivos en activos → total de activos;
entidades sin fines de lucro → gastos totales.

En todos: riesgo de fraude en ingresos y elusión de controles por la dirección
(NIA 240), partes relacionadas (NIA 550), cumplimiento tributario y laboral
(NIA 250), empresa en marcha (NIA 570).

## 5. avance.md

Crea la lista con las tareas de las tres fases (toma los índices de
`fase-planificacion`, `fase-preliminar` y `fase-final`), cada una con estado
`[ ]` pendiente, `[~]` en curso, `[x]` hecha o `[n/a]` con la razón.

## 6. Insumos

El cliente entrega **Excel, CSV, XML (comprobantes electrónicos del SRI), PDF**
y otros formatos. Guarda las copias en `00_Insumos_cliente/` y conviértelas a
CSV de trabajo cuando haga falta; nunca edites el original. Pide los archivos según `.claude/skills/motor-auditoria-nia/references/carga-de-archivos.md`,
levanta el inventario de lo recibido y lo que falta, y ejecuta las
validaciones de balances del `motor-auditoria-nia` (Paso 3) antes de construir.
Luego sigue con `/fase-planificacion`.
