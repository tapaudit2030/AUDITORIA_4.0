---
name: fase-planificacion
description: Fase 1 de AUDITOR_4.0 — Planificación de la auditoría de estados financieros bajo NIA. Aceptación e independencia, carta de encargo, conocimiento de la entidad, materialidad, revisión analítica, riesgos de error material y de fraude, control interno COSO, estrategia global, memorando de planificación y programas por ciclo. Usar cuando se pida "planificación", "planificar la auditoría", "memorando de planificación", "matriz de riesgos", "estrategia de auditoría" o "programas de auditoría".
---

# Fase 1 — Planificación

Requisito: `encargo.json` con firma, tipo de cliente y marco confirmados. Si
falta, ejecuta primero `nuevo-encargo`. Los papeles van en
`encargos/<PREFIJO>/01_Planificacion/`.

## Índice de papeles de la fase

| Ref. | Papel | NIA | Cómo se produce |
|---|---|---|---|
| PL-01 | Aceptación / continuidad del cliente e independencia del equipo | 220, NICC 1 / NIGC 1, 300 | Cuestionario en Excel (`papeles-trabajo-nia`); declaraciones de independencia por miembro del equipo |
| PL-02 | Carta de encargo (borrador) | 210 | Word sobre el modelo de la firma. Modelo en `formatos_referencias/<firma_id>/`; si no está, pídelo y no lo inventes |
| PL-03 | Conocimiento de la entidad y su entorno | 315 (Revisada 2019) | Memorando: actividad, tipo de cliente, estructura, marco contable, regulación sectorial, tributaria y laboral, sistemas de información, partes relacionadas |
| P-01 | **Materialidad de planificación**: global, de ejecución y umbral de trivialidad, con la base y los % que el auditor definió para **este** cliente según su tipo | 320, 450 | `auditoria-preliminar-nia` → `build_materialidad.py`. Nunca uses % por defecto: si no están en `encargo.json`, pregúntalos |
| A-1/B-1/B-2 | Estados comparativos | 520 | `auditoria-preliminar-nia` → `build_comparativos*.py` |
| RA-01 | Revisión analítica preliminar e indicadores | 520, 315 | `auditoria-preliminar-nia` → `build_analitica.py` |
| PL-04 | Riesgo de fraude: indagaciones, sesión de equipo, presunciones | 240 | Excel; incluye la presunción de fraude en ingresos y la elusión de controles |
| PL-05 | Cumplimiento de leyes: tributario, laboral, societario | 250 | Lista de obligaciones (SRI, IESS, MDT, Supercias) con la evidencia a pedir. Ningún plazo ni tarifa de memoria |
| PL-06 | Partes relacionadas | 550 | Listado y transacciones a revisar |
| PL-07 | Empresa en marcha — evaluación preliminar | 570 | Indicadores financieros y operativos desde RA-01 |
| CI-00 | Control interno COSO 2013 y matriz de riesgos y controles | 315, 265 | `revision-control-interno-coso` |
| NAR / REC | **Narrativas y pruebas de recorrido** por proceso (una transacción de punta a punta por proceso significativo, con su evidencia: documento, registro, aprobación) para confirmar el diseño e implementación de los controles | 315 | `auditoria-preliminar-nia` → `build_narrativas.py`; el recorrido se documenta con la evidencia real entregada por el cliente |
| PL-08 | Matriz de riesgos de error material por aseveración | 315, 330 | Excel: riesgo inherente × control → riesgo de error material **por fórmula** (matriz 3×3); riesgos significativos señalados |
| PL-09 | Uso del trabajo de expertos / auditoría interna / saldos de apertura | 620, 610, 510 | Solo si aplica; si no, `n/a` con la razón |
| PL-10 | Estrategia global y plan de auditoría | 300 | Memorando: alcance, calendario de visitas (preliminar y final), equipo, horas, áreas de enfoque |
| PL-11 | Programas de auditoría por ciclo | 330 | Un programa por ciclo en alcance, con procedimientos que respondan a cada riesgo de PL-08 y su referencia al papel |
| PL-12 | Memorando de planificación | 300 | Word con la identidad de la firma; resume PL-03 a PL-11 para aprobación del socio |

## Cómo trabajar

1. Lee `encargo.json` y `avance.md`. Marca en `avance.md` lo que empiezas.
2. Valida los balances (`motor-auditoria-nia`, Paso 3) antes de cualquier cifra.
3. Construye P-01, comparativos y RA-01 con los generadores; luego PL-04 a PL-07,
   CI-00 y las **pruebas de recorrido** (NAR/REC) antes de la matriz PL-08: el
   riesgo de control de PL-08 sale de lo que el recorrido confirmó, no de lo que
   dicen los manuales.
4. El enfoque de PL-08 y PL-11 parte del **tipo de cliente** (tabla de
   `nuevo-encargo` §4) y de los hallazgos reales de RA-01, no de una lista genérica.
5. Todo papel va con la identidad de la firma del encargo (`firma_id`):
   GLOBALAUDITORS → aplica `entregables-globalauditors`; ThePowerAudit → formato de
   `firma.py` con `firmas/thepoweraudit/`.
6. Antes de cerrar la fase, pide al subagente `revisor-calidad` que revise la
   carpeta `01_Planificacion`.

## Cierre de la fase

Informa: materialidad determinada (con cifras y base), riesgos significativos
identificados por aseveración, deficiencias de diseño de control detectadas,
lo que falta del cliente y las decisiones para el socio (aprobación de
materialidad, estrategia y memorando). La fase se cierra cuando el socio aprueba
el memorando; regístralo en `avance.md` con la fecha que indique el usuario.
