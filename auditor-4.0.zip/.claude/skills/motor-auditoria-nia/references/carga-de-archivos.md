# Carga de archivos — qué pedir y cómo subirlo

## Regla previa

Al recibir los archivos, **levanta primero el inventario de lo recibido y de lo
que falta**, antes de construir nada. Lo que falte se marca
`PENDIENTE DE INFORMACIÓN DEL CLIENTE` con el efecto de no obtenerlo. Una prueba
sin su evidencia no está ejecutada.

## Archivos por tipo de trabajo

### Auditoría preliminar / planificación

| Archivo | Para qué se usa | ¿Indispensable? |
|---|---|---|
| Balance de comprobación de **cada mes** del ejercicio, hasta el corte | Comparativos mensuales A-1 y B-2, sumarias, analítica | Sí |
| Balance de comprobación de **diciembre del ejercicio anterior** | Comparativo anual y saldos de apertura (NIA 510) | Sí |
| Estados financieros y dictamen del ejercicio anterior | Cifras auditadas comparativas | Sí |
| Papeles del archivo del ejercicio anterior | Formatos, referencias y bancos de preguntas, riesgos y controles | Recomendable |
| Mayores contables | Pruebas de detalle y muestreo | Según alcance |
| Catálogo de cuentas | Verificación del catálogo y de la clasificación | Recomendable |

### Por área

- **Inventarios** — mayor de inventarios, mayor del grupo de costos, kardex por
  producto y bodega, reporte de existencias al corte, acta e instrucciones de la
  toma física, hojas de conteo firmadas por ubicación, compras y ventas
  posteriores al cierre.
- **Efectivo** — estados de cuenta bancarios, conciliaciones bancarias, actas de
  arqueo, reportes de cierre de caja diarios, confirmaciones bancarias.
- **Gastos** — mayores de gasto, XML de comprobantes electrónicos recibidos,
  módulo de compras.
- **Tributario (K-3)** — Formularios 103 y 104 del período, ATS, mayores de IVA
  y retenciones.
- **Control interno** — organigrama, manuales de funciones y de procedimientos,
  políticas contables, flujogramas, reportes de los sistemas.

## Formato

- **Datos** en `.xlsx` o `.csv` **tabulares**: encabezados en la primera fila,
  sin celdas combinadas, sin subtotales incrustados, una fila por registro.
- **Documentos** en PDF.
- Nombrado sugerido: `AAAA_Cliente_TipoDocumento_Periodo`, por ejemplo
  `2026_ACME_BalanceComprobacion_JULIO.xls`.
- Un archivo por período. No consolides meses en una sola hoja antes de
  entregarlos: el encadenamiento mensual se valida archivo contra archivo.

## Cómo subirlos

### Los `.xls` binarios van adjuntos al chat

Los `.xls` antiguos (OLE2) que exportan la mayoría de los ERP ecuatorianos
**no se leen correctamente a través del conector de Microsoft 365 / SharePoint /
OneDrive**: el contenido llega como texto desordenado, con los valores separados
de los códigos de cuenta, y cualquier cifra extraída de ahí sería inventada.

Para esos archivos: **adjúntalos directamente al chat**. Antes de parsearlos
instala el lector:

```bash
pip install xlrd --break-system-packages
```

### Lo que sí sirve por conector

Los `.xlsx`, `.csv` y los PDF **sí** se leen bien a través del conector. Úsalo
para revisar los papeles del archivo anterior, extraer cuestionarios, leer
políticas contables, manuales y organigramas. Es la vía natural cuando el
cliente comparte una carpeta.

### Carpeta local

Si la sesión está vinculada al computador del auditor, trabaja los archivos
donde están, en la carpeta conectada, y deja los entregables junto a sus
fuentes. **Nunca modifiques los archivos originales del cliente**: los papeles
son archivos nuevos.

## Formato del balance de comprobación del ERP

Disposición habitual en los ERP ecuatorianos — **verifícala en cada cliente, no
la asumas**:

- columna 1 = código de cuenta · columna 5 = nombre · columna 8 = saldo anterior
  · columna 9 = débito · columna 10 = crédito · columna 13 = saldo actual
- el encabezado trae `MES DE : <MES> <AÑO>`
- los códigos son jerárquicos con puntos (`1.1.4.30.`); el nivel es el número de
  puntos

Filtra las filas cuyo código coincida con `^\d(\.\d+)*\.?$` para descartar los
encabezados repetidos de página.

## Validaciones antes de construir

Ejecútalas siempre y **reporta el resultado al usuario**:

1. **Identidad aritmética** por cuenta: `saldo anterior + débito − crédito − saldo actual ≈ 0`.
2. **Encadenamiento mensual**: el saldo actual del mes N debe igualar el saldo
   anterior del mes N+1.
3. **Cuadre del balance**: la suma de **todos** los grupos de nivel 1 debe ser
   cero. Recorre los grupos que existan — es frecuente un **grupo 7** (impuesto a
   la renta y participación de trabajadores) que aparece solo en diciembre. Si
   omites un grupo, el balance no cuadra.
4. **Enero puede abrir en cero**: muchos ERP presentan el balance de enero con
   saldo anterior 0 en todas las cuentas, incluidas las de balance. En ese caso
   los archivos del ejercicio **no contienen los saldos al 31 de diciembre
   anterior**: pide el balance de diciembre del año anterior y dilo
   explícitamente. **No derives el saldo de apertura.**

Y una regla de construcción: el **catálogo cambia entre meses**. Constrúyelo
como **unión de todos los períodos** y deriva los bloques de los datos, nunca de
una lista escrita a mano. Una cuenta olvidada rompe la completitud y el control
de completitud es el único que la detecta.
