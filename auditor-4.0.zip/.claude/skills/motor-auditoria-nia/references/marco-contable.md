# El marco contable — la pregunta que no se deduce

## Por qué es bloqueante

El marco de información financiera decide **qué norma se cita como criterio** en
cada hallazgo, y el criterio es lo que convierte una observación en un hallazgo
de auditoría. Citar la norma del otro marco invalida el criterio: el papel deja
de sostener la conclusión aunque la cifra esté bien calculada.

**Nunca lo deduzcas** del tamaño de la entidad, del catálogo de cuentas, del
sector ni de los papeles del ejercicio anterior. Los papeles del año anterior
son precisamente donde suele estar el error: un papel de activos fijos que cita
NIC 16 en una entidad que aplica NIIF para las PYMES es un hallazgo, no una
fuente.

Pregunta expresamente: **¿los estados financieros se preparan bajo NIIF para las
PYMES o bajo NIIF completas?** Pregunta además **qué edición** de la NIIF para
las PYMES aplica la entidad y desde qué ejercicio.

## Si el usuario no responde

No elijas por él. Marca `PENDIENTE DE CONFIRMACIÓN`, **cita de forma dual** —
«Sección 13 de la NIIF para las PYMES o NIC 2, según el marco que confirme la
administración»— y deja el asunto abierto en el papel de hallazgos. Si la
entidad está en conversión entre marcos, documéntalo como
`REQUIERE REVISIÓN DEL AUDITOR RESPONSABLE`.

## Tabla de equivalencias por cuenta

Es la tabla que se usa para llenar la sección «Normativa aplicada» de cada
papel. Verifica la vigencia de la edición antes de citar.

| Cuenta / asunto | NIIF para las PYMES | NIIF completas |
|---|---|---|
| Efectivo y equivalentes, estado de flujos | Sección 7 | NIC 7 |
| Instrumentos financieros básicos, cuentas por cobrar y por pagar | Sección 11 (y 12 para los demás) | NIIF 9 |
| Inventarios | Sección 13 | NIC 2 |
| Propiedades, planta y equipo | Sección 17 | NIC 16 |
| Arrendamientos | Sección 20 | NIIF 16 |
| Provisiones, pasivos y activos contingentes | Sección 21 | NIC 37 |
| Ingresos de actividades ordinarias | Sección 23 | NIIF 15 |
| Deterioro del valor de los activos | Sección 27 | NIC 36 |
| Beneficios a los empleados | Sección 28 | NIC 19 |
| Impuesto a las ganancias | Sección 29 | NIC 12 |
| Partes relacionadas | Sección 33 | NIC 24 |
| Propiedades de inversión | Sección 16 | NIC 40 |
| Activos intangibles distintos de la plusvalía | Sección 18 | NIC 38 |
| Hechos posteriores al período sobre el que se informa | Sección 32 | NIC 10 |
| Políticas contables, cambios y errores | Sección 10 | NIC 8 |
| Presentación de estados financieros | Secciones 3 a 8 | NIC 1 |

## Dónde cambia de verdad el tratamiento

No basta con cambiar el número citado. Estos son los puntos en que el marco
altera el procedimiento de auditoría, no solo la referencia:

- **Deterioro.** El modelo de pérdida y su reversión, y el nivel al que se
  evalúa, difieren entre marcos. Revisa la política de la entidad contra el
  marco confirmado antes de concluir sobre la provisión.
- **Instrumentos financieros.** El modelo de pérdida crediticia de NIIF 9 no es
  el de la Sección 11. La prueba de la provisión de cuentas por cobrar cambia en
  consecuencia.
- **Arrendamientos.** El reconocimiento del activo por derecho de uso bajo NIIF
  16 no tiene equivalente directo en la Sección 20, que mantiene la distinción
  operativo / financiero. Afecta a activos, pasivos y a los indicadores de la
  revisión analítica.
- **Ingresos.** El modelo de cinco pasos de NIIF 15 no es el de la Sección 23.
  Cambia la prueba de corte y de reconocimiento.
- **Impuesto diferido.** El alcance y las excepciones difieren; verifica cuál
  aplica antes de evaluar la conciliación tributaria.
- **Revelaciones.** La NIIF para las PYMES exige un juego reducido. No plantees
  como hallazgo la ausencia de una revelación que el marco aplicable no exige.

## Registro de la respuesta

Escribe la respuesta en `encargo.json`, campo `marco`, con el texto exacto
`"NIIF para las PYMES"` o `"NIIF completas"`. Los generadores lo imprimen en el
encabezado de cada papel y lo usan para la sección de normativa. Si queda en
`PENDIENTE DE CONFIRMACIÓN`, los papeles salen marcados y eso es lo correcto:
es visible y obliga a resolverlo antes de cerrar el legajo.
