# Formato del papel de trabajo

Especificación común a todos los papeles del motor. Los generadores de
`skills/auditoria-preliminar-nia/scripts/` ya la implementan (módulo
`firma.py`); este documento es la referencia cuando construyas un papel nuevo a
mano o con otra skill.

## Anatomía de la hoja

**Encabezado** — logotipo arriba a la izquierda; nombre de la firma; y la
**referencia del papel arriba a la derecha**, sobre banda de marca. Debajo,
cuatro líneas:

```
<Cliente>
<Nombre del papel>
Al <día> de <mes> de <año>
( Expresado en U.S. dólares )
```

Luego el bloque **Preparado por / Revisado por / Aprobado por**, cada uno con su
fecha. Estos datos salen de `encargo.json`; no se digitan en el código.

**Secciones, en este orden exacto:**

```
Objetivo → Procedimiento → Análisis → Marcas → Referencia → Observaciones → Conclusión
```

**Sección «Normativa de auditoría aplicada»** — obligatoria en todo papel. Lleva
las NIA que lo sustentan **con su título completo** (ver
`catalogo-nia.md`), la norma contable del marco confirmado en la apertura, y la
fuente del dato.

**Conclusión** — cierra con una de las cinco: SATISFACTORIA · SATISFACTORIA CON
EXCEPCIONES · NO SATISFACTORIA · LIMITACIÓN AL ALCANCE · PENDIENTE DE EJECUCIÓN.

## Paleta

Los colores se muestrean del logotipo de la firma y viven en `firma.py`:

| Uso | Color |
|---|---|
| Bandas de título y encabezados de columna | negro de marca, texto blanco, filete inferior ámbar |
| Subtotales | ámbar claro |
| Subencabezados | ámbar muy claro |
| Alertas | salmón claro |

## Código de colores de celda — no negociable

| Color de fuente / relleno | Significado |
|---|---|
| **Azul** `#0000FF` | Dato tomado del cliente. No se modifica. |
| **Negro** | Fórmula del propio libro. |
| **Verde** `#008000` | Enlace a otra hoja o a otro libro. |
| **Relleno amarillo puro** `#FFFF00` | Celda que debe completar el auditor, o supuesto de juicio. |

El **amarillo puro está reservado** a las celdas a completar. Nunca se usa como
color de marca, por parecido que sea al ámbar corporativo. **El legajo no se
cierra con celdas amarillas vacías.**

## Celdas parametrizadas

Toda columna de criterio lleva lista desplegable. Las listas estándar están en
`firma.py`:

| Columna | Lista |
|---|---|
| Probabilidad · Impacto · Riesgo inherente | `ALTO, MEDIO, BAJO` |
| ¿Aplica? · ¿Diseño adecuado? · ¿Implementado? | `SÍ, NO, N/A` |
| Marca de auditoría | `√, ∑, ©, ®, ©E, Φ, a, r, ≠, N/A, P/I` |
| Enfoque | `Sustantivo, Sustantivo ampliado, Confianza en controles, No aplica` |

## El nivel de riesgo nunca se escribe

Es **fórmula** sobre la matriz 3×3: ALTO = 3, MEDIO = 2, BAJO = 1; el producto
probabilidad × impacto se clasifica **≥ 6 → ALTO**, **3–4 → MEDIO**,
**1–2 → BAJO**. Si falta cualquiera de los dos factores, la celda queda vacía,
no en BAJO. Añade semáforo con formato condicional.

Implementación en `firma.py`: `formula_nivel_riesgo(col_prob, col_imp, fila)`.

## Controles que debe llevar cada papel

1. **Cuadre** — total calculado menos saldo del cliente = 0.
2. **Completitud** — total del papel contra la **cuenta de control del grupo** en
   el catálogo, **nunca contra la misma suma que construiste**. Es el único
   control que detecta una cuenta olvidada; en el desarrollo de este motor
   detectó tres.
3. **Suma de diferencias absolutas** de todas las filas = 0. Restringe el rango a
   las filas de datos: si abarca la fila de encabezado, `SUMPRODUCT(ABS(...))`
   devuelve `#VALUE!`.
4. **Selección y significatividad por fórmula** contra el error tolerable y la
   materialidad, no a ojo.

## Construcción en Excel

Usa `openpyxl` y sigue la skill `xlsx`. **Fórmulas reales, nunca resultados
pegados**: ningún saldo se digita.

**Evita** `XLOOKUP`, `FILTER`, `SORT`, `UNIQUE` y las fórmulas matriciales —
LibreOffice no las evalúa y el recálculo de verificación falla. Usa
`INDEX`/`MATCH`, `SUMIFS`, `SUMPRODUCT`, `IFERROR`. Para el máximo absoluto de un
rango sin matrices:

```
MAX(MAX(rango),-MIN(rango))
```

Después de cada construcción ejecuta `scripts/recalc.py` de la skill `xlsx` y
**no entregues nada mientras reporte `errors_found`**. Un recálculo limpio prueba
que las fórmulas evalúan, no que sean correctas: verifica además los valores de
los totales y de los cuadres.

### Detalles que rompen la construcción

- `freeze_panes` necesita una **cadena** (`"D31"`), no una celda fusionada.
- No reasignes un estilo leído de la propia celda (`celda.font = celda.font`):
  lanza `TypeError: unhashable type: 'StyleProxy'`.
- Escribe solo el **ancla superior izquierda** de un rango fusionado.
- Los nombres de hoja no pasan de **31 caracteres**.
- Configuración de impresión: `fitToWidth=1` y `fitToHeight=0`.
