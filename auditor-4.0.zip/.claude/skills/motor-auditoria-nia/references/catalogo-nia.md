# Catálogo de NIA citadas en los papeles

Cada papel de trabajo lleva una sección **«Normativa de auditoría aplicada»** en
la que la NIA se cita **con su número y su título completo**, nunca solo con el
número. Copia el título de esta tabla; no lo redactes de memoria.

La lista es la que el motor usa en los generadores
(`scripts/firma.py`, diccionario `NIA`). Si necesitas citar una NIA que no está
aquí, verifica su título y su vigencia para el ejercicio auditado antes de
escribirla, o márcala `PENDIENTE DE VERIFICACIÓN NORMATIVA`.

| NIA | Título |
|---|---|
| 200 | Objetivos globales del auditor independiente y realización de la auditoría de conformidad con las NIA |
| 210 | Acuerdo de los términos del encargo de auditoría |
| 220 | Gestión de la calidad de una auditoría de estados financieros |
| 230 | Documentación de auditoría |
| 240 | Responsabilidades del auditor en la auditoría de estados financieros con respecto al fraude |
| 250 | Consideración de las disposiciones legales y reglamentarias en la auditoría de estados financieros |
| 260 | Comunicación con los responsables del gobierno de la entidad |
| 265 | Comunicación de las deficiencias en el control interno a los responsables del gobierno y a la dirección |
| 300 | Planificación de la auditoría de estados financieros |
| 315 | Identificación y valoración de los riesgos de incorrección material |
| 320 | Importancia relativa o materialidad en la planificación y ejecución de la auditoría |
| 330 | Respuestas del auditor a los riesgos valorados |
| 402 | Consideraciones de auditoría relativas a una entidad que utiliza una organización de servicios |
| 450 | Evaluación de las incorrecciones identificadas durante la realización de la auditoría |
| 500 | Evidencia de auditoría |
| 501 | Evidencia de auditoría — consideraciones específicas para determinadas áreas |
| 505 | Confirmaciones externas |
| 510 | Encargos iniciales de auditoría — saldos de apertura |
| 520 | Procedimientos analíticos |
| 530 | Muestreo de auditoría |
| 540 | Auditoría de estimaciones contables y de la información relacionada a revelar |
| 550 | Partes vinculadas |
| 560 | Hechos posteriores al cierre |
| 570 | Empresa en funcionamiento |
| 580 | Manifestaciones escritas |
| 700 | Formación de la opinión y emisión del informe de auditoría sobre los estados financieros |

## Qué NIA sustenta qué papel

Orientación, no lista cerrada. La NIA que se cita es la que realmente sustenta
el procedimiento ejecutado en ese papel.

| Papel / trabajo | NIA que lo sustentan |
|---|---|
| Apertura y términos del encargo | 200 · 210 · 220 |
| Documentación y referenciación | 230 |
| Planificación y estrategia | 300 · 315 |
| Materialidad (P-01) | 320 · 450 |
| Comparativos y revisión analítica (A-1, B-1, B-2, RA-01) | 315 · 520 |
| Sumarias por ciclo | 315 · 330 · 500 |
| Narrativas, recorridos y matrices de riesgos y controles | 315 · 265 · 330 · 402 |
| Saldos de apertura / primer año de encargo | 510 |
| Pruebas de detalle y evidencia | 500 · 501 |
| Confirmaciones de bancos, clientes, proveedores, abogados | 505 |
| Muestreo | 530 |
| Estimaciones (deterioro, provisiones, VNR, vida útil) | 540 |
| Partes relacionadas | 550 |
| Hechos posteriores | 560 |
| Empresa en funcionamiento | 570 |
| Carta de manifestaciones | 580 |
| Fraude | 240 |
| Cumplimiento legal y tributario | 250 |
| Comunicación de hallazgos y deficiencias | 260 · 265 · 450 |
| Cierre y opinión (competencia del socio) | 700 |
