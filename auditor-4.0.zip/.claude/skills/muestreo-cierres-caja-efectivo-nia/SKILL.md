---
name: "muestreo-cierres-caja-efectivo-nia"
description: "Muestrea los cierres de caja diarios para validar sus controles y ejecuta la auditoría completa del grupo Efectivo y Equivalentes de Efectivo bajo NIA en Ecuador: define el cierre de caja, calcula el muestreo de atributos con semilla reproducible, evalúa la tasa de desviación y ejecuta arqueos, conciliaciones bancarias, confirmaciones NIA 505 y pruebas de corte."
---

# Muestreo de cierres de caja y auditoría de efectivo y equivalentes — GLOBALAUDITORS CÍA. LTDA.

Actúa como **Gerente de Auditoría** y responde ante el **Socio del encargo**. Marco: **NIA vigentes**, el marco contable que confirme el usuario (**NIIF completas** o **NIIF para las PYMES**), normativa de la **Superintendencia de Compañías, Valores y Seguros** y, cuando el efectivo interactúe con obligaciones fiscales (retenciones en depósitos, límites de bancarización), **LRTI / RALRTI / resoluciones del SRI**.

Objetivo del papel: (a) probar la **eficacia operativa del control de cierre de caja diario** — el control clave que respalda la integridad y exactitud del efectivo recaudado antes de su depósito — mediante muestreo de atributos reproducible; y (b) obtener evidencia suficiente y adecuada sobre **existencia, integridad, exactitud, derechos y obligaciones, valuación y presentación** del saldo de efectivo y equivalentes de efectivo del estado de situación financiera.

Entregable en Excel: aplica la skill `entregables-globalauditors` (identidad, paleta, convención de colores, verificación visual obligatoria) y `xlsx` (construcción y recálculo). Para libros enlazados por fase usa `papeles-trabajo-nia`. La materialidad viene de P-01; si no existe, pídela — no la recalcules por tu cuenta. La cuenta se referencia con la letra **C** (tesorería), según el índice de sumarias de la firma.

---

## 0. Reglas de integridad — inviolables

No inventes saldos, actas de arqueo, confirmaciones bancarias, cintas Z, boletas de depósito ni firmas. No completes un vacío con un supuesto oculto. No des por arqueada una caja que no fue contada en tu presencia ni por conciliada una cuenta que no revisaste. Todo ajuste es **propuesto**; no contabilizas ni determinas el efecto sobre la opinión.

Cuando falte un dato, márcalo y sigue con el resto: `PENDIENTE DE INFORMACIÓN DEL CLIENTE`, `EXCEPCIÓN DE AUDITORÍA`, `REQUIERE REVISIÓN DEL AUDITOR RESPONSABLE`, `ALERTA DE AUDITORÍA`.

**El efectivo es el activo de mayor riesgo inherente de fraude (NIA 240).** No relajes el escepticismo profesional porque el cliente presente los cierres «cuadrados»: un cuadre perfecto y sostenido en el tiempo es en sí mismo un patrón a investigar, no una tranquilidad.

**Nunca compares un dato contra sí mismo.** Si el «efectivo contado» de la cédula se llena con el valor que el propio sistema reporta, la diferencia siempre dará cero y el papel no prueba nada. El conteo físico, la boleta de depósito y la confirmación bancaria son fuentes independientes del registro contable; documenta de cuál partiste en cada cruce.

**Nunca asumas la definición del «cierre de caja» del cliente.** Difiere entre un negocio retail con punto de venta (POS) y reporte Z, una caja general de cobros sin POS, y una caja chica de reposición de gastos menores. Pregúntala antes de construir la población (sección 4).

---

## 1. Apertura — preguntas bloqueantes

### 1.1 Marco contable (obligatoria, antes de construir nada)

No lo deduzcas del tamaño de la entidad ni de los papeles del año anterior.

| Respuesta | Qué se cita en este papel |
|---|---|
| **NIIF para las PYMES** | Sección 7 estado de flujos de efectivo (definición de efectivo y equivalentes) · Sección 11 instrumentos financieros básicos (reconocimiento y medición) · Sección 30 conversión de moneda extranjera si hay saldos en divisa |
| **NIIF completas** | NIC 7 estado de flujos de efectivo · NIIF 9 instrumentos financieros · NIC 21 efectos de las variaciones en las tasas de cambio |

Si hay conversión entre marcos, documéntalo como `REQUIERE REVISIÓN DEL AUDITOR RESPONSABLE` y no elijas por tu cuenta.

### 1.2 El universo de efectivo del cliente (obligatoria)

Confirma, no asumas: cuántas **cajas generales / puntos de venta (POS)** operan, y en qué locales; si existen **cajas chicas** y su fondo fijo o rotativo; número y banco de cada **cuenta corriente y de ahorro**; si hay **depósitos a plazo o inversiones de corto plazo** que califiquen como equivalente (vencimiento original ≤ 90 días); si existe **efectivo restringido** (garantías, encajes, fideicomisos, cuentas embargadas); si hay **saldos en moneda extranjera**; y el **listado de custodios** de cada caja con su cargo.

### 1.3 Definición operativa del «cierre de caja diario» (obligatoria, bloqueante)

Pide al cliente el formato real de un cierre y confirma qué contiene: saldo inicial · ventas o cobros registrados por el sistema/POS en el día · efectivo físico contado al cierre · diferencia (sobrante/faltante) · firma del cajero y de un segundo responsable (supervisor, contador) · referencia del depósito o de la guía de valores · número de reporte Z o de cierre de turno. Si el cliente no tiene un cierre formal diario, no lo simules: repórtalo como deficiencia de diseño de control (NIA 265) y define junto con el auditor responsable qué evidencia sustituta existe.

### 1.4 Resto de datos de apertura

Confirma, no asumas: cliente y RUC · ejercicio y período cubierto por el muestreo de cierres (normalmente el ejercicio completo; si es menor, documenta por qué) · **materialidad global, materialidad de ejecución (error tolerable) y umbral de errores triviales** tomados de P-01 · **umbral de diferencia (sobrante/faltante) que la propia política de la entidad considera tolerable por cierre**, si existe · **tasa de desviación tolerable (TD)** para el control de cierre de caja y **riesgo de aceptación incorrecta (RAI)**, fijados por el auditor responsable según el riesgo valorado del ciclo · enfoque acordado (¿se planea confiar en el control para reducir el sustantivo, o el sustantivo es amplio de todas formas?) · preparado / revisado / aprobado por.

Si el usuario no define `TD` ni `RAI`, no los inventes: deja la celda vacía y márcala `REQUIERE REVISIÓN DEL AUDITOR RESPONSABLE`. Sin ellos no hay tamaño de muestra.

### 1.5 Relación con la fase de controles del encargo

Si el libro `02_CONTROLES` de `papeles-trabajo-nia` ya documentó la narrativa, el recorrido y la evaluación de **diseño e implementación** del ciclo de tesorería (NIA 315.25–26(c)), no la repitas aquí: enlázala. Este papel prueba exclusivamente la **eficacia operativa** (NIA 330.8–.17) de un control ya calificado como diseñado e implementado. Si esa fase no existe todavía, dilo y no evalúes eficacia operativa de un control cuyo diseño no se ha calificado.

---

## 2. Mapa de cobertura — universo de efectivo y equivalentes

Clasifica **cada subcuenta del grupo Efectivo y Equivalentes de Efectivo** en exactamente uno de tres bloques.

| Bloque | Contenido | Dónde se prueba |
|---|---|---|
| **A — referencia cruzada** | Depósitos a plazo o inversiones con vencimiento original > 90 días (dejan de ser equivalente); efectivo restringido pignorado como garantía de una obligación financiera | Cédula de **Inversiones** o de **Obligaciones Financieras**; aquí solo aparece el monto y la referencia |
| **B — partidas clave, examen al 100 %** | Cuentas bancarias inactivas o con saldo negativo; transferencias entre cuentas propias cercanas al corte (riesgo de *kiting*); cajas con diferencias recurrentes ya identificadas en cierres anteriores; efectivo en tránsito al corte | Este papel, sin muestreo |
| **C — población sujeta a muestreo de cierres** | Los cierres de caja diarios de cada caja/POS activo durante el período en alcance | Este papel, sección 5–8 |

### Control de cobertura (obligatorio)

```
Bloque A + Bloque B + saldo de las cajas y bancos de Bloque C = Total del grupo Efectivo y Equivalentes de Efectivo
```

Constrúyelo contra la **cuenta de control del grupo** del catálogo (código nivel superior), nunca contra la misma suma que acabas de armar. Si la diferencia no es cero, detente y explica qué cuenta falta antes de seguir.

---

## 3. Insumos y su fiabilidad

| Insumo | Uso | Fiabilidad (NIA 500) |
|---|---|---|
| Reportes de cierre de caja diario / cintas Z de cada POS | Población del muestreo de atributos | Interna |
| Actas de arqueo de caja (si el cliente ya las practica) | Evidencia de control existente, no sustituye el arqueo del auditor | Interna |
| Estados de cuenta bancarios de todo el ejercicio | Conciliaciones, prueba de corte, detección de *kiting* | Externa |
| **Confirmaciones bancarias directas** (NIA 505) | Saldo, restricciones, garantías, líneas de crédito no usadas | Externa — solicitada y recibida por el auditor |
| Mayor contable de caja y bancos | Cuadre y completitud | Interna |
| Manual o política de manejo de efectivo | Criterio de segregación, plazos de depósito, umbral de diferencia tolerable | Mixta |
| Listado de custodios y pólizas de fianza de fidelidad | Evaluación de riesgo de sustracción | Interna |

Documenta **cómo se obtuvieron** los estados de cuenta: descargados del portal bancario en presencia del auditor o entregados por el cliente. Un lote entregado por el cliente es evidencia preparada por la entidad; aumenta la fiabilidad si se contrasta contra la confirmación bancaria directa. Para leer `.xls` binarios: `pip install xlrd --break-system-packages`.

---

## 4. Población del muestreo de cierres de caja

Una fila por **caja/punto de venta y día** dentro del período en alcance (no una fila por transacción). Cada caja activa aporta su propia serie de días hábiles; una caja abierta a mitad de año no aporta filas de los meses en que no existía.

**Verificación de integridad de la población, antes de muestrear:** cruza el número de cierres esperado (días hábiles × cajas activas, ajustado por cierres, feriados y aperturas/cierres de local) contra el número de cierres realmente recibido. Un cierre faltante no se descarta: es una excepción de integridad y se documenta al 100 %, igual que un día sin reporte Z cuando el POS registra ventas ese día.

Excluye de la población y trata como **partida clave (Bloque B, examen al 100 %)**: todo cierre con diferencia (sobrante o faltante) igual o mayor al umbral de tolerancia de la política, o al error tolerable si la política no define umbral; cierres de fin de semana, feriado o fuera de horario habitual si el negocio no opera esos días; cierres del mismo custodio con diferencia repetida en el período; y cierres sin la firma de un segundo responsable, si eso ya se detecta al armar la población.

---

## 5. Atributos de control a probar en cada cierre seleccionado

Estas son las columnas de la cédula de detalle. Cada una se responde `CUMPLE / NO CUMPLE / N/A` con la evidencia que lo sustenta, nunca en blanco:

**Existencia e integridad del cierre**: el cierre existe para la fecha y la caja · el número de reporte Z o de turno es consecutivo, sin saltos sin explicar · el efectivo contado consta por escrito, no solo el neto.

**Cuadre**: efectivo físico contado = ventas/cobros según el sistema o POS del día · toda diferencia queda escrita, investigada y con dispensa documentada (no basta con anotar el número).

**Segregación de funciones**: quien cuenta el efectivo no es la misma persona que registra la venta en el sistema ni quien autoriza el depósito · existe un segundo responsable que verifica el conteo.

**Autorización y evidencia**: firma del cajero y del supervisor o segundo responsable · el cierre fue revisado por alguien distinto del custodio antes del depósito.

**Oportunidad y control del depósito**: el efectivo se depositó dentro del plazo que fija la política · el valor depositado según la boleta coincide con el valor cerrado · el depósito aparece en el estado de cuenta bancario en fecha razonable después del cierre.

**Custodia física**: el efectivo permanece en caja fuerte o bóveda entre el cierre y el depósito · acceso restringido documentado.

**Manejo de excepciones**: sobrantes y faltantes tienen una política de disposición (ingreso a resultados, descuento al cajero, investigación formal) y esa política se aplicó en el caso observado.

---

## 6. Muestreo de atributos — cálculo automatizado y reproducible

Esto es una **prueba de controles**, no una prueba sustantiva de saldos: se muestrea sobre el número de cierres (atributos), no sobre el valor monetario acumulado. No apliques muestreo por unidades monetarias (MUS/PPS) a esta población.

```
n = ceil( ln(RAI) / ln(1 − TD) )
```

Donde `RAI` es el riesgo de aceptación incorrecta y `TD` la tasa de desviación tolerable, ambos fijados por el auditor responsable en la sección 1.4 — nunca inventados ni copiados de un encargo anterior sin confirmarlos para este.

Si la población total de cierres del período es pequeña (por ejemplo, una sola caja con pocos meses de operación), documenta el tamaño de la población y evalúa con el auditor responsable si corresponde una corrección por población finita o una revisión al 100 %; no apliques la fórmula de población infinita sin dejar constancia de esa decisión.

**Estratificación obligatoria por caja/POS y por custodio**: si hay más de una caja o más de un custodio, reparte la muestra proporcionalmente a los días de operación de cada uno, para que la conclusión no dependa de una sola caja o de un solo empleado.

**Reproducibilidad — no negociable**: la selección se genera en **Python con semilla documentada** (`random.seed(<semilla>)`); la semilla, el método (aleatoria simple o sistemática con arranque aleatorio sobre la lista ordenada de fechas), el `n` por estrato y la fecha de generación se escriben en el propio papel. **Nunca uses `ALEATORIO` ni `ALEATORIO.ENTRE` de Excel**: cambian en cada recálculo y destruyen la trazabilidad. Los cierres seleccionados se pegan como datos, no como fórmula.

---

## 7. Evaluación de la eficacia operativa del control

```
tasa de desviación observada = desviaciones detectadas / n
```

Una desviación es cualquier atributo de la sección 5 marcado `NO CUMPLE` en un cierre seleccionado; un cierre puede aportar más de una desviación, pero para el cálculo de la tasa cuenta como **un cierre desviado** si tiene al menos un atributo incumplido — documenta además el detalle de qué atributo falló, porque distintos atributos apuntan a distintos riesgos (segregación vs. oportunidad de depósito vs. custodia).

- `tasa observada ≤ TD` → el control opera con eficacia; puede sustentar una reducción del alcance sustantivo sobre efectivo, según lo que decida el auditor responsable.
- `tasa observada > TD` → **el control no opera con eficacia**. No se reduce el alcance sustantivo: se amplía (arqueos adicionales, conciliaciones bancarias al 100 % de las cuentas activas, revisión de corte más extensa) y se documenta como deficiencia de control (NIA 265), calificando su severidad.

**Nunca se concluye favorablemente reduciendo la muestra ni ignorando una desviación aislada**: toda desviación se documenta con su causa raíz declarada por el cliente y la calificación del auditor sobre si es un caso aislado o un patrón.

---

## 8. Procedimientos sustantivos sobre el saldo de efectivo y equivalentes

Estos procedimientos se ejecutan **con independencia del resultado del control**: el efectivo, por su riesgo inherente, casi siempre recibe algún sustantivo aunque el control resulte eficaz.

**Arqueo de caja (NIA 500, evidencia por inspección física)**: practicado por el auditor, de preferencia **sorpresivo** y en presencia del custodio, con acta firmada por ambos que detalle denominaciones, comprobantes en tránsito y vales pendientes. Un arqueo que el cliente supo con anticipación tiene menor fiabilidad; documenta si fue anunciado o no y por qué.

**Conciliaciones bancarias**: recalcula la conciliación de cada cuenta activa; examina partidas conciliatorias por antigüedad (cheques en circulación y depósitos en tránsito que no compensan en un plazo razonable son un hallazgo, no una partida normal); rastrea su compensación en el estado de cuenta del mes siguiente.

**Confirmaciones bancarias directas (NIA 505)**: solicitud enviada por el auditor directamente al banco (no a través del cliente) por cada cuenta activa e inactiva conocida; coteja el saldo confirmado contra el mayor contable y contra la conciliación; revisa la confirmación en busca de restricciones, garantías otorgadas, líneas de crédito, avales y cuentas no reveladas por el cliente. Una confirmación no devuelta a tiempo se trata como **limitación al alcance** hasta agotar procedimientos alternativos — no se asume el saldo del cliente por defecto.

**Prueba de corte**: examina los depósitos y retiros de los últimos y primeros días alrededor de la fecha de cierre, y contrasta contra el estado de cuenta bancario del período siguiente para confirmar que el registro contable corresponde al período correcto.

**Detección de transferencias entre cuentas propias cercanas al corte (*kiting*)**: arma un cuadro de transferencias inter-bancarias de los últimos días del ejercicio con fecha de emisión y fecha de acreditación en cada extremo; una transferencia registrada como recibida antes de haberse debitado en el banco de origen es indicio de *kiting*.

**Efectivo restringido y equivalentes de efectivo**: verifica que solo se clasifique como equivalente el efectivo con vencimiento original ≤ 90 días desde su adquisición, de fácil conversión a un importe determinado y con riesgo insignificante de cambio de valor; lo demás se reclasifica y se cruza al Bloque A. El efectivo restringido (garantías, encajes, cuentas embargadas o en fideicomiso) se separa y se evalúa su presentación como corriente o no corriente según el plazo de la restricción.

**Moneda extranjera**: si existen saldos en divisa, recalcula la conversión a la tasa de cierre y la diferencia de cambio contra el marco confirmado (Sección 30 NIIF PYMES / NIC 21).

**Consideraciones de fraude (NIA 240)**: revisa si algún custodio tiene acceso simultáneo al registro contable, si existen cajas sin fianza de fidelidad, y si hay movimientos de efectivo con partes relacionadas fuera del curso normal del negocio.

---

## 9. Estructura del libro de trabajo

| Hoja | Contenido |
|---|---|
| **C-00** | Alcance, marco confirmado, materialidad recibida de P-01, `TD`, `RAI`, enfoque y firmas |
| **C-01** | Mapa de cobertura: cada subcuenta del grupo asignada a Bloque A / B / C, con el control de cobertura en cero |
| **C-02** | Universo de cajas, POS, bancos, custodios y definición operativa del cierre de caja confirmada con el cliente |
| **C-03** | Verificación de integridad de la población de cierres (esperados vs. recibidos) y partidas clave excluidas |
| **C-04** | Parámetros del muestreo de atributos: población por estrato, `TD`, `RAI`, `n`, semilla, método, fecha |
| **C-05** | Cédula de detalle: una fila por cierre seleccionado, una columna por atributo de la sección 5 |
| **C-06** | Evaluación de la tasa de desviación y conclusión sobre la eficacia operativa del control |
| **C-07** | Actas de arqueo de caja practicados por el auditor |
| **C-08** | Conciliaciones bancarias — detalle, recálculo y antigüedad de partidas |
| **C-09** | Confirmaciones bancarias — control de envío y recepción, cruce contra libros y restricciones informadas |
| **C-10** | Pruebas de corte y detección de transferencias entre cuentas propias |
| **C-11** | Efectivo restringido, equivalentes de efectivo y moneda extranjera — clasificación y recálculo |
| **C-12** | Deficiencias de control y hallazgos sustantivos |
| **Marcas** | Leyenda de marcas y convención de colores |

Cada hoja lleva, en este orden exacto: **Objetivo → Procedimiento → Análisis → Marcas → Referencia → Observaciones → Conclusión**, y cierra con SATISFACTORIA / SATISFACTORIA CON EXCEPCIONES / NO SATISFACTORIA / LIMITACIÓN AL ALCANCE. Incluye además una sección **«Normativa de auditoría aplicada»** con la NIA que sustenta el procedimiento y su título completo, la norma contable según el marco confirmado y la fuente del dato.

NIA que sustentan este papel: **200** objetivos globales · **230** documentación · **240** fraude, con énfasis en el efectivo como activo de mayor riesgo · **265** comunicación de deficiencias · **315 (Revisada)** identificación y valoración de riesgos, diseño e implementación del control · **330** respuesta a los riesgos valorados y prueba de eficacia operativa · **402** consideraciones cuando un tercero custodia o transporta valores · **500** evidencia · **505** confirmaciones externas · **510** saldos iniciales, si es primer año de auditoría · **520** procedimientos analíticos · **530** muestreo de auditoría · **560** hechos posteriores · **580** manifestaciones escritas.

Construcción: `openpyxl`, fórmulas reales y nunca resultados pegados (salvo la selección de la muestra, que se pega por diseño). Evita `XLOOKUP`, `FILTER`, `SORT`, `UNIQUE` y las matriciales — LibreOffice no las evalúa; usa `INDEX`/`MATCH`, `SUMPRODUCT`, `IFERROR`. Recalcula con el script del skill `xlsx` y no entregues nada mientras reporte errores. Un recálculo limpio prueba que las fórmulas evalúan, no que sean correctas: verifica además los totales y los cuadres.

---

## 10. Procedimientos analíticos previos (NIA 520)

Antes de muestrear, corre y reporta: variación mensual del saldo de caja y bancos contra el ejercicio anterior; rotación de depósitos (días entre cierre y depósito) por caja; frecuencia y monto de sobrantes/faltantes por custodio a lo largo del período; cajas con crecimiento de saldo no depositado; y cuentas bancarias con movimientos atípicos de fin de semana o fuera de horario. Estos resultados orientan qué cajas o cuentas merecen partida clave (Bloque B) antes de fijar la muestra.

---

## 11. Qué automatizas y qué decide el auditor

| Automatizado | Manual — decide el auditor responsable |
|---|---|
| Armar la población de cierres y verificar su integridad | Confirmar el marco contable, la materialidad y la definición operativa del cierre |
| Calcular `n` y seleccionar con semilla | Fijar `TD` y `RAI` |
| Calcular la tasa de desviación observada | Calificar si el control opera con eficacia y qué efecto tiene sobre el alcance sustantivo |
| Cruzar confirmaciones bancarias y conciliaciones contra libros | Decidir si una confirmación no devuelta constituye limitación al alcance |
| Detectar patrones de transferencias sospechosas de *kiting* | Concluir si constituye un hallazgo de fraude o un error de corte |
| Listar cierres faltantes o con diferencia | Determinar la causa raíz y la severidad de la deficiencia |

---

## 12. Cierre — qué informas al usuario

No describas el contenido del archivo: el usuario lo abre. Informa siempre:

1. **Cobertura**: qué porcentaje del saldo del grupo quedó en cada bloque y con qué cifras cuadró el control.
2. **Integridad de la población**: cierres esperados vs. recibidos, y qué faltó.
3. **Muestreo de controles**: población, `TD`, `RAI`, `n`, semilla, tasa de desviación observada y la conclusión sobre la eficacia operativa.
4. **Resultado sustantivo**: arqueos practicados, conciliaciones y confirmaciones bancarias recibidas/pendientes, y hallazgos de corte o de *kiting*.
5. **Hallazgos reales**, separando incorrecciones cuantificadas y deficiencias de control.
6. Lo que quedó **pendiente de información del cliente** y por qué.
7. Las **decisiones que requieren al auditor responsable**.

Nunca ocultes un vacío ni lo llenes con un número para que el papel «se vea completo». Un papel con casillas marcadas como pendientes es evidencia válida; un papel con cifras o actas inventadas no lo es.