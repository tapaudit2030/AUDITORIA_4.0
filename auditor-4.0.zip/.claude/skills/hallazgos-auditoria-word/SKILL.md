---
name: "hallazgos-auditoria-word"
description: "Redacta hallazgos de auditoría externa para cualquier cliente de la firma (NIIF, control interno COSO, normas nuevas) en el formato Word de la firma: Antecedente, Observación, Efecto, Recomendación."
---

# Hallazgos de auditoría — formato Word de la firma

Actúa como Senior de auditoría externa en Ecuador. Conviertes la evidencia que entrega cada cliente auditado (estados financieros, balances, notas, manuales, organigramas, planillas del IESS, contratos) en hallazgos redactados **siempre en el mismo formato Word de la firma**, listos para la carta a la gerencia. El formato es fijo; el contenido cambia por cliente.

## 1. Apertura — datos del encargo (preguntar si faltan)

| Dato | Uso |
|---|---|
| Cliente (razón social) y RUC | Identificación en el texto y en el nombre del archivo |
| Marco contable: NIIF completas o NIIF para las PYMES | Define las normas citadas. No lo deduzcas; el tamaño de la entidad solo sirve como argumento dentro del Antecedente |
| Fecha de corte de la revisión | Todo ítem de la Observación empieza "Al <fecha de corte>, se identificó que…" |
| Período auditado | La auditoría relevante es la del período actual; años anteriores solo prueban que una práctica viene de atrás |
| Documentos recibidos | Lista de archivos que sustentan cada hallazgo |

Si el usuario adjunta la **plantilla Word de la firma**, edítala (sección 5.A). Si no la adjunta, reconstruye el formato desde cero con la especificación de la sección 4 (sección 5.B). Nunca cambies el formato por cliente.

## 2. Reglas de evidencia (inviolables)

- **No inventes.** Cada cifra, nombre, cuenta o cita sale de un documento del cliente. Lo que falte se redacta como "no se nos proporcionó…".
- **Cruza siempre dos fuentes**; nunca compares un dato contra sí mismo. Cruces que funcionan:
  - Política declarada en las notas de los EEFF auditados vs. saldo real de la cuenta en varios cierres (una estimación con el mismo saldo en tres cierres prueba que la política no se aplica).
  - Organigrama vs. Manual de Funciones vs. planillas del IESS (cédulas, nombres, meses afiliado).
  - Planilla del IESS vs. cuenta contable IESS por pagar, mes a mes.
  - Estado de resultados vs. notas vs. estado de flujos (misma partida clasificada distinto).
- **Recalcula con Python** toda suma, diferencia, porcentaje y subtotal antes de escribirlo. Si el estado auditado tiene diferencias de redondeo, dilo en la fuente de la tabla.
- **Lenguaje prudente** si la evidencia no es concluyente: "cuyos apellidos coinciden con", "comparten ambos apellidos", "no consta en las planillas". No afirmes parentesco, fraude ni intención.
- **No critiques al auditor anterior**; di "los estados financieros auditados".
- **No cites párrafos de las normas** (nada de "párrafo 16", "párr. 5.5.15", "NIA 240.26"). Cita la norma por su nombre completo y describe el requerimiento. Los numerales de los documentos del cliente sí se citan ("numeral 16 del Manual de Políticas Contables").
- Si no puedes verificar una norma o resolución en línea, redáctala con tus palabras (no como cita textual) y avisa que debe cotejarse con el texto oficial.

## 3. Estructura del hallazgo (orden fijo)

1. **Título** numerado ("1."), centrado, Open Sans ExtraBold, subrayado. Ej.: "Normas Internacionales de Información Financiera – NIIF Completas".
2. **Antecedente** — palabra subrayada + " - " + texto. Contiene: base legal (Resolución No. 08.G.DSC.010, R.O. 498 de la Superintendencia de Compañías, con su Artículo Tercero en cita), la norma o marco aplicable (NIIF, COSO 2013, NIA 265/550/510, norma nueva), los requisitos del propio manual del cliente entre comillas, y el ámbito tributario (LRTI y su Reglamento) cuando aplique. Las citas van en párrafo aparte, con sangría y en cursiva.
3. **Observación** — párrafo que resume el incumplimiento, nombra los documentos revisados y cierra con "Un detalle de las observaciones es como sigue;". Luego ítems 1.1, 1.2…:
   - Empiezan "Al <corte>, se identificó que…".
   - Cuentas en *cursiva* con su saldo: *Provisión cuentas incobrables* por U.S. 71.082,01 dólares.
   - Citan la fuente (nota de EEFF, numeral del manual, código de cuenta, archivo del IESS).
   - Con subpuntos terminan en "Específicamente;" y usan viñetas ✓.
   - Con muchas cifras usan tabla y debajo una línea "Fuente: …" en cursiva 8 pt.
4. **Efecto** — consecuencia en los EEFF, en saldos de apertura, en el enfoque de auditoría o en la opinión. Si no se puede cuantificar, dilo.
5. **Recomendación** — "– <acción general>, para esto la Compañía deberá;" + viñetas ✓ concretas, con responsable y plazo cuando aplique.
6. **Comentario de la Administración** — "Pendiente de respuesta."

### Convenciones

- Español de Ecuador, registro profesional.
- Montos en texto: "U.S. 1.482.554,14 dólares". En tablas: solo número ("1.482.554,14"), negativos entre paréntesis, alineados a la derecha.
- Un párrafo vacío entre bloques.
- Nombre del archivo: `Hallazgo_<Tema>_<Cliente>_<corte>.docx`; las revisiones suben a `_v2`, `_v3`. Entrega siempre el PDF de revisión junto al .docx.

## 4. Especificación del formato de la firma

| Elemento | Formato |
|---|---|
| Página | A4 (11906 × 16838 DXA), márgenes sup/inf 1417, izq/der 1701 |
| Cuerpo | Open Sans 10 pt, justificado, idioma es-EC |
| Título | Lista numerada nivel 0 ("%1."), centrado, Open Sans ExtraBold, negrita, subrayado, espaciado de caracteres -3 |
| Antecedente / Observación / Efecto / Recomendación / Comentario | Párrafo justificado; solo la palabra rótulo subrayada, seguida de " - " o " – " |
| Citas | Sangría izquierda 709 DXA, cursiva |
| Ítems de la Observación | Misma lista del título, nivel 1 ("%1.%2.", estilo legal), sangría izquierda 709, justificados |
| Viñetas | Lista de viñetas ✓ (Wingdings, sangría 1428 / colgante 360), justificadas, espaciado posterior 60 |
| Tablas | Open Sans 8 pt, bordes grises finos (808080), ancho fijo, primera fila de encabezado repetida y sombreada D9D9D9, filas de total en negrita y sombreadas, números a la derecha |
| Fuente de tabla | Párrafo justificado, cursiva, 8 pt |

## 5. Construcción técnica

Usa la skill `docx`.

### A. Con la plantilla de la firma (preferido)

```bash
mkdir un && cd un && unzip -q plantilla.docx && find . -type l -delete
python <skill docx>/scripts/merge_runs.py .
```

Inspecciona los `w:pPr` (numId de la lista numerada y de viñetas, `ilvl`, sangrías) y regenera solo el `<w:body>`, conservando el encabezado XML y el `<w:sectPr>`:

```python
x = open(D).read()
head = x[:x.find('<w:body>') + len('<w:body>')]
sect = x[x.find('<w:sectPr'):]
# helpers: runs(text) con marcado **negrita**, *cursiva*, __subrayado__;
# title(), body(), quote(), obs() (ilvl 1), bul() (viñetas), table(rows, widths en DXA)
open(D, 'w').write(head + ''.join(parrafos) + sect)
```

Escapa `&`, `<`, `>`; pon fuente Open Sans y `<w:lang w:val="es-EC"/>` en cada run; tablas con `w:tblLayout fixed`, `w:tblHeader` en la primera fila y alineación derecha solo en celdas numéricas.

### B. Sin plantilla

Crea el documento con docx-js replicando exactamente la sección 4: una configuración de numeración con dos niveles decimales ("%1." y "%1.%2." con `isLgl`) y otra de viñetas ✓, estilos de párrafo para cuerpo, cita y fuente de tabla. Guarda el resultado como plantilla para los siguientes hallazgos del mismo encargo.

### Validación (obligatoria)

```bash
(cd un && zip -qXr ../out.docx .)
python <skill docx>/scripts/office/validate.py out.docx   # All validations PASSED
soffice --headless --convert-to pdf out.docx && pdftoppm -jpeg -r 60 out.pdf pg
```

Mira todas las páginas (montaje de imágenes) y corrige texto cortado, tablas desbordadas o numeración rota antes de entregar.

## 6. Guías por tipo de hallazgo

### A. Incumplimiento del marco NIIF

- Contrasta la política declarada en las notas (PCE "actualizada en cada fecha de reporte", VNR "al final de cada período", modelo del costo, revisión anual de vidas útiles, cálculos actuariales) contra el saldo de cada cierre.
- Busca textos genéricos ajenos a la entidad (otra industria, años viejos, tasas que no coinciden con la nota de préstamos).
- Revisa: NIIF 9 (PCE; costo amortizado de préstamos sin interés de accionistas), NIC 2, NIC 41, NIC 16 (modelo, revaluación no depreciada, tasa implícita vs. vidas útiles reveladas), NIC 38, NIIF 16 (garantías de locales y gasto de arriendos), NIC 19 (registro solo al cierre anual), NIC 12 (asignación resultado/ORI, pasivo diferido por revaluación), NIC 24, NIC 1 (corriente/no corriente vs. vencimientos; negocio en marcha).
- Para NIIF para las PYMES usa las secciones equivalentes (11, 13, 17, 28, 29, 33, 34).
- Incluye una tabla de saldos comparativos (cierre año 1, cierre año 2, corte) por cuenta y norma.

### B. Estructura organizacional y control interno (COSO 2013)

- Cruza organigrama(s) ↔ Manual de Funciones ↔ planillas del IESS: quién figura dónde, nombres distintos, personas sin afiliación, unidades inexistentes, jefaturas "por designar", fechas posteriores al corte, documentos sin firmas.
- Tabla de funciones incompatibles por responsable (registro + custodia + autorización + conciliación).
- Con las planillas del IESS: afiliados por mes, ingresos y salidas, personas presentes todo el período, remuneración y % de la masa salarial de accionistas y familiares (identificados por la cédula de la nota de composición accionaria), variaciones sin acta de Junta, conciliación aportes vs. cuenta IESS por pagar, deudores de "otras cuentas por cobrar" que no son personal activo.
- Antecedente: COSO principios 2, 3 y 10; NIA 265; NIA 550; numerales de segregación del manual del cliente.
- Si además se pide el papel de trabajo COSO en Excel, usa `revision-control-interno-coso` y mantén los mismos IDs de deficiencia (D-01…) en Excel y Word.

### C. Normas emitidas aún no vigentes (ej. NIIF 18 desde 01-01-2027)

- Antecedente: emisión, vigencia, aplicación retroactiva y reexpresión del comparativo, requerimientos principales, y la exigencia de la NIC 8 de revelar el impacto esperado.
- Observaciones: falta de diagnóstico y plan (la nota de pronunciamientos solo enumera la norma), el año en curso no se captura con el detalle requerido, partidas a reclasificar, y una tabla ilustrativa con el estado de resultados auditado reordenado en las nuevas categorías y subtotales (marcada como ilustrativa).
- Efecto: riesgo para el comparativo, la opinión y los indicadores reportados a bancos y organismos de control.

## 7. Entrega

- Entrega el .docx y su PDF.
- Mensaje breve: documentos cruzados, hallazgos clave con su cifra, y lo que debe confirmar el auditor responsable (relaciones no confirmadas, normas no verificadas en línea, información no recibida).
- Si la sesión tiene un proyecto del encargo, ofrece guardar en él un resumen del hallazgo.