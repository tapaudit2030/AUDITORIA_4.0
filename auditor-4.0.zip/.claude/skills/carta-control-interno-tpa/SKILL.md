---
name: "carta-control-interno-tpa"
description: "Redacta la carta de control interno (Oficio TPA) de ThePowerAudit S.A. sobre el modelo Word de la firma, a partir de hallazgos de control interno, con el marco contable confirmado (NIIF para las PYMES o NIIF completas) y LRTI. Solo para clientes de ThePowerAudit."
---

# Carta de control interno – ThePowerAudit S.A.

Convierte hallazgos de control interno (por ejemplo, la hoja HAL-01 del mapeo de procesos MP-00, una matriz de deficiencias NIA 265 o una lista del usuario) en la carta "Comentarios a la Gerencia" de la firma. La carta respeta exactamente el modelo Word que entrega el usuario.

## Insumos

1. **Modelo de carta de la firma** (.docx; por ejemplo, `OFICIO Nro. TPA-<CLIENTE>-<AÑO>-00X Carta de control interno al <fecha>.docx`). Si no se adjunta, pídelo: nunca construyas la carta desde cero.
2. **Hallazgos con su evidencia**: documento fuente, cifras del balance de comprobación y citas textuales de las políticas o manuales del cliente.
3. **Balance de comprobación** del corte, para validar cada cifra citada.

## Reglas no negociables

- **No inventar nada.** Cada cifra sale del balance o de un documento del cliente. Cada cita entre comillas es textual, incluidos los errores de tipeo del original (por ejemplo, "deberá conta"). Si falta evidencia, el asunto va a la condición "Información no incluida", no se redacta como deficiencia.
- **No afirmar requerimientos que no constan.** Si no hay evidencia de que la información se pidió formalmente, escribe "la documentación proporcionada no incluye", no "no ha proporcionado la información solicitada".
- **Marco contable: el confirmado en `encargo.json` (campo `marco`)** — AUDITOR_4.0 lo pregunta siempre al abrir el encargo. Si es **NIIF para las PYMES**, cita la sección así: `La Sección 13 "Inventarios" de la NIIF para las PYMES (Tercera Edición, febrero 2025)`. Si es **NIIF completas**, cita la NIC/NIIF equivalente (p. ej. `La NIC 2 "Inventarios"`; deterioro de cartera con NIIF 9). Nunca mezcles ambos marcos ni uses fórmulas duales como "según el marco aplicable". Si `marco` está pendiente, no redactes la carta: pide la confirmación.
- **Antecedente tributario: Ley de Régimen Tributario Interno (LRTI) y su Reglamento de aplicación vigentes en Ecuador**, con artículo y numeral. Nunca escribas "PENDIENTE DE VERIFICACIÓN NORMATIVA". Referencias usadas con frecuencia:
  - LRTI art. 10 num. 11: provisión de incobrables del 1 % anual sobre los créditos del ejercicio, con un acumulado máximo del 10 % de la cartera total. Reglamento art. 28 num. 3: baja de incobrables.
  - LRTI art. 10 num. 9: remuneraciones deducibles solo si se aportó al IESS. Para la materia gravada, cita la Ley de Seguridad Social, art. 11 (incluye comisiones).
  - Reglamento art. 28 num. 10: gastos de gestión hasta el 2 % de los gastos generales. LRTI art. 10 num. 6: gastos de viaje hasta el 3 % del ingreso gravado.
  - LRTI art. 47: crédito tributario y devolución del impuesto a la renta. LRTI art. 69: liquidación del IVA y retenciones de IVA.
  - Si el acceso web está disponible, confirma el texto vigente en la fuente oficial (SRI) antes de citar. Si no lo está, cita igual y avisa al usuario que contraste los artículos.
- **NIA** (nombre completo): 210, 240, 315 (Revisada 2019), 500, 550, etc. Cita el número de párrafo solo si estás seguro de él.
- **Español de Ecuador.** Cifras como `U.S. 469.602 dólares` en el texto y `469.602` en las tablas (punto de miles).

## Estructura (se conserva la del modelo)

1. Portada, oficio, fecha, destinatarios, saludo y firma: sin cambios. Conserva el número de oficio y la fecha del modelo y avísale al usuario que los confirme.
2. Introducción: se editan solo dos párrafos.
   - Alcance: "Los comentarios que se exponen a continuación corresponden a <alcance real>… No constituyen una revisión integral del sistema de control interno de la Compañía." Mantén una longitud similar a la del original para que la firma no pase de página.
   - Marco normativo: "Las referencias normativas contables de este informe corresponden a <marco confirmado: la NIIF para las PYMES, Tercera Edición, emitida en febrero de 2025 | las Normas NIIF completas>, marco adoptado por la Compañía en su Manual de Políticas Contables. Los criterios tributarios se fundamentan en la Ley de Régimen Tributario Interno y en su Reglamento de aplicación, vigentes en el Ecuador."
3. **CONDICIONES REPORTABLES**: la n.º 1 es "Información no incluida…", con viñetas agrupadas por subtítulo en cursiva. Le siguen los hallazgos de nivel Alto.
4. Secciones por área, en mayúsculas con doble subrayado (por ejemplo: AMBIENTE DE CONTROL Y ORGANIZACIÓN; VENTAS, INGRESOS Y CUENTAS POR COBRAR; EGRESOS Y TESORERÍA; INVENTARIOS; NÓMINA Y BENEFICIOS A EMPLEADOS; ASUNTOS TRIBUTARIOS). La numeración es continua en toda la carta.
5. Cada condición tiene este formato:
   - Título numerado, centrado, negrita y subrayado.
   - `Antecedente` (subrayado) ` - ` y la norma NIIF para las PYMES, NIA, LRTI o política del cliente. Las citas textuales van en un párrafo propio: `“…texto…”`.
   - `Observación` (subrayado) ` - Al <fecha de corte>, …` con los hechos y cifras. Si hay tabla, el párrafo cierra con "un detalle es como sigue;". Las tablas no llevan bordes, el encabezado va subrayado y se subraya la última cifra antes del total.
   - `Recomendación` (subrayado) ` – ` con acciones concretas.
   - Hallazgos que describen la misma deficiencia vista desde dos procesos se unifican, y se informa al usuario.

## Procedimiento técnico (editar el modelo, no recrearlo)

1. `unzip` del modelo, borrar los enlaces simbólicos y ejecutar `merge_runs.py` del skill docx.
2. En `word/document.xml`, separa los bloques de primer nivel (`<w:p>` y `<w:tbl>`) y verifica que su concatenación reproduzca el cuerpo exacto. Conserva todo hasta el párrafo con el `sectPr` que cierra la carta (antes de "CONDICIONES REPORTABLES") y el `sectPr` final del documento.
3. Genera los párrafos nuevos clonando el XML del modelo:
   - Título: estilo `Prrafodelista` con el `numId` de las condiciones.
   - Viñetas: `Prrafodelista` con su propio `numId`.
   - Etiquetas: run subrayado seguido de un run normal.
   - Citas: `<w:br/>` más el texto entre comillas tipográficas.
   - Párrafos vacíos entre bloques, igual que en el modelo.
   - Quita los atributos `w14:paraId` de los párrafos nuevos.
4. Paginación: agrega `<w:keepNext/>` a encabezados, títulos y al párrafo vacío siguiente, y en las tablas `<w:cantSplit/>` y `keepNext` en todas las filas menos la última.
5. Vuelve a comprimir el paquete y ejecuta `validate.py --original modelo.docx`; debe indicar que la validación pasó.
6. Convierte a PDF con LibreOffice y revisa las páginas: la firma debe quedar en su página, sin títulos huérfanos al pie. Busca en el texto las cadenas `NIC `, `NIIF 9`, `marco aplicable` y `PENDIENTE`: deben dar 0 resultados.
7. Entrega el .docx y el .pdf, y guárdalos en la carpeta del cliente (por ejemplo, `Claude outputs`) con un nombre distinto al del modelo.

## Al entregar

Indica en pocas líneas:

- el número de condiciones por sección;
- qué cambió respecto del modelo (párrafo de alcance y párrafo de marco normativo);
- qué hallazgos se unificaron;
- los datos que el usuario debe confirmar: número de oficio, fecha y artículos tributarios si no se pudieron verificar en línea.