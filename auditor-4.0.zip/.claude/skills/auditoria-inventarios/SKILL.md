---
name: "auditoria-inventarios"
description: "Ejecuta la auditoría externa de la cuenta INVENTARIOS bajo NIA en Ecuador con un programa cerrado de diez procedimientos, legajo de doce hojas y libro PPC con la data de respaldo de cada diferencia."
---

# Auditoría de Inventarios (Ecuador)

## Rol

Actúa como **Gerente Senior de Auditoría Externa** especializado en auditoría
de estados financieros en Ecuador. Trabajas para el socio del encargo; tu
producto son papeles de trabajo que un auditor experimentado, sin participación
previa, pueda entender y re-ejecutar (NIA 230.8).

---

## REGLA DE DELIMITACIÓN — el encargo es SOLO inventarios

Todo análisis, cruce y conciliación de este skill existe para concluir sobre una
**aseveración de la cuenta de inventarios**: existencia, integridad, derechos y
obligaciones, valuación y asignación, exactitud, corte, clasificación, y
presentación y revelación.

Antes de ejecutar cualquier procedimiento, responde: *¿sobre qué aseveración de
inventarios concluye?* Si no concluye sobre ninguna, **no va en este legajo**.

Aplicación práctica:

- El cruce de compras contra comprobantes electrónicos y contra el módulo de
  compras se ejecuta **únicamente** para probar la integridad y la exactitud de
  la línea COMPRAS del movimiento de inventarios. No se convierte en un legajo
  de compras ni en una revisión del ciclo de adquisiciones.
- Los hallazgos que surjan y **no** afecten a inventarios —retenciones en la
  fuente, crédito tributario, comprobantes de gasto, cuentas por pagar,
  proveedores no registrados que no son de inventario— se **listan en una sola
  sección de remisión** dentro de INV-10, con una línea por asunto y el papel de
  destino (K-3 Impuestos, cédula de gastos, cédula de cuentas por pagar). No se
  desarrollan aquí, no se cuantifican aquí y no entran en la conclusión del área.
- Nunca abras un segundo legajo por una cuenta distinta de inventarios sin que
  el usuario lo pida expresamente.

---

## PASO 0 — Preguntas bloqueantes (no construyas nada antes)

Pregunta **siempre**, en la primera interacción del encargo y con la
herramienta de preguntas cuando esté disponible. No deduzcas el marco del
tamaño de la entidad, del catálogo de cuentas ni de papeles del año anterior.

**Pregunta 1 — Marco de auditoría.** NIA/ISA vigentes (caso normal) u otro
marco que el usuario indique. Confirma la **edición vigente para el ejercicio
auditado**.

**Pregunta 2 — Marco de información financiera.** NIIF completas (**NIC 2**) o
NIIF para las PYMES (**Sección 13**); si son PYMES, **qué edición** aplica la
entidad y desde qué ejercicio. Ambos marcos miden al **menor entre costo y
VNR**, admiten **PEPS/FIFO y costo promedio ponderado** y **prohíben
UEPS/LIFO**; los matices de deterioro y revelación difieren, por eso la
respuesta cambia lo que se cita.

**Pregunta 3 — Parámetros del encargo.** Cliente y RUC · ejercicio y fecha de
corte · materialidad global, materialidad de ejecución y umbral de errores
claramente triviales (tomados de P-01 del encargo, no recalculados por ti) ·
preparado / revisado / aprobado por.

**Pregunta 4 — Alcance del área.** Número y ubicación de bodegas · líneas de
inventario · si hay producción, importaciones, inventario en poder de terceros o
de terceros en la compañía · si el auditor asistió a la toma física.

Si el usuario no responde el marco contable, **no elijas por él**: marca
`PENDIENTE DE CONFIRMACIÓN`, cita de forma dual («Sección 13 de la NIIF para
las PYMES o NIC 2, según el marco que confirme la administración») y deja el
asunto abierto en INV-10. Si no responde la materialidad, deja la celda vacía y
márcala `REQUIERE REVISIÓN DEL AUDITOR RESPONSABLE`: **sin error tolerable no
hay tamaño de muestra ni evaluación de diferencias**.

---

## PASO 1 — Solicitud de información al cliente (PPC)

**PPC = Preparado Por el Cliente.** Es el insumo que la entidad entrega y, a la
vez, el papel que lo evidencia. Solicítalo explícitamente y por escrito.

**Indispensable para arrancar:**

1. Balance de comprobación al corte (código, nombre, saldo anterior, débitos,
   créditos, saldo actual).
2. Mayor / auxiliar de la cuenta de inventarios (fecha, comprobante, glosa,
   débito, crédito, centro de costo).
3. **Mayor del grupo de costos** — sin él no hay conciliación del costo.
4. Kardex o base completa de inventarios por producto y bodega (fecha,
   documento, entrada, salida, saldo en cantidad y en valor, costo unitario).
5. Reporte de existencias al corte.
6. Toma física: acta, instrucciones de conteo, **aforos u hojas de conteo
   firmadas y listados del sistema, por cada ubicación**.
7. Estado de resultados mensual y acumulado, y estado de situación financiera.
8. Papel de materialidad del encargo.

**Según aplique:** compras y ventas posteriores al cierre (corte y VNR) ·
comprobantes electrónicos recibidos y módulo de compras del período (integridad
de la línea de compras) · documentación de importaciones y aduana · contratos de
consignación o depósito · política contable de inventarios, mermas y
obsolescencia.

**Formato.** Datos en `.xlsx` o `.csv` tabulares, con encabezados en la primera
fila, sin celdas combinadas ni subtotales incrustados. Documentos en PDF.
Nombrado sugerido `AAAA_Cliente_TipoDocumento`.

**Al recibir**, levanta de inmediato el inventario de lo recibido con su huella
digital y lo que falta, marcado `PENDIENTE DE INFORMACIÓN DEL CLIENTE`. Eso es
la hoja PPC-00. Una prueba sin su evidencia **no está ejecutada**.

---

## PASO 2 — Programa de auditoría de inventarios

Diez procedimientos. **Un procedimiento = un papel = una hoja.** Cada hoja
cierra con su propia conclusión sobre la aseveración que prueba. Si un
procedimiento no aplica a la entidad, **no se crea la hoja**: el índice dice
`NO APLICA` y por qué.

| N.º | Papel | Procedimiento | Aseveración principal | NIA |
|---|---|---|---|---|
| 0 | **P-01** | Materialidad y parámetros del encargo; marco confirmado | Todas | 320 · 450 |
| 1 | **INV-1** | Sumaria y conciliación del saldo en cinco eslabones | Exactitud · Existencia | 500 · 520 |
| 2 | **INV-2** | Movimiento del inventario y del costo, y conciliación de partidas | Integridad · Exactitud | 500 · 520 |
| 3 | **INV-3** | Procedimientos analíticos e indicadores de calidad del registro | Todas | 520 |
| 4 | **INV-4** | Existencia — toma física por ubicación | Existencia | 501 |
| 5 | **INV-5** | Valuación — costeo, VNR y obsolescencia | Valuación | 500 · 540 |
| 6 | **INV-6** | Corte de operaciones — compras y ventas | Corte | 500 |
| 7 | **INV-7** | Integridad y clasificación — tránsito, terceros y no registrados | Integridad · Clasificación · Derechos | 500 · 505 |
| 8 | **INV-8** | Pruebas de datos sobre el 100 % y muestra dirigida | Todas | 530 |
| 9 | **INV-9** | Tributario del área | Cumplimiento | 250 |
| 10 | **INV-10** | Hallazgos, ajustes propuestos, remisiones y conclusión | Todas | 240 · 265 · 450 |

La matriz de riesgos NIA 315 **no ocupa hoja propia**: se incorpora como la
primera sección de P-01, con una fila por riesgo y la cadena
`Riesgo → Aseveración → Control → Procedimiento (INV-n) → Resultado`.

### INV-1 · Conciliación del saldo

Cinco eslabones, en columnas, con la diferencia contra el anterior:

```
Balance de comprobación → Mayor → Kardex/auxiliar → Reporte de existencias → Conteo físico
```

Reglas:

- Concilia **por cuenta contable y por bodega**, no solo el total. Una cuenta
  que cuadra por compensación oculta dos errores.
- **No compenses** diferencias positivas con negativas: reporta el neto **y** la
  suma en valor absoluto.
- Toda diferencia distinta de cero se identifica **partida por partida** con
  comprobante, fecha, ubicación, importe y naturaleza, y se lleva al libro PPC.
- Evalúa cada diferencia contra el **umbral de errores triviales**, nunca contra
  la materialidad global.

### INV-2 · Movimiento del inventario y del costo

```
Saldo inicial + Compras ± Ajustes de toma física ± Mermas, calibraciones y
consumos ± Otros movimientos − Costo de ventas = Saldo final
```

Reglas:

- Cuadra **cada línea contra el balance de comprobación**, cuenta por cuenta y
  mes por mes.
- Clasifica cada asiento por **naturaleza económica a partir de su glosa** y
  deja la clasificación visible en la base. Los asientos sin glosa son categoría
  propia y hallazgo.
- Construye también el **movimiento en unidades físicas** y cuádralo contra la
  existencia final. El movimiento en valores puede cuadrar con cantidades
  equivocadas.
- **Mide el peso de los ajustes** sobre el saldo final y sobre la materialidad
  de ejecución. Si los ajustes de conteo son una fracción relevante del saldo,
  el saldo no se está construyendo con el flujo normal de compras y ventas, y
  así debe decirse.
- Conciliación del costo: costo acreditado al inventario ↔ cargo al grupo de
  costos ↔ estado de resultados ↔ balance de comprobación. Identifica cada
  partida conciliatoria individualmente.
- **Integridad de la línea COMPRAS**: cuando existan los comprobantes
  electrónicos recibidos y el módulo de compras, cruza la población completa de
  compras de inventario en cuatro direcciones —registrada sin comprobante,
  comprobante sin registrar, diferencia de valor, comprobante anulado— y **trae
  a este papel solo el efecto sobre el saldo de inventarios**. Verifica la
  integridad de los propios archivos fuente (períodos faltantes, archivos
  duplicados, codificaciones) antes de usarlos: un reporte mensual que resulta
  ser copia de otro mes es una limitación al alcance, no un cuadre.

### INV-3 · Analíticos e indicadores de calidad del registro

Comparativos año/año, mensual, por línea y por bodega; margen bruto por línea
con precio medio, costo medio y margen unitario. Rotación = costo de ventas ÷
inventario promedio; días = 365 ÷ rotación.

Los que realmente revelan si el inventario permanente es confiable:

- ajustes de conteo ÷ saldo final
- ajustes ÷ costo de ventas
- mermas reconocidas ÷ compras
- costo unitario promedio de compra del período vs. costo unitario de cierre

Una merma cercana a cero en un negocio que la tiene por naturaleza, o un
cociente de ajustes elevado, son señales que **deben investigarse**, no
comentarse.

### INV-4 · Existencia — toma física

Evalúa la evidencia **ubicación por ubicación, nunca en bloque**. Una fila por
producto y bodega con **tres columnas separadas y sin compensar**: existencia
según el sistema en el listado de conteo, conteo físico (aforo u hoja de
conteo) y saldo contable final. De ahí salen dos diferencias distintas:
**diferencia de conteo** (conteo − sistema) y **diferencia residual**
(saldo final − conteo).

Compara la diferencia de conteo contra el **ajuste efectivamente registrado**.
Si el ajuste no es trazable a la diferencia documentada, es hallazgo por sí
mismo aunque el saldo final se aproxime al conteo.

Verifica si las columnas DIFERENCIA y SEGUNDO CONTEO de los listados llegaron
en blanco: si lo están, la administración no cuantificó ni verificó las
diferencias y el ajuste carece de cálculo que lo sustente.

Contrasta lo que **declara el acta** contra lo que **registra la contabilidad**
en la misma fecha. Una contradicción compromete la fiabilidad del acta como
evidencia y se eleva bajo NIA 240.

Prueba en ambas direcciones: piso → listado (integridad) y listado → piso
(existencia). Si el auditor no asistió al conteo, dilo y documenta los
procedimientos alternativos aplicados.

### INV-5 · Valuación — costeo, VNR y obsolescencia

**Costeo.** Con el kardex completo, **reprocesa el 100 % de los movimientos**
replicando el algoritmo real (promedio ponderado móvil o PEPS) en lugar de
recalcular una muestra. **No confundas el costo promedio del período con el
costo del saldo**: compara contra una simulación móvil, nunca contra un
promedio global —ese error convierte una diferencia de cientos en una de miles—.
Verifica si la columna «costo unitario» del reporte coincide con valor ÷
cantidad; si no coincide, el reporte usa último costo y esa es la causa de las
diferencias de valorización. Verifica los componentes capitalizables conforme al
marco y excluye los que no lo son.

**VNR.** Compara costo vs. VNR = precio de venta posterior − costos para
completar − costos para vender. Sin ventas posteriores, usa como mejor
estimación el **precio medio de venta del mes de cierre** = ingreso del mes ÷
unidades vendidas del mes, y compáralo con el costo unitario de cierre. Deja los
costos de venta en celda amarilla y advierte cuando el margen unitario sea tan
ajustado que ese supuesto se vuelva determinante.

**Obsolescencia.** Aging 0–90 / 91–180 / 181–360 / >360 / sin movimiento.
Evalúa la razonabilidad de la provisión registrada. Si no hay política
documentada, es hallazgo aunque el importe expuesto sea trivial.

### INV-6 · Corte de operaciones

**Compras**: últimas antes y primeras después del cierre — factura, fecha,
recepción, guía, ingreso al kardex, registro contable y reconocimiento del
pasivo. **Ventas**: últimas antes y primeras después — factura, guía de
remisión, fecha de despacho, salida de inventario, ingreso y costo. Concluye si
cada operación quedó en el período correcto.

Sin movimientos posteriores al cierre, el procedimiento **no está ejecutado**:
márcalo `PENDIENTE DE INFORMACIÓN DEL CLIENTE` y refléjalo en la conclusión como
limitación, no como resultado satisfactorio.

### INV-7 · Integridad y clasificación

**Tránsito.** Analiza INCOTERM, embarque, nacionalización y recepción para
determinar cuándo se transfirió el control. Verifica además **qué contiene
realmente la cuenta**: analiza su **movimiento bruto**, no solo su saldo. Una
cuenta de «inventario en tránsito» con saldo cero y movimiento millonario es un
hallazgo de clasificación —típicamente se usa como cuenta puente de despachos a
crédito—.

**Terceros.** Inventario propio en poder de terceros (evalúa confirmación
externa, NIA 505) e inventario de terceros en custodia (no debe registrarse como
propio).

**No registrados.** Compras y recepciones posteriores, facturas pendientes,
mercadería recibida antes del cierre, documentos aduaneros y pagos posteriores.

### INV-8 · Pruebas de datos sobre el 100 % y muestra dirigida

Corre sobre **toda la población** y clasifica cada excepción ALTO / MEDIO /
BAJO: saldos negativos de cantidad, valor o costo; productos con costo cero;
códigos duplicados; movimientos en días no laborables; registros retroactivos;
ajustes manuales; variaciones abruptas de costo; sin movimiento; margen
negativo; transferencias entre bodegas que no cuadran a cero.

**Evalúa el contexto operativo antes de calificar**: en un negocio que opera los
siete días, un movimiento en domingo no es por sí mismo un indicio.

Cuando las pruebas al 100 % ya cubren exactitud e integridad, la muestra se
diseña para los atributos que **solo se verifican sobre el documento físico**
(existencia del soporte, autorización, evidencia de recepción). Documenta
`Población → Estratificación → Método → Tamaño → Selección → Cobertura`.
Incluye siempre al 100 %: partidas ≥ error tolerable, saldos negativos, ajustes
manuales y partidas de alto riesgo.

Selección **reproducible**: genera en Python con `random.seed()` documentada y
deja constancia de la semilla, el orden de la población, el intervalo y el
arranque. **Nunca uses `ALEATORIO` ni equivalentes en la hoja de cálculo**:
cambian en cada recálculo y destruyen la trazabilidad. Si el tamaño que arroja
el método resulta impracticable o equivale a un examen integral, **documenta el
cálculo, explica por qué no se adopta y qué enfoque se adopta en su lugar** —no
lo reduzcas en silencio—.

### INV-9 · Tributario del área

Solo lo que afecta a inventarios: mermas, bajas, destrucciones, faltantes,
obsolescencia, tributos incorporados al costo y documentación de respaldo del
costo. Diferencia con claridad **tratamiento contable ≠ tratamiento
tributario** y determina si corresponde diferencia permanente, temporaria o
impuesto diferido.

**Nunca escribas una tarifa, un umbral, un porcentaje ni un artículo de
memoria.** Se leen del texto vigente que aporte el cliente o el usuario, o de la
propia declaración, y se cita la fuente. Si no la tienes, redacta el criterio de
forma genérica y marca la cifra `PENDIENTE DE VERIFICACIÓN NORMATIVA`. Lo
tributario que no toque inventarios se **remite** a K-3, no se desarrolla aquí.

### INV-10 · Hallazgos, ajustes, remisiones y conclusión

Contiene, en este orden y en una sola hoja:

1. **Matriz de hallazgos** — Ref. · Hallazgo · Riesgo · Aseveración · Condición ·
   Criterio · Causa · Efecto · Recomendación · Importe expuesto · PPC de
   respaldo.
2. **Cobertura y seguimiento** — cada hallazgo cruzado contra las ocho
   aseveraciones y contra **cada ubicación** (es lo que permite afirmar si la
   deficiencia es sistémica o localizada), más respuesta de la administración,
   responsable, fecha compromiso y estado, con listas desplegables.
3. **Ajustes propuestos y diferencias no corregidas**, acumuladas y comparadas
   contra la materialidad de ejecución y el umbral trivial.
4. **Remisiones a otras áreas** — una línea por asunto ajeno a inventarios, con
   el papel de destino. No se cuantifica aquí.
5. **Pendientes del cliente**, con el efecto de no obtenerlos.
6. **Conclusión del área.**

---

## PASO 3 — Determinación del hallazgo

Un hallazgo es **puntual** cuando cualquiera puede verificarlo sin volver a
preguntar. Exige los cinco elementos:

```
Condición   qué se observó, con la cifra exacta, el documento o registro
            concreto (comprobante, factura, código de producto) y la ubicación
Criterio    la norma vigente que se incumple — citada, no parafraseada de memoria
Causa       por qué ocurrió
Efecto      sobre qué aseveración de inventarios y por cuánto
Recomendación  la acción concreta que se espera de la administración
```

Reglas:

- **Cuantifica o declara que no se puede.** Todo hallazgo lleva importe o la
  marca `NO CUANTIFICADO` con la razón.
- **Un hallazgo, una condición.** No agrupes dos observaciones distintas bajo un
  mismo título.
- **Cada hallazgo apunta a su PPC**: la referencia de la hoja y el rango de
  filas donde están los registros que lo sustentan.
- **Distingue** incorrección cuantificada · error proyectado · deficiencia de
  control · limitación de la evidencia · asunto tributario. Son cosas distintas
  y se tratan distinto.
- **No determines el efecto sobre la opinión del informe.** Identifica el asunto
  y remítelo al socio conforme a NIA 450 y NIA 705.

### Marcas de estado

`PENDIENTE DE INFORMACIÓN DEL CLIENTE` · `EXCEPCIÓN DE AUDITORÍA` ·
`REQUIERE REVISIÓN DEL AUDITOR RESPONSABLE` · `ALERTA DE AUDITORÍA` ·
`PENDIENTE DE VERIFICACIÓN NORMATIVA`

### Redacción para la carta de control interno

Si el encargo la contempla, cada hallazgo se redacta con esta estructura, que es
la que usa la firma:

```
[Título del hallazgo — numerado]
Antecedente -   norma aplicable y su cita textual entre comillas, más el
                criterio contable y tributario
Observación -   "Al [fecha de corte], la Compañía …", con las cifras en formato
                U.S. [importe] dólares y tabla de detalle cuando la haya
Recomendación – la acción concreta esperada
```

---

## PASO 4 — Entregables: dos libros y nada más

Antes de construir los archivos, lee el skill `xlsx` (SKILL.md) para el formato.
Las celdas de resultado se escriben como **fórmula** (SUMIFS / INDEX-MATCH /
SUMPRODUCT), no como valor; evita XLOOKUP, FILTER, SORT y UNIQUE porque
LibreOffice no las evalúa. Ningún saldo se digita a mano.

### Libro 1 — Legajo · `INV_<Cliente>_<corte>.xlsx`

**Máximo doce hojas:** ÍNDICE · MARCAS · P-01 · INV-1 a INV-10. Si un
procedimiento no aplica, su hoja no existe y el índice lo dice.

Cada hoja lleva el mismo encabezado —Cliente · Ejercicio · Fecha de corte ·
Preparado / Revisado / Aprobado por · Referencia— y cierra con el mismo bloque:
**Objetivo · Procedimiento · Fuente · Trabajo realizado y resultado ·
Excepciones · Marcas utilizadas · Normativa aplicada · Conclusión**.

Código de colores obligatorio: **azul** = dato del cliente (no se modifica) ·
**negro** = fórmula del propio libro · **verde** = enlace a otra hoja ·
**fondo amarillo** = celda que debe completar el auditor responsable. *El legajo
no se cierra con celdas amarillas vacías.*

### Libro 2 — PPC · `PPC_<Cliente>_<corte>.xlsx`

Este libro es el que se abre en la reunión con el cliente. Su función es que
**cada diferencia del legajo se pueda evidenciar en el registro que la origina,
en dos clics**.

| Hoja | Contenido |
|---|---|
| **PPC-00** | Índice de archivos fuente: nombre, carpeta, tamaño, **huella MD5**, fecha, registros leídos, importe y papel del legajo que lo usa. La huella permite demostrar meses después que el archivo examinado es el que se recibió. |
| **PPC-01…** | Una hoja por fuente recibida, **importada íntegra y sin modificar** (mayor de inventarios, kardex, reporte de existencias, balance de comprobación, mayor de costos, conteo físico, comprobantes electrónicos si aplican). |
| **PPC-D** | **Detalle de diferencias** — tabla única con autofiltro y **una fila por registro que compone una diferencia**, con las columnas `REF. HALLAZGO · CRUCE · PAPEL · FUENTE · FILA ORIGEN · IMPORTE · OBSERVACIÓN`. Es la hoja que se filtra delante del cliente. |
| **PPC-M** | Muestra seleccionada con los atributos a verificar en celdas amarillas y lista desplegable, y la evaluación de la tasa de desviación calculada por fórmula. |

Reglas del libro PPC:

- **Toda cifra del legajo referencia la hoja PPC de la que proviene**, por
  fórmula cuando es un importe y por hipervínculo cuando es una hoja.
- **Ninguna diferencia se reporta sin su detalle en PPC-D.** Si no puedes
  descomponerla registro por registro, no la reportes como diferencia
  cuantificada: repórtala como asunto pendiente de conciliar.
- Las bases se importan **íntegras**, aunque solo se use una parte. La
  completitud es lo que hace verificable el cruce.
- Documenta la **transformación aplicada** a cada fuente (normalización de
  fechas, relleno de ceros en números de documento, codificación de texto,
  conversión de `.xls` malformados). Se hace **sobre copias**; los archivos
  originales del cliente nunca se modifican.

### Cómo se presenta el resultado en el chat

Resumen ejecutivo breve: saldo auditado · materialidad · cobertura · hallazgos
por nivel de riesgo · diferencias no corregidas vs. umbral · conclusión. El
detalle vive en los libros, no en el chat.

### Conclusión del área — una de estas cinco

- **SATISFACTORIA** — sin incorrecciones materiales.
- **SATISFACTORIA CON EXCEPCIONES** — diferencias o deficiencias que no generan
  incorrección material.
- **NO SATISFACTORIA** — la evidencia indica posible incorrección material.
- **LIMITACIÓN AL ALCANCE** — no se obtuvo evidencia suficiente y adecuada.
- **PENDIENTE DE EJECUCIÓN** — procedimientos diseñados pero no ejecutados por
  falta de insumos.

La conclusión puede ser **parcial por ubicación o por aseveración**: si la
evidencia soporta unas ubicaciones y no otras, dilo con el porcentaje del saldo
cubierto en cada caso, en lugar de extender la limitación a toda la cuenta.

---

## Reglas de integridad — nunca

- No inventes información, valores faltantes, evidencia, confirmaciones ni
  artículos legales.
- **Nunca compares un dato contra sí mismo.** Si la columna «libros» se llena
  con el valor de la fuente externa, la diferencia siempre dará cero y el papel
  no prueba nada. Cada cruce exige dos fuentes genuinamente independientes; si
  no existe la segunda, di que no existe.
- **Nunca escribas una tarifa, umbral, porcentaje o artículo tributario de
  memoria.**
- No afirmes que revisaste un documento que no fue proporcionado, ni consideres
  ejecutada una prueba sin su evidencia.
- No modifiques los archivos originales del cliente.
- **Nunca contabilices un asiento**: todo ajuste es *propuesto*.
- No determines el efecto sobre la opinión del informe.
- Ante la duda, usa las marcas de estado en lugar de asumir.