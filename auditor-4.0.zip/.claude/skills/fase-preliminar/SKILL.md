---
name: fase-preliminar
description: Fase 2 de AUDITOR_4.0 — Visita preliminar (ejecución interina) de la auditoría bajo NIA. Sumarias interinas, narrativas y recorridos, pruebas de controles con muestreo, revisión interina por ciclos (efectivo, inventarios, gastos, nómina, impuestos), hallazgos y carta de control interno NIA 265. Usar cuando se pida "visita preliminar", "auditoría interina", "pruebas de controles", "recorridos", "narrativas", "carta de control interno" o "hallazgos preliminares".
---

# Fase 2 — Preliminar (ejecución interina)

Requisito: fase 1 aprobada o, al menos, materialidad P-01 y matriz de riesgos
PL-08 terminadas. Si no, avisa al usuario y pregunta si se continúa.
Los papeles van en `encargos/<PREFIJO>/02_Preliminar/`.

## Índice de papeles de la fase

| Ref. | Papel | NIA | Cómo se produce |
|---|---|---|---|
| P-01.1 | **Materialidad — revisión interina**: recalcula con las cifras al corte interino (anualizadas cuando la base es de resultados) y compara con P-01; documenta si se mantiene o se modifica y por qué | 320.12-13 | `build_materialidad.py` con los balances interinos; la decisión de modificarla es del gerente o socio |
| SUM | Sumarias por ciclo al corte interino | 500, 330 | `auditoria-preliminar-nia` → `build_sumarias.py` |
| NAR | Actualización de narrativas y recorridos de la planificación (solo si cambió un proceso o un control) | 315 | Actualiza NAR/REC de `01_Planificacion`; no se repite lo ya documentado |
| PC | Pruebas de controles (eficacia operativa) | 330, 530 | Muestreo de atributos con semilla reproducible; un papel por control clave seleccionado en PL-08 |
| E | Efectivo: cierres de caja, arqueos, conciliaciones | 330, 500, 505 | `muestreo-cierres-caja-efectivo-nia` |
| INV | Inventarios (y observación de toma física si cae en el periodo) | 501 | `auditoria-inventarios` |
| G | Gastos: cruce con comprobantes del SRI y compras | 500, 530 | `muestreo-gastos-nia` |
| K-4 | Nómina y beneficios a empleados (IESS, MDT, décimos, utilidades) | 250, 500 | `auditoria-nomina-nia` |
| K-3 | IVA y retenciones interinos (103, 104, ATS) | 250 | `papel-k3-impuestos` |
| OTR | Otros ciclos en alcance (CxC, CxP, PPE, ingresos) | 330 | `papeles-trabajo-nia` con el programa PL-11 de cada ciclo |
| HAL | Hoja de hallazgos y deficiencias (NIA 265) | 265 | `revision-control-interno-coso` (matriz de deficiencias) |
| CCI | Carta de control interno a la gerencia | 265 | ThePowerAudit → `carta-control-interno-tpa`; GLOBALAUDITORS → `hallazgos-auditoria-word` con `entregables-globalauditors` |
| PEND | Requerimiento de información pendiente al cliente | 500 | Lista para enviar al cliente, con lo marcado `PENDIENTE DE INFORMACIÓN DEL CLIENTE` |

## Cómo trabajar

1. Empieza por P-01.1: la materialidad vigente es la que se usa en todas las
   pruebas y muestras de esta fase.
2. Ejecuta solo los ciclos en alcance de `encargo.json`; los demás se marcan
   `n/a` en `avance.md`.
3. Cada prueba responde a un riesgo de PL-08 y lleva su referencia cruzada al
   programa PL-11.
4. Lo que surja de otra área se **remite** en una línea al papel de destino; no
   se desarrolla en el papel actual.
5. Las diferencias encontradas se acumulan como **ajustes propuestos** para el
   resumen de diferencias de la fase final (NIA 450): referencia, cuenta,
   importe, naturaleza (factual, de juicio, proyectada).
6. La carta de control interno solo incluye deficiencias con evidencia. Lo que
   no se pudo verificar va como "Información no incluida".
7. Antes de cerrar, pide al subagente `revisor-calidad` que revise `02_Preliminar`.

## Cierre de la fase

Informa: controles que operan y los que no (con el resultado del muestreo),
diferencias propuestas acumuladas frente a la materialidad de ejecución,
deficiencias significativas para comunicar a la dirección, cambios necesarios
en la estrategia o en los programas de la fase final (NIA 300: la planificación
se actualiza) y el requerimiento de pendientes al cliente.
