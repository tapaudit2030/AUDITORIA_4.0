---
name: estado-encargo
description: Muestra el estado de un encargo de AUDITOR_4.0 o de todos los encargos abiertos — fase actual, papeles hechos y pendientes, información pendiente del cliente y decisiones para el socio. Usar cuando se pregunte "cómo va el encargo", "estado de la auditoría", "qué falta", "avance".
---

# Estado del encargo

1. Si el usuario no nombra un cliente, lista las carpetas de `encargos/` y da
   una línea por encargo: cliente, firma, fase actual y % de tareas hechas.
2. Para un encargo concreto, lee `encargo.json` y `avance.md` y revisa qué
   archivos existen realmente en `01_Planificacion`, `02_Preliminar` y
   `03_Final`. Si `avance.md` marca algo como hecho y el archivo no existe,
   dilo: manda lo que hay en la carpeta, no la lista.
3. Responde en este orden:
   - Fase actual y avance por fase (hechas / en curso / pendientes / n/a).
   - Datos del encargo aún `PENDIENTE DE CONFIRMACIÓN` (en especial marco,
     tipo de cliente y materialidad).
   - Información pendiente del cliente.
   - Decisiones que esperan al gerente o socio.
   - Siguiente paso recomendado.
4. No cambies `avance.md` desde este comando salvo para corregir una
   discrepancia que el usuario confirme.
