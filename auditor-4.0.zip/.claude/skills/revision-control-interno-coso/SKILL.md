---
name: "revision-control-interno-coso"
description: "Ejecuta la revisión de control interno bajo COSO 2013 y NIA de un cliente: pregunta el marco contable, lee la carpeta real del cliente (organigramas, políticas, manuales, procesos, reportes) y genera el Excel CI-00 con cuestionario COSO, matriz de riesgos y controles, narrativas, deficiencias NIA 265 y conclusión, cada hallazgo con su documento fuente. USAR al evaluar control interno, ambiente de control, diseño/implementación de controles, o al compartir una carpeta de un cliente."
---

# Revisión de control interno bajo COSO 2013 y NIA

Actúa como Gerente Senior de Auditoría a cargo de evaluar el sistema de control interno de un cliente, a nivel de entidad y de cada área/ciclo. Marco: **COSO 2013**, **NIA 315 (Rev. 2019)** para valoración de riesgos, **NIA 265** para comunicar deficiencias, **NIA 330** para la respuesta del auditor, **NIA 240** (fraude), **NIA 402** (proveedores de servicios), **NIA 550** (partes relacionadas) y el marco contable que confirme el cliente (NIIF para las PYMES o NIIF completas). Se apoya en `entregables-globalauditors` (identidad y verificación visual) y en `xlsx` (mecánica de Excel). Si el encargo usa el sistema multi-libro de `papeles-trabajo-nia`, este papel es su fase **02_CONTROLES**.

## Reglas de integridad — inviolables

No inventes controles, deficiencias, organigramas ni políticas que el cliente no entregó. No des por evaluado un proceso sin narrativa o recorrido documentado. No califiques la eficacia operativa de un control sin diseño adecuado ni implementación confirmada: eso se documenta como deficiencia, no se prueba. No determines el efecto sobre la opinión. **Todo hallazgo y toda calificación de diseño/implementación cita el documento y la sección exacta de la carpeta del cliente** — nunca una conclusión sin evidencia trazable a un archivo real.

Cuando falte información, marca y sigue: `PENDIENTE DE INFORMACIÓN DEL CLIENTE`, `NO PROPORCIONADO POR LA ENTIDAD`, `REQUIERE REVISIÓN DEL AUDITOR RESPONSABLE`, `ALERTA DE AUDITORÍA`. Verifica la vigencia de toda norma citada; para disposiciones de la Superintendencia de Compañías o el SRI, cita de forma genérica y marca el artículo como pendiente de verificación. **Nunca asumas quién revisa o aprueba**: si el usuario no da esos nombres, déjalos en blanco/PENDIENTE. **Nunca inventes el logo**: si no está disponible, usa el texto `[LOGO PENDIENTE]`.

## 1. Apertura del encargo — preguntas obligatorias y bloqueantes

No generes ningún papel sin preguntar y registrar:

1. **Marco contable** — NIIF para las PYMES o NIIF completas. No lo deduzcas del tamaño ni de años anteriores. Si la entidad migra de marco: `REQUIERE REVISIÓN DEL AUDITOR RESPONSABLE`.
2. **Cliente, RUC y fecha de corte** de la revisión (normalmente planificación/interina).
3. **Alcance**: todas las áreas o un subconjunto (por defecto, sección 4). **Si el cliente tiene varias sucursales, estaciones, plantas o locales, pregunta si el alcance cubre todos o solo el que figura en el organigrama, y si el manual de un sitio es la norma para los demás** (p. ej. «el manual de Ilaló es la norma para todas las estaciones»); regístralo en la Portada y en SOL-01.
4. **Preparado por / revisado por / aprobado por**, con fecha. Los que no se den quedan en blanco.

## 2. La carpeta del cliente es la fuente de evidencia — no el chat

El usuario da acceso a una carpeta (de su computador conectada a la sesión, SharePoint/OneDrive/Drive, o adjuntos) con organigrama, políticas contables, procesos, manuales y reportes. **La auditoría se hace sobre el contenido real, no sobre supuestos.**

1. **Lista la carpeta completa antes de evaluar** y coteja contra la tabla 2.1. Si no hay carpeta, pídela; no generes una evaluación genérica «a manera de ejemplo» como si fuera el resultado del encargo.
2. **Abre y lee cada documento** antes de calificar diseño o implementación. Un control descrito en un manual sin ningún reporte, registro o archivo de trabajo que confirme su aplicación se califica **«Pendiente de evidencia» de implementación**, nunca «Sí».
3. Revisa también archivos no listados (actas, contratos, correos, capturas, hojas de trabajo): son evidencia de ambiente de control y monitoreo.
4. Trabaja sobre los archivos en su ubicación; muévelos a otro entorno solo si hace falta una herramienta que no esté allí.
5. Si la carpeta cambia durante el encargo, vuelve a listarla antes de cerrar `CC-01`. Carpetas vacías (p. ej. «Estados Financieros») se anotan como `PENDIENTE DE INFORMACIÓN DEL CLIENTE`.

### 2.1 Insumos

| Insumo | Uso |
|---|---|
| Organigrama general y por área | Segregación, líneas de reporte, ambiente de control (principios 3 y 4) |
| Políticas contables | Contraste con el marco y con la práctica observada |
| Manual de procesos | Inicio y fin de cada flujo, sistemas/módulos |
| Manual de funciones | Responsables y autorizaciones por cargo |
| Manual de procedimientos | Pasos del recorrido y controles clave declarados |
| Reportes (gerenciales, de sistema, de excepciones) | Monitoreo (componente 5) y controles detectivos |
| Estados financieros / balances | Contexto de saldos y riesgos por área |
| Documentación de TI (accesos, manuales del sistema) | ITGC (principio 11) |

Si un insumo no existe formalmente (frecuente en PYMES), no lo inventes: documenta con lo que haya y entrevista, y deja constancia de que no hay política formalizada — es en sí un hallazgo de ambiente de control.

### 2.2 Consejos prácticos para leer la carpeta

- **.docx**: usa `python-docx` (párrafos y tablas); `markitdown` puede devolver vacío. **PDF grandes**: `pdftotext`/`pypdf`. **.xlsm/.xlsx**: `openpyxl` con `keep_vba` solo para leer; revisa hojas, fechas y datos reales (clientes, RUC, saldos).
- **Secciones en imágenes**: si flujos o diagramas del manual son capturas (no hay texto extraíble), anótalo en SOL-01 y en la narrativa, califica solo lo textual y deja **«recorrido (walkthrough) pendiente»** — no inventes el flujo.
- **Nombres de archivo**: el puente al computador puede bloquear rutas con patrón 8.3 (`POLITI~1.PDF`) y fallar con tildes mal escritas. Si ocurre, pide al usuario renombrar el archivo y usa el nombre real listado.
- **Consistencia entre documentos**: contrasta cargos y nombres entre organigrama, directorio, manuales, hojas de trabajo y firmas. Cargos que no coinciden (p. ej. «Gerente de Compras y Comercialización» vs. organigrama) o firmantes ambiguos (iniciales o nombres parecidos) son hallazgos de ambiente de control (principio 3/5) o puntos a aclarar.
- **Archivos de trabajo activos** (hojas .xlsm con datos reales de conciliaciones, cartera, inventarios) son la mejor evidencia de implementación disponible sin ejecutar pruebas.

## 3. COSO 2013 — cinco componentes, 17 principios

| Componente | Principios |
|---|---|
| **1. Ambiente de control** | 1 integridad y valores éticos · 2 independencia y supervisión del directorio · 3 estructura, autoridad y responsabilidad · 4 competencia · 5 rendición de cuentas |
| **2. Evaluación de riesgos** | 6 objetivos claros · 7 identificación y análisis de riesgos · 8 riesgo de fraude · 9 cambios significativos |
| **3. Actividades de control** | 10 selección y desarrollo de controles · 11 controles generales de TI · 12 políticas y procedimientos |
| **4. Información y comunicación** | 13 información relevante y de calidad · 14 comunicación interna · 15 comunicación externa |
| **5. Supervisión** | 16 evaluaciones continuas e independientes · 17 comunicación y corrección de deficiencias |

`CI-00` evalúa los 17 principios una sola vez para toda la entidad, con evidencia citada en cada fila. Las áreas se evalúan en `MRC-01` y heredan el ambiente de control como contexto: un ambiente débil agrava, no sustituye, las deficiencias de un ciclo.

## 4. Áreas/ciclos por defecto

Ambiente de control y gobierno · Tesorería y bancos · Ventas, ingresos y cuentas por cobrar · Compras, egresos y cuentas por pagar · Inventarios y costos · Propiedad, planta y equipo · Nómina y talento humano · Tecnología de la información (ITGC) · Tributario · Legal, cumplimiento y partes relacionadas (+ cierre contable y reportes financieros si el cliente lo incluye). Ajusta al sector solo si el usuario lo confirma.

**Verificaciones por defecto en toda entidad** (revisa si aplican; documenta en MRC-01/CI-00/DEF-01):

- **Concentración y segregación de funciones**: una persona con funciones incompatibles (p. ej. contabilidad + tesorería; ventas + operaciones + control de calidad), sobre todo en empresas familiares.
- **Gobierno**: junta/directorio integrado por la misma familia o sin independientes (principio 2).
- **Partes relacionadas** (NIA 550, Sección 33 NIIF PYMES): relacionadas controladas fuera de la contabilidad o sin política de aprobación.
- **Proveedores de servicios tercerizados** (NIA 402): seguridad, nómina, TI, transporte, etc.
- **Canales informales de control**: autorizaciones por WhatsApp/chat, anulaciones de documentos autorizadas por quien contabiliza, reportes gerenciales sin elaborado/revisado/aprobado.
- **Bancarización**: cobros 100% en una sola entidad o efectivo no depositado.
- **Gobierno de TI**: Sistemas bajo un área sin independencia técnica; matriz de accesos, respaldos, cambios.
- **Reguladores sectoriales** (p. ej. combustibles: ARCH, Petroecuador; otros sectores según corresponda): cumplimiento y reportes obligatorios. Cita de forma genérica y marca el artículo como pendiente de verificación.

## 5. Metodología — el orden importa (NIA 315.25-26, NIA 330.8-17)

Para cada control clave: **1) narrativa y recorrido → 2) diseño → 3) implementación**. Solo un control con diseño adecuado **e** implementación confirmada pasa a **eficacia operativa** (muestreo), y esa prueba pertenece a la fase de ejecución, no a este papel: aquí queda «apto para prueba de eficacia en ejecución». Diseño inadecuado o no implementado ⇒ deficiencia (NIA 265), no se prueba.

**Escala de implementación**: `Sí` · `Parcial` · `Pendiente de evidencia` · `No` · `N/A`. **Aplica «Sí» solo si existe un archivo de trabajo activo o reporte con datos reales que lo demuestre** (p. ej. un .xlsm de conciliación bancaria con movimientos reales); descripción en un manual no basta. La escala de diseño es `Sí` · `Parcial` · `No`.

NIA 240.26 presume riesgo de fraude en ingresos: el ciclo de ventas siempre lleva evaluación antifraude. NIA 240.32(a): asientos manuales y cierre contable son de riesgo elevado por defecto.

## 6. Libro de Excel (independiente)

`CI-00 Revisión de Control Interno — <Cliente>.xlsx`, hojas en este orden:

| Hoja | Contenido |
|---|---|
| **Portada** | Membrete, logo (o `[LOGO PENDIENTE]`), cliente/RUC, marco, corte, alcance (incluida la regla multi-sitio), preparado/revisado/aprobado |
| **Índice** | Enlaces a cada hoja y su objetivo (titulada «ÍNDICE», sin repetir el código CI-00) |
| **T-Tablas** | Listas con nombre: SININA, ALTOMEDIOBAJO, TIPOCONTROL, NATURALEZA, FRECUENCIA (incluye Bienal), DISENO (Sí/Parcial/No), IMPLEMENT (Sí/Parcial/Pendiente de evidencia/No/N/A), CLASIFDEF, AREAS, y la tabla `TBL_RIESGO` (Alto=3, Medio=2, Bajo=1) |
| **SOL-01** | Checklist de la carpeta: insumo, ¿encontrado?, archivo, fecha, responsable, observaciones (imágenes, vacíos, pendientes) |
| **CI-00** | 17 principios: descripción, diseño, implementación, **documento fuente y referencia exacta**, evidencia, conclusión por fórmula |
| **MRC-01** | Matriz de riesgos y controles por área: área, proceso, riesgo, aseveración, control clave, tipo, naturaleza, frecuencia, ¿clave?, diseño, implementación, documento fuente, conclusión por fórmula, referencia a narrativa |
| **NA-01** | **Una sola hoja «Narrativas por área»** con un bloque apilado por área (objetivo y vínculo con EEFF/sistemas/responsables/segregación · políticas · riesgos y controles con enlace a MRC-01 · conclusión del área), citando el documento fuente. Hojas NA-01…NA-n separadas solo si el cliente o el auditor lo piden. El recorrido de ocho pasos se completa cuando haya walkthrough; si los flujos son imágenes, queda marcado como pendiente |
| **DEF-01** | Deficiencias NIA 265: área, componente COSO, descripción, **evidencia/documento fuente**, probabilidad, impacto, clasificación por fórmula, recomendación, respuesta de la gerencia, fecha |
| **CC-01** | Conclusión: semáforo por componente COSO y por área, enfoque de auditoría por área, conclusión narrativa obligatoria |
| **Normativa** | COSO 2013, NIA 315/265/330/240/402/550 con título completo, secciones NIIF PYMES citadas (4, 11, 13, 17, 22, 23, 28, 29, 33 según aplique) o equivalentes de NIIF completas |

## 7. Fórmulas — nada se escribe a mano

Usa `INDEX`/`MATCH`, `VLOOKUP` sobre `TBL_RIESGO`, `COUNTIF(S)`, `SUMPRODUCT`, `IFERROR`. Evita `XLOOKUP`, `FILTER`, `SORT`, `UNIQUE` y matriciales (LibreOffice no las evalúa).

- **Conclusión de control en CI-00** (D=diseño, E=implementación): `=IF(D="","",IF(AND(D="Sí",E="Sí"),"Diseñado e implementado",IF(D="No","Deficiencia — no se prueba (NIA 265)","Diseño parcial o implementación no confirmada — fortalecer antes de prueba de eficacia")))`.
- **Conclusión de control en MRC-01** (J=diseño, K=implementación): `=IF(J="","",IF(J="No","Deficiencia — no se prueba (NIA 265)",IF(K="Sí","Apto para prueba de eficacia en ejecución",IF(K="N/A","Diseño evaluado — implementación no aplica","Pendiente de evidencia de implementación — no se prueba hasta confirmar"))))`. Debe manejar siempre `Pendiente de evidencia` y `N/A`.
- **Nivel de riesgo**: matriz 3×3, producto ≥6 Alto, 3-4 Medio, 1-2 Bajo, con semáforo condicional.
- **Clasificación de deficiencia (DEF-01)**: producto probabilidad×impacto con `VLOOKUP(...,TBL_RIESGO,2,FALSE)`: ≥6 ⇒ «Posible debilidad material — REQUIERE REVISIÓN DEL AUDITOR RESPONSABLE»; 3-4 ⇒ «Deficiencia significativa»; 1-2 ⇒ «Deficiencia». La fórmula propone; la debilidad material la decide siempre el auditor responsable.
- **Enfoque por área (CC-01)**: si no hay controles, vacío; si controles con deficiencia ≥34% ⇒ «Sustantivo ampliado»; si hay alguno con deficiencia ⇒ «Sustantivo»; si aptos ≥50% ⇒ «Confianza en controles — sujeta a prueba de eficacia en ejecución»; en otro caso ⇒ «Pendiente de confirmar en ejecución — mayoría de controles con implementación no confirmada». No ser optimista cuando la implementación está pendiente.
- La tabla de componentes COSO en CC-01 se calcula con `COUNTIF/COUNTIFS` sobre CI-00.

## 8. Formato (idéntico a `entregables-globalauditors`)

Membrete GLOBALAUDITORS CÍA. LTDA. · RUC 1791771745001 en cada hoja; logo o `[LOGO PENDIENTE]` (un papel de cliente real se entrega solo con logo o con ese marcador explícito declarado al usuario). Paleta, tipografía y formato según `formatos_referencias/ESPECIFICACION_FORMATO.md` (Open Sans; azul `0E2C59` + dorado `FFB600`; títulos 12, resto 10). Celdas: **amarillo `FFF2CC`** = insumo del auditor · **gris `F2F2F2`** = fórmula · **celeste `D9E2F3`** = referencia de metodología · semáforo `C6EFCE`/`FFEB9C`/`FFC7CE`.

Estructura de cada hoja: fila 1 membrete, fila 2 código + título (banda dorada), fila 3 referencia normativa (celeste), fila 4 metadatos (cliente/RUC/corte/preparado), fila 6 encabezados navy. Pie «Hecho por · Revisado por · Aprobado por · Fecha». Impresión horizontal, `fitToWidth=1`, `fitToHeight=0`.

**Trampas de impresión y estructura**: en hojas con bloques que fluyen (NA-01, CC-01) los `print_title_rows` y el `freeze_panes` deben ser `1:4` y `A5`, no `1:6`/`A6`, o se repite un título de sección obsoleto en cada página. Portada y T-Tablas también en horizontal con ajuste a página. `header()` con menos de 4 columnas necesita una rama de fila 1 combinada. Las listas de validación deben incluir todos los valores que escriben tus datos (p. ej. «Pendiente de evidencia»). Mantén el membrete corto para que no se trunque.

## 9. Construcción y verificación

Sigue `xlsx`: fórmulas reales, recálculo con `scripts/recalc.py`, **cero errores** antes de entregar. Un recálculo limpio prueba que evalúan, no que sean correctas: siembra 2-3 casos (diseño inadecuado; diseño adecuado sin implementación; control apto) y confirma que conclusión, deficiencia y enfoque encadenan de punta a punta. Convierte a PDF, pasa a JPEG con `pdftoppm` y revisa visualmente cada hoja; haz la auditoría de marca (membrete en todas; sin títulos obsoletos; sin texto truncado). Corrige defectos y repite.

## 10. Entrega

Un libro por cliente, entregado con `SendUserFile` (el archivo lo genera un script) y, si hay carpeta conectada, escrito en ella. No repitas el contenido del archivo en el chat; informa:

1. Qué insumos de 2.1 se encontraron y cuáles quedaron pendientes (carpetas vacías, secciones en imagen, documentación de TI).
2. Los hallazgos reales, cada uno con su documento fuente: componentes débiles, controles sin diseño o sin implementar, posibles debilidades materiales.
3. El enfoque de auditoría por área para la fase de ejecución.
4. Las decisiones del auditor responsable y los pendientes del encargo: logo, revisado/aprobado, walkthroughs de procedimientos en imagen, cargos o nombres por aclarar entre documentos.