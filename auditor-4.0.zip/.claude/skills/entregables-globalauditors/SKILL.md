---
name: entregables-globalauditors
description: "Usar al crear cualquier entregable de GLOBALAUDITORS CÍA. LTDA. (Excel o Word; sin PDF): aplica la identidad de la firma, su paleta, el logotipo, los datos institucionales y el ciclo obligatorio de verificación visual."
---

# Entregables de GLOBALAUDITORS

Todo archivo que salga de la firma —papel de trabajo, informe, carta, manual o presentación— lleva la misma identidad. Esta habilidad define esa identidad y el procedimiento de verificación que ningún entregable puede saltarse.

## Datos institucionales (verbatim, nunca abreviar ni reescribir)

| Campo | Valor |
|---|---|
| Firma | GLOBALAUDITORS CÍA. LTDA. |
| RUC | 1791771745001 |
| Socio principal | Dr. William Morales |
| Gerente general | Lcda. Emilia Moreira |
| Ciudad / país | Ecuador (Quito salvo indicación contraria) |

El membrete estándar es: `GLOBALAUDITORS CÍA. LTDA.  ·  RUC 1791771745001`.

## Tipografía y paleta (Manual de Marca Global Auditors 2019)

- Tipografía: **Open Sans**. Tamaños: **títulos 12, resto 10** (Excel y Word).
- Azul marino `0E2C59` = color principal (títulos, rellenos de resultado, filetes).
- Dorado `FFB600` = único acento (encabezados de tabla, cifras destacadas).
- Bandas suaves: `DCE3EE` (azul claro) y `FFF0C2` (dorado claro).
- Formato del papel: `formatos_referencias/ESPECIFICACION_FORMATO.md`.

Semáforo en papeles de trabajo: verde `C6EFCE`/`006100`, ámbar `FFEB9C`/`9C6500`, rojo `FFC7CE`/`9C0006`.

## Convención de colores en Excel (no negociable)

- **Amarillo `FFF2CC`** = celda de ingreso manual del auditor.
- **Gris `F2F2F2`** = celda calculada por fórmula o traída por vínculo. Nunca se escribe encima.
- **Celeste `D9E2F3`** = rótulo o dato de referencia de la metodología.
- **Dorado `FFB600`** con texto azul `0E2C59` = encabezado de tabla; **azul `0E2C59`** con texto dorado = columnas Ref. y resultados.
- **Semáforo** = evaluación automática; es una conclusión que el sistema propone.

Documentar esta convención en el propio entregable siempre que el destinatario sea el equipo.

## Logotipo

Los logos ya preparados están en `firmas/globalauditors/`: `logo_transparente.png` (fondos claros), `logo_blanco.png` (fondos azul marino) y `logo.png` (fondo blanco, encabezado de Excel). Úsalos directamente. Si cambia el logo oficial, se preparan así:

1. Recortar el contenido con una máscara de no-blanco (`rgb.min(axis=2) > 232` es fondo).
2. `logo_trans.png` — fondo transparente, para fondos claros.
3. `logo_white.png` — los píxeles oscuros pasan a blanco y el dorado se conserva, para fondos azul marino.
4. Recortar ambos a su `getbbox()`.

Tamaños que funcionan: 146×46 px (fila 1 de Excel), 127×40 (encabezado Word), 285×90 (portadas Excel), 476×150 (portadas Word y PPT).

**Si no hay logo disponible en el entorno, pedirlo al usuario antes de construir** — no inventar un sustituto ni omitirlo.

## Reglas por formato

### Excel (openpyxl)
- Filas 1–4 son el encabezado del papel: membrete + logo (fila 1, alto 36), código y título sobre banda azul, referencia normativa sobre celeste, y una fila calculada con cliente / RUC / período / marco.
- `print_title_rows = "1:4"`, `oddHeader` con firma y RUC, `oddFooter` con «Página &P de &N», orientación horizontal, `fitToWidth = 1`.
- Pie de control «Hecho por · Revisado por · Aprobado por» con fecha en cada papel.
- Consolidar las validaciones de datos idénticas en un solo objeto con varios rangos: miles de objetos `DataValidation` inflan el archivo.

### Word (docx de npm)
- Encabezado: `ImageRun` del logo 127×40 + tabulación + título, línea con firma y RUC debajo, borde inferior.
- `titlePage: true` con encabezados `first` y `default` distintos.
- Portada con el logo grande 340×107 y el bloque de firma y RUC.
- Tablas: `columnWidths` **y** ancho por celda en DXA, o el ajuste se rompe.

### PowerPoint (pptxgenjs)
- `pres.layout = 'LAYOUT_WIDE'` (13,333 × 7,5"), margen 0,62".
- Títulos en Cambria negrita 30 pt sobre kicker dorado en versalitas; cuerpo en Calibri 10–13 pt.
- Estructura sándwich: portada, divisores de parte y cierre en `navyD`; contenido sobre blanco.
- Motivo repetido: insignia circular dorada numerada + tarjetas `roundRect` con relleno `card` y sombra suave. **Nunca franjas ni líneas de acento** bajo los títulos.
- Decoración: círculos concéntricos (uno relleno en `navy`, otro solo contorno dorado) en la esquina de las láminas oscuras. Verificar que no crucen el logotipo.
- Pie en todas las láminas: logo pequeño + `Proyecto … · GLOBALAUDITORS CÍA. LTDA. · RUC 1791771745001` + número dorado a la derecha.
- **El contenido termina en y ≤ 6,50"**; el pie ocupa de 6,98" hacia abajo. Es la causa número uno de solapamientos.
- Notas del orador en `slide.addNotes()`, nunca en una caja de texto de la lámina.

## Verificación obligatoria antes de entregar

1. **Excel**: recalcular con `soffice --headless --convert-to xlsx`, recargar con `openpyxl(data_only=True)` y buscar valores que contengan `#REF!`, `#VALUE!`, `#DIV/0!`, `#NAME?`, `#N/A`, `#NUM!`. Filtrar el falso positivo del rótulo `#` de la columna de numeración.
2. **PPTX**: `python /mnt/skills/public/pptx/scripts/office/validate.py deck.pptx` — debe decir «All validations PASSED».
3. **Visual**: convertir a PDF y a imágenes (`pdftoppm -jpeg -r 110`) y **mirar cada lámina o página**. Delegar la revisión a un subagente da mejor resultado que revisarlas uno mismo después de escribir el código. Buscar solo defectos objetivos: texto cortado o desbordado, elementos solapados, contenido que pisa el pie, bajo contraste.
4. **Auditoría de marca**: recorrer todas las hojas o láminas y confirmar que cada una tiene logo y membrete de impresión.
5. Entregar solo el archivo editable (Excel o Word). **No se entregan PDF** (política de la firma); el PDF se usa únicamente como paso interno de la verificación visual.

## Idioma y tono

Todo en español de Ecuador, registro profesional y directo. Números con separador de miles por punto y decimal por coma (`7.796`, `8,0 %`). Evitar anglicismos cuando exista término en español: «papel de trabajo», «recorrido» o «prueba de recorrido» (no *walkthrough*, salvo entre paréntesis la primera vez), «hallazgo», «cédula».