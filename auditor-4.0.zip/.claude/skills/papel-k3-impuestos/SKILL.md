---
name: papel-k3-impuestos
description: >
  Automatiza el llenado del papel de trabajo tributario K-3 (IVA y Retenciones; 18 hojas: A-1,
  K-1, K-1.1, K-2, K-3.1 a K-3.12, Marcas) usado en auditoria de estados financieros. USAR SIEMPRE
  que el usuario mencione "papel de trabajo de impuestos", "K-3", "conciliacion de IVA",
  "ANEXO A4", "revision tributaria", comparta un archivo llamado K-3_Impuestos_Modelo.xlsx (o
  similar), o pida cruzar Formulario 104/103, ATS, mayores contables y balance contra libros para
  una auditoria. Tambien usar si el usuario pide "automatizar el papel de impuestos" o "llenar el
  modelo" para un nuevo cliente o periodo.
---

# Papel de trabajo K-3 - Impuestos (IVA y Retenciones)

## Que es esto

Un papel de trabajo de auditoria financiera (NO una declaracion tributaria) cuyo unico objetivo es
responder: **¿lo que el cliente registro en su contabilidad (libros) es lo mismo que declaro al SRI?**
Sirve para probar la aseveracion de Existencia/Integridad/Valuacion del pasivo y gasto de impuestos
en los estados financieros, y para detectar contingencias tributarias no reveladas.

**Regla de oro: NUNCA se modifica la estructura del modelo.** No se agregan, eliminan ni renombran
hojas. No se tocan formulas existentes, ni siquiera las que tienen errores conocidos (ver
`references/defectos_conocidos_del_modelo.md`) -- esos defectos se documentan con un comentario en
la celda, nunca se corrigen sin autorizacion explicita del usuario.

**Regla de oro #2: cero materialidad.** A diferencia de una auditoria financiera, este papel no
descarta diferencias por ser pequeñas. El SRI no tolera margenes. Toda diferencia se muestra tal
cual; el auditor decide manualmente si la marca "i" (inmaterial, ver hoja Marcas) con su propia
justificacion escrita. La automatizacion nunca aplica un umbral.

**Regla de oro #3: no asumir nada.** Tarifas de IVA, regimen tributario, normativa contable (NIIF
Full vs PYMES), y cualquier parametro similar SIEMPRE se confirman con el usuario o se leen de un
documento real -- nunca se asumen por "lo tipico" o por un valor historico. Ejemplo real de este
error: se asumio 12% de IVA (tarifa historica de Ecuador) cuando la tarifa real vigente era 15%; se
detecto solo al verificar aritmeticamente (impuesto generado / base neta) contra la declaracion real.

## Flujo de trabajo para un cliente/periodo nuevo

1. **Confirmar con el usuario** (nunca asumir): normativa contable (NIIF Full o PYMES), regimen
   tributario, tarifa de IVA vigente, y el archivo modelo a usar (si no se especifica, usar el mas
   reciente que el usuario haya compartido en la conversacion).
2. **Leer `references/mapa_hojas.md`** -- tabla completa de que hoja recibe que dato, de que fuente,
   y con que formula exacta. Es la referencia principal para saber donde va cada numero.
3. **Solicitar progresivamente los documentos**, un tipo a la vez si el usuario no los ha compartido
   todos: primero Formulario 104 y 103 de cada mes, luego ATS, luego mayores contables (Activos,
   Pasivos, Ingresos, Costos y Gastos), luego Balance General. No pedir de una vez todo si el usuario
   prefiere ir por partes -- seguir su ritmo.
4. **Correr los parsers** (`scripts/`) sobre cada documento para extraer los datos en JSON. Ver
   `scripts/README.md` para el uso de cada uno.
5. **Validar cada dato contra una fuente independiente antes de usarlo** -- nunca copiar un numero de
   la declaracion a la columna de "libros" sin verificar primero que existe un dato de libros
   genuinamente independiente. Ejemplo de error ya cometido y corregido: la columna de "retenciones
   IVA del periodo" en K-3.1 se llenaba con el mismo valor de la declaracion (circular, la diferencia
   siempre daba cero sin probar nada) hasta encontrar la fuente real en el mayor de Activos
   (cuentas 101050201-205, asiento "CIERRE").
6. **Llenar el modelo** usando `scripts/fill_model_template.py` como punto de partida (ajustar los
   valores de entrada, no la logica de escritura de celdas).
7. **Recalcular con LibreOffice** (`/mnt/skills/public/xlsx/scripts/recalc.py`) y confirmar que el
   conteo de errores `#REF!`/`#VALUE!` no aumento respecto al modelo original en blanco (los errores
   preexistentes en A-1/K-1/K-1.1/K-3.11/K-3.12 son del modelo, no se corrigen).
8. **Reportar al usuario, hoja por hoja**: que se lleno con certeza, que quedo pendiente y por que
   (nunca ocultar un vacio ni inventar un numero para llenarlo), y que hallazgos aparecieron
   (diferencias, anomalias de control, defectos de formula encontrados).

## Hojas ocultas -- no llenar salvo instruccion explicita

A-1 Balance General (x2), K-1 GTOS ACUMULADOS, K-1.1 Hoja Resumen, K-2 Programa de trabajo,
K-3.11 Contribucion Temporal y K-3.12 Calculo Anticipado IR vienen **ocultas** en el modelo. No
llenarlas por defecto. Excepcion: K-1.1 filas especificas que K-3.10 referencia por formula (ver
`references/mapa_hojas.md`, seccion K-3.10) si necesitan un valor para que esa hoja visible funcione.

## Fuentes de datos esperadas (nomenclatura sugerida de archivos)

```
{CLIENTE}_F104_{MM}{AAAA}.pdf          Formulario 104, un archivo por mes
{CLIENTE}_F103_{MM}{AAAA}.pdf          Formulario 103, un archivo por mes
{CLIENTE}_ATS_{MM}{AAAA}.xlsx          Detalle XML del ATS, un archivo por mes
{CLIENTE}_MAYOR_ACTIVOS.xlsx           Mayor contable, todos los meses en un archivo
{CLIENTE}_MAYOR_PASIVOS.xlsx           idem
{CLIENTE}_MAYOR_INGRESOS.xlsx          idem
{CLIENTE}_MAYOR_GASTOS.xlsx            idem
{CLIENTE}_BALANCE_GENERAL.xlsx         Balance comparativo, todos los meses
{CLIENTE}_RETENCIONES_EMITIDAS.xlsx    Reporte de comprobantes de retencion IVA, todos los meses
```

Si el usuario entrega archivos con nombres distintos, usarlos igual -- esta nomenclatura es un
punto de partida sugerido, no un requisito bloqueante.

## Que hace la IA sola vs. que queda para el auditor

| Automatizado | Manual (el auditor decide) |
|---|---|
| Extraer casilleros de PDF/XML (parsers) | Confirmar la tarifa de IVA vigente si hay ambiguedad |
| Ubicar asientos "CIERRE" en los mayores | Marcar "i" (inmaterial) con su propia justificacion |
| Llenar celdas de entrada (input) del modelo | Redactar la conclusion narrativa de cada hoja |
| Calcular diferencias (las formulas del modelo ya existen) | Decidir si una diferencia es hallazgo de control o error real |
| Detectar patrones atipicos (ej. asiento que no cancela saldo anterior) | Autorizar corregir un defecto de formula del modelo |

## Documentos de referencia de esta skill

- `references/mapa_hojas.md` -- que hoja recibe que dato, de que fuente, formula exacta de cada
  seccion. Leer siempre antes de llenar una hoja por primera vez.
- `references/defectos_conocidos_del_modelo.md` -- lista de errores de diseño ya encontrados en el
  modelo (formulas que excluyen columnas, rangos SUM incompletos, comparaciones circulares) que se
  deben preservar y solo documentar, no corregir.
- `references/notas_oficiales_k31.md` -- transcripcion de las notas (a) a (k) del propio modelo para
  K-3.1, que definen el significado exacto de cada columna.
- `scripts/` -- los 4 parsers (F.104, F.103, ATS, mayor) mas el script de llenado, todos probados
  contra documentos reales.
