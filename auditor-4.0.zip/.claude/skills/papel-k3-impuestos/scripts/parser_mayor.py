"""
parser_mayor.py
================
Busca, para una cuenta contable y un archivo de mayor dados, el asiento de
CIERRE mensual ("CIERRE IMPUESTOS MES <MES> <ANIO>") que es el que realmente
concilia contra el Formulario 104 -- NO el total bruto de movimientos de la
cuenta (que incluye reversiones, notas de credito y otros ajustes que se
netean antes del cierre).

Hallazgo que motiva este script (NOVISOLUTIONS, ene-jun 2026, validado 6/6 meses):
    cuenta 101050101 "IVA Compra (500)":
        credito del asiento CIERRE  -  F104.casillero(523)  [+/- ajustes 526/527]
        = F104.casillero(520)                                   (exacto, +/-0.01)

Uso:
    python parser_mayor.py mayor.xlsx --cuenta 101050101 [--hoja "Nombre hoja"]
"""
import json
import argparse
import openpyxl
from collections import defaultdict


def find_cierre_entries(path: str, cuenta: int, hoja: str = None,
                         col_codigo: int = 1, col_mes: int = None,
                         col_memo: int = None, col_debito: int = None,
                         col_credito: int = None, header_row: int = 14) -> dict:
    """
    Los mayores de NOVISOLUTIONS usan esta disposicion (fila de encabezado ~14):
    0 Grupo, 1 Codigo, 2 Nombre Cuenta, ... Mes, ... Memo, ... Debito, Credito, Saldo
    Si el archivo tiene otra disposicion, pasar los indices de columna manualmente.
    """
    wb = openpyxl.load_workbook(path, data_only=True, read_only=True)
    sheetnames = [hoja] if hoja else wb.sheetnames

    resultados = defaultdict(dict)
    for sn in sheetnames:
        if sn not in wb.sheetnames:
            continue
        ws = wb[sn]
        # Detectar encabezado automaticamente si no se paso
        headers = None
        for row in ws.iter_rows(min_row=1, max_row=20, values_only=True):
            if row and row[0] == "Grupo" and "Codigo" in row:
                headers = row
                break
        if headers is None:
            continue
        idx = {h: i for i, h in enumerate(headers) if h}
        c_mes = col_mes if col_mes is not None else idx.get("Mes")
        c_memo = col_memo if col_memo is not None else idx.get("Memo Contable")
        c_deb = col_debito if col_debito is not None else idx.get("Débito", idx.get("Debito"))
        c_cred = col_credito if col_credito is not None else idx.get("Crédito", idx.get("Credito"))

        for row in ws.iter_rows(min_row=header_row + 1, max_row=ws.max_row, values_only=True):
            if len(row) <= max(col_codigo, c_mes or 0, c_memo or 0):
                continue
            if row[col_codigo] != cuenta:
                continue
            memo = row[c_memo] if c_memo is not None else None
            if memo and "CIERRE" in str(memo).upper():
                mes = row[c_mes]
                resultados[mes] = {
                    "memo": memo,
                    "debito": row[c_deb] if c_deb is not None else None,
                    "credito": row[c_cred] if c_cred is not None else None,
                    "hoja": sn,
                }
    return dict(resultados)


def main():
    ap = argparse.ArgumentParser(description="Localiza asientos de cierre mensual en el mayor contable")
    ap.add_argument("xlsx")
    ap.add_argument("--cuenta", type=int, required=True, help="Codigo de cuenta contable, ej. 101050101")
    ap.add_argument("--hoja", default=None, help="Nombre de hoja especifica (opcional, busca en todas si se omite)")
    ap.add_argument("--json", default=None)
    args = ap.parse_args()

    data = find_cierre_entries(args.xlsx, args.cuenta, hoja=args.hoja)
    print(json.dumps(data, indent=2, ensure_ascii=False))
    if args.json:
        with open(args.json, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)


if __name__ == "__main__":
    main()
