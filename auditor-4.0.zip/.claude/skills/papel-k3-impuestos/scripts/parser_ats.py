"""
parser_ats.py
================
Procesa el detalle transaccional del ATS (formato Excel derivado del XML
que se sube al SRI) y produce un resumen por tipo de comprobante,
aplicando la REGLA DE AGREGACION validada con evidencia real:

    Un comprobante puede aparecer en varias filas del detalle XML
    (ej. reembolsos con proveedores anidados). Sumar linea por linea
    duplica el valor. La regla correcta es agrupar primero por
    comprobante UNICO (establecimiento + puntoEmision + secuencial)
    y tomar el valor de cabecera una sola vez por comprobante.
    Esto aplica a TODOS los tipos de comprobante, no solo reembolsos
    (confirmado por el cliente).

Uso:
    python parser_ats.py archivo.xlsx [--json salida.json]

Salida: resumen de compras por tipo de comprobante (Bi 0%, Bi 12%, IVA),
y el neto de la base gravada 12% segun la formula validada:
    BI12_neto = suma(tipo 01,03,05,41) - suma(tipo 04)
"""
import json
import argparse
import openpyxl
from collections import defaultdict

TIPO_LABELS = {
    1: "Factura", 2: "Nota de venta", 3: "Liquidacion de compra",
    4: "Notas de credito", 5: "Notas de debito", 11: "Pasajes aviacion",
    18: "Documentos autorizados en ventas", 19: "Comprobantes pago cuotas/aporte",
    20: "Servicios instituciones del Estado", 41: "Comprobante venta por reembolso",
    42: "Retencion presuntiva",
}

# Tipos de comprobante que suman a la base "compras tarifa 12% con derecho a credito"
# segun la regla validada; el tipo 04 (notas de credito) se resta.
BASE_12_SUMA = (1, 3, 5, 41)
BASE_12_RESTA = (4,)


def dedup_and_aggregate(path: str) -> dict:
    wb = openpyxl.load_workbook(path, data_only=True, read_only=True)
    ws = wb[wb.sheetnames[0]]
    headers = [c.value for c in next(ws.iter_rows(min_row=1, max_row=1))]
    idx = {h: i for i, h in enumerate(headers) if h}

    required = ["idProv", "tipoComprobante", "establecimiento", "puntoEmision",
                "secuencial", "baseImponible", "baseImpGrav", "montoIva"]
    missing = [r for r in required if r not in idx]
    if missing:
        raise ValueError(f"Faltan columnas esperadas en el ATS: {missing}")

    seen = set()
    por_tipo = defaultdict(lambda: {"n_comprobantes": 0, "bi0": 0.0, "bi12": 0.0, "iva": 0.0})

    for row in ws.iter_rows(min_row=2, max_row=ws.max_row, values_only=True):
        id_prov = row[idx["idProv"]]
        if id_prov in (None, ""):
            continue  # fila de ventas u otra seccion, no es compra
        tipo = row[idx["tipoComprobante"]]
        key = (row[idx["establecimiento"]], row[idx["puntoEmision"]], row[idx["secuencial"]])
        if key in seen:
            continue
        seen.add(key)
        por_tipo[tipo]["n_comprobantes"] += 1
        por_tipo[tipo]["bi0"] += row[idx["baseImponible"]] or 0
        por_tipo[tipo]["bi12"] += row[idx["baseImpGrav"]] or 0
        por_tipo[tipo]["iva"] += row[idx["montoIva"]] or 0

    resumen_por_tipo = {}
    for tipo, vals in por_tipo.items():
        label = TIPO_LABELS.get(tipo, f"Tipo {tipo}")
        resumen_por_tipo[str(tipo)] = {"label": label, **{k: round(v, 2) for k, v in vals.items()}}

    bi12_suma = sum(por_tipo[t]["bi12"] for t in BASE_12_SUMA if t in por_tipo)
    bi12_resta = sum(por_tipo[t]["bi12"] for t in BASE_12_RESTA if t in por_tipo)
    iva_suma = sum(por_tipo[t]["iva"] for t in BASE_12_SUMA if t in por_tipo)
    iva_resta = sum(por_tipo[t]["iva"] for t in BASE_12_RESTA if t in por_tipo)

    return {
        "archivo": path,
        "por_tipo_comprobante": resumen_por_tipo,
        "base_12_neta_compras": round(bi12_suma - bi12_resta, 2),
        "iva_12_neto_compras": round(iva_suma - iva_resta, 2),
        "nota_metodologica": (
            "Base y IVA netos = suma(tipos 01,03,05,41) - tipo 04, deduplicado por "
            "comprobante unico (establecimiento+puntoEmision+secuencial). "
            "Esta cifra es INFORMATIVA: la que determina el impuesto es libros vs "
            "declaracion F.104, no ATS vs declaracion (ver hallazgo de auditoria)."
        ),
    }


def main():
    ap = argparse.ArgumentParser(description="Parser/agregador del ATS con regla de comprobante unico")
    ap.add_argument("xlsx")
    ap.add_argument("--json", default=None)
    args = ap.parse_args()
    data = dedup_and_aggregate(args.xlsx)
    print(json.dumps(data, indent=2, ensure_ascii=False))
    if args.json:
        with open(args.json, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)


if __name__ == "__main__":
    main()
