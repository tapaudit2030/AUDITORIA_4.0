# Scripts de extraccion -- probados contra documentos reales

Todos requieren `pip install pdfplumber openpyxl --break-system-packages` (openpyxl normalmente ya
esta disponible).

## parser_f104.py -- Formulario 104 (IVA)

```bash
python parser_f104.py ruta/al/F104_enero.pdf --json salida.json
```

Devuelve razon social, RUC, periodo, tipo/estado de declaracion, y un diccionario `casilleros` con
los valores numericos de cada casillero relevante (419, 421, 503, 504, 520-527, 605-625, 699,
721-731, 799, 859, etc.).

**Antes de confiar en el resultado**: verificar que `casilleros["421"] / casilleros["419"]` (o
`411`) reproduce la tarifa de IVA que el usuario confirmo -- si no coincide, algo salio mal en la
extraccion o la tarifa es distinta a la esperada.

## parser_f103.py -- Formulario 103 (Retenciones Renta)

```bash
python parser_f103.py ruta/al/F103_enero.pdf --json salida.json
```

Devuelve casilleros 302, 349, 497, 499, 500, 501. Verificacion cruzada automatica sugerida:
`casilleros["497"]` debe coincidir con `f104_casilleros["503"] + f104_casilleros["504"]` del mismo
mes -- si no coincide, investigar antes de continuar (puede ser un cliente distinto sin esta
regularidad, no asumir que aplica siempre).

## parser_ats.py -- ATS (detalle transaccional XML/Excel)

```bash
python parser_ats.py ruta/al/ATS_enero.xlsx --json salida.json
```

Aplica la regla de **comprobante unico** (agrupa por establecimiento+puntoEmision+secuencial antes
de sumar, para no duplicar comprobantes con detalle anidado como reembolsos). Devuelve un resumen
por tipo de comprobante y la base/IVA neto de compras tarifa gravada (codigos 01+03+05+41-04).

**Si el archivo tiene columnas distintas** (nombres de campo diferentes a `idProv`,
`tipoComprobante`, `baseImponible`, `baseImpGrav`, `montoIva`, `establecimiento`, `puntoEmision`,
`secuencial`), el script fallara con un error claro listando las columnas faltantes -- no adivinar
un mapeo, pedir al usuario que confirme la estructura del archivo.

## parser_mayor.py -- Mayor contable (ubicar asientos de cierre)

```bash
python parser_mayor.py ruta/al/mayor.xlsx --cuenta 101050101 --hoja "Nombre de hoja opcional"
```

Busca, para una cuenta especifica, las lineas cuyo memo contable incluya la palabra "CIERRE" -- que
en los mayores de este tipo de cliente suelen ser el asiento que realmente concilia contra la
declaracion (a diferencia del movimiento bruto de la cuenta, que incluye reversiones y ajustes).

**Advertencia real ya encontrada**: no todos los meses siguen el mismo patron de 2 lineas
(debito=nuevo saldo, credito=cancela saldo anterior). En un caso real, un mes especifico solo tuvo
una linea de debito sin la de credito -- eso fue una anomalia de control real del cliente, no un
error del script. Si un mes no sigue el patron esperado, reportarlo como hallazgo, no forzar un
numero.

**Si el archivo es grande** (varios cientos de miles de filas), pasar `--hoja` con el nombre exacto
de la hoja para evitar recorrer hojas irrelevantes y que el proceso tarde demasiado.

## Flujo sugerido

1. Correr los 4 parsers sobre los documentos del periodo, guardando cada salida en JSON.
2. Consolidar manualmente (o con un script propio del proyecto) los JSON en un solo diccionario con
   la estructura que espera el llenado del modelo (ver `mapa_hojas.md` para que campo va donde).
3. Antes de escribir cualquier valor en el Excel, aplicar las verificaciones cruzadas mencionadas
   arriba (tarifa, 497=503+504, comprobante unico, etc.).
4. Escribir los valores en el archivo modelo respetando exactamente su estructura (ver SKILL.md,
   reglas de oro). No hay un script generico de "llenado" incluido aqui porque el mapeo de columnas
   cambia segun que hojas apliquen para cada cliente (ver limitaciones documentadas en
   `mapa_hojas.md` para K-3.2, K-3.6, etc.) -- escribir el llenado especifico para cada caso,
   siguiendo el mapa como referencia.
