"""
parser_f104.py
================
Extrae los casilleros clave del Formulario 104 (Declaracion de IVA) del SRI
a partir del PDF de la declaracion.

Uso:
    python parser_f104.py archivo.pdf [--json salida.json]

Casilleros extraidos (los que alimentan el papel de trabajo K-3, validados
contra NOVISOLUTIONS enero-junio 2026):
    Identificacion, razonSocial, periodoFiscal, tipoDeclaracion, estado
    401,402,403,404,405,406,407,408,409  (ventas bruto)
    411,413,415,417,419                  (ventas neto)
    421,429                              (IVA generado en ventas)
    500,501,502,503,504,505,506,507,508,509  (compras bruto)
    510,511,512,513,514,517,518,519          (compras neto)
    520,521,523,524,527                      (IVA en compras)
    563,564,565                          (factor proporcionalidad / credito)
    605,606,609                          (saldo credito tributario mes anterior + retenciones recibidas)
    615,617,618,619                      (saldo credito tributario proximo mes)
    699,721,723,725,727,729,731,799,801,859   (retenciones IVA efectuadas / total consolidado)

Nota importante de metodologia (confirmada con evidencia real):
  - El casillero 497 del F.103 (Retenciones en la Fuente) SIEMPRE coincide
    exactamente con 503+504 de este formulario (importaciones). Si se cruza
    contra F.103, usar esa regla, no una suma parcial.
"""
import re
import sys
import json
import argparse

try:
    import pdfplumber
except ImportError:
    pdfplumber = None

# Mapa casillero -> etiqueta amigable (para el Excel)
CASILLERO_LABELS = {
    "401": "Ventas locales tarifa dif. 0% (bruto)",
    "411": "Ventas locales tarifa dif. 0% (neto)",
    "419": "Total ventas neto",
    "421": "IVA generado ventas tarifa dif. 0%",
    "429": "Total IVA generado ventas",
    "500": "Compras tarifa dif. 0% con derecho (bruto)",
    "510": "Compras tarifa dif. 0% con derecho (neto)",
    "501": "Compras activo fijo (bruto)",
    "511": "Compras activo fijo (neto)",
    "503": "Importacion servicios (bruto)",
    "513": "Importacion servicios (neto)",
    "504": "Importacion bienes (bruto)",
    "514": "Importacion bienes (neto)",
    "520": "IVA compras tarifa dif. 0%",
    "521": "IVA compras activo fijo",
    "523": "IVA importacion servicios",
    "524": "IVA importacion bienes",
    "527": "Ajuste negativo NC import (credito)",
    "563": "Factor de proporcionalidad",
    "564": "Credito tributario aplicable",
    "605": "Saldo CT mes anterior - compras",
    "606": "Saldo CT mes anterior - retenciones",
    "609": "Retenciones IVA recibidas en el periodo",
    "615": "Saldo CT proximo mes - compras",
    "617": "Saldo CT proximo mes - retenciones",
    "699": "Total impuesto a pagar por percepcion",
    "721": "Retencion IVA 10%",
    "723": "Retencion IVA 20%",
    "725": "Retencion IVA 30%",
    "727": "Retencion IVA 50%",
    "729": "Retencion IVA 70%",
    "731": "Retencion IVA 100%",
    "799": "Total impuesto retenido (agente)",
    "801": "Total a pagar por retencion",
    "859": "TOTAL CONSOLIDADO IVA",
}

# Todos los casilleros numericos que buscamos (clave = numero, valor tal cual aparece en el PDF)
ALL_CODES = list(CASILLERO_LABELS.keys()) + [
    "402", "403", "404", "405", "406", "407", "408", "409",
    "413", "415", "417",
    "502", "505", "506", "507", "508", "509",
    "512", "517", "518", "519",
    "526", "565",
    "618", "619",
]


def extract_text(pdf_path: str) -> str:
    if pdfplumber is None:
        raise RuntimeError("pdfplumber no esta instalado. pip install pdfplumber --break-system-packages")
    text_parts = []
    with pdfplumber.open(pdf_path) as pdf:
        for page in pdf.pages:
            t = page.extract_text() or ""
            text_parts.append(t)
    return "\n".join(text_parts)


def parse_header(text: str) -> dict:
    header = {}
    m = re.search(r"Identificaci[oó]n:\s*(\d+)", text)
    if m:
        header["ruc"] = m.group(1)
    m = re.search(r"Raz[oó]n Social:\s*([^\n]+)", text)
    if m:
        header["razonSocial"] = m.group(1).split("Tipo")[0].strip()
    m = re.search(r"Per[ií]odo Fiscal:\s*([A-ZÁÉÍÓÚ]+\s+\d{4})", text)
    if m:
        header["periodoFiscal"] = m.group(1).strip()
    m = re.search(r"Tipo Declaraci[oó]n:\s*(\w+)", text)
    if m:
        header["tipoDeclaracion"] = m.group(1).strip()
    m = re.search(r"Estado de la\s*Declaraci[oó]n:\s*(\w+)", text) or re.search(r"Declaraci[oó]n:\s*(CUMPLIDA|PENDIENTE)", text)
    if m:
        header["estado"] = m.group(1).strip()
    return header


def parse_casilleros(text: str) -> dict:
    """
    Busca patrones 'NNN  <numero>' en el texto (el numero de casillero
    seguido del valor). El formulario del SRI intercala texto y numeros,
    por eso se usa una busqueda de 'codigo seguido de valor numerico'
    respetando limites de palabra.
    """
    values = {}
    for code in ALL_CODES:
        # Busca "  code  valor" evitando capturar codigos que son subcadena de otros
        pattern = rf"(?<!\d){code}(?!\d)\s+(-?\d{{1,3}}(?:,\d{{3}})*\.\d{{2}}|-?\d+\.\d{{2}}|0\.00)"
        matches = re.findall(pattern, text)
        if matches:
            # Si aparece más de una vez (cabecera + repeticion de pagina), toma el primero
            raw = matches[0].replace(",", "")
            try:
                values[code] = float(raw)
            except ValueError:
                pass
    return values


def parse_f104(pdf_path: str) -> dict:
    text = extract_text(pdf_path)
    result = {"archivo": pdf_path}
    result.update(parse_header(text))
    result["casilleros"] = parse_casilleros(text)
    return result


def main():
    ap = argparse.ArgumentParser(description="Parser del Formulario 104 (IVA) del SRI")
    ap.add_argument("pdf", help="Ruta al PDF de la declaracion")
    ap.add_argument("--json", help="Ruta de salida JSON (opcional)", default=None)
    args = ap.parse_args()

    data = parse_f104(args.pdf)
    print(json.dumps(data, indent=2, ensure_ascii=False))

    if args.json:
        with open(args.json, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        print(f"\nGuardado en {args.json}", file=sys.stderr)


if __name__ == "__main__":
    main()
