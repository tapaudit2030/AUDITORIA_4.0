"""
parser_f103.py
================
Extrae los casilleros clave del Formulario 103 (Retenciones en la Fuente)
del SRI a partir del PDF de la declaracion.

Uso:
    python parser_f103.py archivo.pdf [--json salida.json]

Casilleros extraidos (los que alimentan K-3.8, validados NOVISOLUTIONS ene-jun 2026):
    302 (relacion de dependencia), 349 (subtotal pais), 497 (subtotal exterior),
    499 (total retencion renta), 501 (total despues de compensacion)

Regla de negocio confirmada con evidencia real (6/6 meses, sin excepcion):
    casillero 497 == F104.casillero(503) + F104.casillero(504)   [importaciones]
  Si esta igualdad no se cumple para un mes nuevo, es señal de alerta -> revisar,
  no asumir que es igual.
"""
import re
import json
import argparse

try:
    import pdfplumber
except ImportError:
    pdfplumber = None

CODES = ["302", "349", "497", "499", "500", "501"]


def extract_text(pdf_path: str) -> str:
    if pdfplumber is None:
        raise RuntimeError("pdfplumber no esta instalado. pip install pdfplumber --break-system-packages")
    parts = []
    with pdfplumber.open(pdf_path) as pdf:
        for page in pdf.pages:
            parts.append(page.extract_text() or "")
    return "\n".join(parts)


def parse_header(text: str) -> dict:
    header = {}
    m = re.search(r"Identificaci[oó]n:\s*(\d+)", text)
    if m:
        header["ruc"] = m.group(1)
    m = re.search(r"Raz[oó]n Social:\s*([^\n]+)", text)
    if m:
        header["razonSocial"] = m.group(1).split("Tipo")[0].strip()
    m = re.search(r"Per[ií]odo Fiscal:\s*([A-ZÁÉÍÓÚ]+\s+\d{4})", text)
    if m:
        header["periodoFiscal"] = m.group(1).strip()
    m = re.search(r"Tipo Declaraci[oó]n:\s*(\w+)", text)
    if m:
        header["tipoDeclaracion"] = m.group(1).strip()
    m = re.search(r"Declaraci[oó]n:\s*(CUMPLIDA|PENDIENTE)", text)
    if m:
        header["estado"] = m.group(1).strip()
    return header


def parse_casilleros(text: str) -> dict:
    values = {}
    for code in CODES:
        pattern = rf"(?<!\d){code}(?!\d)\s+(-?\d{{1,3}}(?:,\d{{3}})*\.\d{{2}}|-?\d+\.\d{{2}}|0\.00)"
        matches = re.findall(pattern, text)
        if matches:
            raw = matches[0].replace(",", "")
            try:
                values[code] = float(raw)
            except ValueError:
                pass
    return values


def parse_f103(pdf_path: str) -> dict:
    text = extract_text(pdf_path)
    result = {"archivo": pdf_path}
    result.update(parse_header(text))
    result["casilleros"] = parse_casilleros(text)
    return result


def main():
    ap = argparse.ArgumentParser(description="Parser del Formulario 103 (Retenciones Renta) del SRI")
    ap.add_argument("pdf")
    ap.add_argument("--json", default=None)
    args = ap.parse_args()
    data = parse_f103(args.pdf)
    print(json.dumps(data, indent=2, ensure_ascii=False))
    if args.json:
        with open(args.json, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)


if __name__ == "__main__":
    main()
