# Mapa de hojas del modelo K-3 Impuestos

Convencion: **Libros** = dato del mayor contable / balance del cliente. **Declaracion** = dato del
Formulario 104 o 103. **Anexo** o **Modulo** = dato del ATS (son sinonimos en este modelo -- el
cliente llama "modulo" al ATS).

## K-3.1 ANEXO A4 -- Conciliacion de IVA y Retenciones de IVA vs. Libros (LA HOJA PRINCIPAL)

12 filas (Enero-Diciembre) en la seccion 1 (filas 28-39), 12 filas en la seccion 2 -- Retenciones
IVA agente (filas 48-59). Columnas B-AD, todas fijas, no cambian de posicion entre clientes.

### Seccion 1 (Ventas / Compras / Liquidacion), fila por mes:
| Col | Contenido | Fuente | Tipo |
|---|---|---|---|
| B | Ventas netas gravadas tarifa dif. 0% (incluye venta de activos fijos, ver nota "a") | Mayor Ingresos: cuentas de venta con IVA, netas de descuentos/devoluciones | Input |
| C | Ventas 0% con derecho a credito | Mayor Ingresos (normalmente 0 si el cliente no vende ese tipo) | Input |
| D | Ventas 0% sin derecho a credito | Mayor Ingresos: cuenta de venta sin IVA | Input |
| E | Exportaciones | Mayor Ingresos (normalmente 0) | Input |
| F | Ventas a credito (no cobradas, IVA diferido) | Mayor Ingresos / cta por cobrar, o 0 si el F.104 casillero 481 es 0 todo el periodo | Input |
| G | Tarifa de IVA vigente | **Declaracion, casillero de tarifa, o confirmar con el usuario. Verificar aritmeticamente: casillero 421/419.** | Input |
| H | Impuesto generado en ventas | `=B*G` | Formula, no tocar |
| I | Ajuste NC distinta tarifa (ventas) | Declaracion (casilleros 423/424), normalmente 0 | Input |
| J | Impuesto a liquidar mes anterior | `=L` del mes anterior (Enero es input manual, tomado de diciembre del año anterior) | Formula / input solo Enero |
| K | Impuesto a liquidar este mes | `=((B-F)*G)+I` | Formula, no tocar |
| L | Impuesto a liquidar proximo mes | `=(H+I)-K` | Formula, no tocar |
| M | Total impuesto a liquidar | `=J+K` | Formula, no tocar |
| N | Adquisiciones e importaciones con derecho a credito | **Suma de TODAS las categorias de compra: local 12/15% + activo fijo + importacion servicios + importacion bienes.** Fuente: mayor Activos, cuentas de IVA compra, suma de asientos "CIERRE" de cada cuenta, dividido entre la tarifa. Verificado: N*tarifa debe = suma de casilleros 520+521+523+524 del F.104. | Input |
| O | Impuesto causado en adquisiciones | `=N*G` | Formula, no tocar |
| P | Ajuste NC distinta tarifa (compras) | Declaracion (casilleros 526/527), normalmente 0 | Input |
| Q | Factor de proporcionalidad | `=IF(SUM(B:E)=0,0%,(B+C+E)/(B+C+D+E))` | Formula, no tocar |
| R | Credito tributario en compras | `=(O+P)*Q` | Formula, no tocar |
| S | Compensaciones de IVA | Declaracion (casilleros 603/604), normalmente 0 | Input |
| T | Saldo credito tributario mes anterior | `=W` del mes anterior (Enero es input manual, del balance/declaracion de diciembre del año anterior) | Formula / input solo Enero |
| U | Retenciones IVA del periodo (recibidas por la cia.) | **NO copiar del F.104 casillero 609 directamente (circular).** Fuente real: mayor Activos, cuentas "IVA Retenido X%" (ej. 101050201-205), suma de asientos "CIERRE". Validar contra 609. | Input |
| V | Ajustes IVA devuelto/rechazado | Declaracion (casilleros 610-614), normalmente 0 | Input |
| W | Saldo credito tributario proximo mes | `=ABS(IF((M-R-S-T-U+V)<0,eso,0))` | Formula, no tocar |
| X | Total impuesto a pagar | `=IF((M-R-S-T-U+V)>0,eso,0)` | Formula, no tocar |
| Y | Ventas segun declaracion (casillero 419) | F.104 | Input |
| Z | Credito tributario segun declaracion (615+617+618+619) | F.104 | Input |
| AA | Impuesto a pagar segun declaracion (casillero 699) | F.104 | Input |
| AB | Diferencia ventas | `=Y-B-C-D-E` (nota: F, "ventas a credito", queda fuera a proposito) | Formula, no tocar |
| AC | Diferencia credito tributario | `=Z-W` | Formula, no tocar |
| AD | Diferencia impuesto | `=AA-X` | Formula, no tocar |

### Seccion 2 (Retenciones IVA como agente), fila por mes:
Columnas B-G = libros (10/20/30/50/70/100%, fuente: reporte de comprobantes de retencion IVA
realmente emitidos -- validar exacto contra declaracion). Columnas I-N = declaracion (casilleros
721/723/725/727/729/731). Columnas P-V = diferencias, formula simple `=declaracion-libros` por
tarifa, mas total. H y O son `=SUM()` de cada lado.

## K-3.2 ANEXO A5 -- Retenciones Renta vs. Libros

Filas 28-90 = un concepto de retencion de Renta por fila (honorarios, predomina intelecto,
publicidad, transporte, arrendamiento, paraisos fiscales, etc.), columnas J-U = libros por mes
(Enero-Diciembre). **Limitacion frecuente**: los clientes rara vez tienen una cuenta contable
separada por cada concepto de retencion de Renta (a diferencia de IVA, que si suele tener cuentas
101050201-205 por tarifa). Si no se encuentra esa granularidad en el mayor, no llenar filas 28-90;
llenar solo:
- Fila "Total de retenciones de impuesto a la renta según declaraciones (casillero 499)" con el
  dato real del F.103.
- Dejar la fila "según libros" (justo arriba) vacia y documentar la limitacion -- no copiar el
  mismo valor de la declaracion (seria circular).

**Defecto conocido**: la formula del TOTAL declarado usa `=SUM(J92:Q92)` en vez de `SUM(J92:U92)`,
excluyendo Octubre-Diciembre. No corregir sin autorizacion.

## K-3.3 cruce de compras -- Modulo (ATS) vs. Libros

Columnas: C=Segun Modulo (ATS, usar `scripts/parser_ats.py`), D=Diferencia (formula, no tocar),
E=Segun Libros (mayor Activos, cuenta de IVA compra local, asiento "CIERRE" -- **usar solo la
porcion de compras LOCALES**, el ATS no captura importaciones porque llegan por aduana, no por
comprobante local; comparar contra el total completo de libros infla la diferencia artificialmente
en el monto de las importaciones).

## K-3.4 Diferencias Compras / K-3.5 Diferencia Ventas -- Anexo (ATS) vs. Declaracion

4 buckets en K-3.4 (Compras 12%, Compras 0%, No objeto de IVA, Importaciones), 2 buckets en K-3.5
(Ventas 12%, Ventas 0%). Cada bucket: C=Anexo, D=Diferencia, E=Declaracion.

**Importante sobre K-3.5**: las formulas de Diferencia vienen hardcodeadas como `=-E` (asumen que
C=Anexo siempre sera 0), porque el ATS de ventas normalmente no captura informacion util cuando el
cliente usa facturacion electronica directa. Esto no es un bug a corregir -- es una limitacion
metodologica real del ATS para ventas, ya reconocida en la conclusion del propio modelo
("No se ha determinado diferencias debido a que en el ATS no se presenta informacion de ventas").

**Compras 12%**: el "Anexo" incluye el codigo 03 del ATS (liquidacion de compra / importacion de
servicios) sumado a compras normales, y resta las notas de credito (codigo 04). Ver
`scripts/parser_ats.py`, regla `BASE_12_SUMA`/`BASE_12_RESTA`.

**Importaciones**: el modelo trae, en su version en blanco, VALORES DE EJEMPLO pre-cargados
(distintos numeros por mes) en la columna E de este bucket. Son datos de ejemplo del template
original, no datos reales de ningun cliente -- **sobrescribirlos siempre**, nunca asumir que ya
estan correctos.

## K-3.6 Retenciones en la fuente (Renta) / K-3.7 Diferencia Rte. IVA -- Anexo vs. Declaracion

K-3.6 tiene una peculiaridad: `D = C - (E - F)`, donde F es la base de "relacion de dependencia"
que se resta de la comparacion (esa base no pasa por el ATS de la misma forma). K-3.7 tiene 5
buckets (retencion IVA 10/20/30/70/100%), formula simple `D=C-E` en cada uno.

## K-3.8 Diferencia form. 104-103 -- Cruce de bases imponibles

Columnas C-F = F.104 por tarifa (0%, 12/15%, no objeto, importaciones); G=SUM(C:E) **-- DEFECTO
CONOCIDO: excluye F (Importaciones) a proposito o por error del diseño original. No corregir sin
autorizacion.** I,J,K = F.103 (casilleros 349, 497, 302). L = I-K+J (base comparable). H = L-G
(diferencia, inflada por el defecto de G).

**Regla validada con evidencia real (6/6 meses, un cliente)**: el casillero 497 del F.103 siempre
coincide exacto con la suma de los casilleros 503+504 del F.104 (importaciones). Usar esto como
verificacion cruzada al momento de cargar los datos.

## K-3.9 Retenciones IVA -- "Calculo de valores declarados de IVA": Anexo vs. **LIBROS**

Ojo: a diferencia de K-3.4/K-3.5/K-3.6/K-3.7, esta hoja compara Anexo contra **LIBROS**, no contra
declaracion. C=Anexo (mismo dato ATS que K-3.3), E=Libros (misma fuente que K-3.3, mayor Activos
cta. IVA compra local). Hay una segunda seccion identica para Credito Tributario de Renta mas abajo
en la hoja -- llenar solo si hay datos de libros de Renta disponibles (ver limitacion de K-3.2).

## K-3.10 Cierre de Asientos -- Verificacion de cierre contable

Estructura de "visita interina" (una fila, normalmente Junio) y "visita final" (una fila,
Diciembre) -- NO es mensual como las demas hojas. Tres bloques:
1. **Asiento de cierre**: B=F.104 casillero 699, C=F.104 casillero 801 (=799 si 800/802 son 0),
   D=F.103 casillero 499. E y F son formulas que jalan de `K-1.1 Hoja Resumen` (celdas especificas,
   ver abajo). **Defecto conocido**: la formula de G en la fila de visita interina usa `+E` en vez
   de `-E` (inconsistente con la fila de visita final, que si resta). No corregir.
2. **Credito Tributario - IVA**: B=F.104 casillero 615, C=F.104 casillero 617, E=libros saldo
   credito compras (mayor, cta. credito tributario compras, debito), F=libros saldo credito
   retenciones (mayor, cta. credito tributario retenciones, debito). Formula D=B+C-E-F debe dar
   exactamente 0 si todo esta bien cargado -- es la validacion mas limpia de todo el modelo.
3. **Impuesto por pagar (Formulario 101)**: requiere la declaracion de Renta anual; dejar vacio si
   no esta disponible.

**Dependencia de K-1.1**: aunque K-1.1 esta oculta y normalmente fuera de alcance, K-3.10 necesita
dos celdas especificas de ella (las que corresponden al saldo de IVA por pagar y Renta por pagar del
mes de cierre, mas su comparativo de diciembre del año anterior). Llenar SOLO esas dos filas de
K-1.1 (no la hoja completa), con fuente: mayor Pasivos, cuentas de "Impuestos a Pagar IVA/RENTA
SRI", asiento "CIERRE", mas el balance de diciembre del año anterior para la columna comparativa.

## K-3.11 Contribucion Temporal / K-3.12 Calculo Anticipado IR

Ocultas en el modelo. No llenar salvo que el usuario indique expresamente que aplican para el
cliente/periodo en cuestion y provea los datos correspondientes.

## Marcas

Hoja de leyenda (simbolos como "i" = diferencia inmaterial). No requiere llenado de datos, solo
verificar que las marcas usadas en las demas hojas esten definidas aqui.
