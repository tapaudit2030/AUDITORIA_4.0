# Defectos conocidos del modelo -- preservar, solo documentar

Confirmados en el archivo modelo original (no son errores de copia de un cliente especifico, estan
en la plantilla base). Regla: **nunca corregir sin autorizacion explicita del usuario en esa
conversacion**. Si aparecen, agregar un comentario en la celda con el texto sugerido de aqui.

## 1. K-3.8, fila G -- excluye la columna de Importaciones

`G23 = SUM(C23:E23)` en vez de `SUM(C23:F23)`. El casillero 497 del F.103 (con el que se compara
indirectamente) SI incluye importaciones, por lo que esto genera una diferencia falsa de varios
millones cada mes, en cualquier cliente con importaciones significativas.

> Comentario sugerido: "ADVERTENCIA (fiel al modelo, no corregida): esta formula excluye la columna
> de Importaciones, generando una diferencia inflada. Confirmado con el usuario: mantener fiel al
> modelo hasta nueva instruccion."

## 2. K-3.2, fila de total declarado -- rango SUM incompleto

`V92 = SUM(J92:Q92)` en vez de `SUM(J92:U92)`. Excluye Octubre, Noviembre y Diciembre del total
anual de retenciones de renta declaradas.

## 3. K-3.4 / K-3.7, varios rangos SUM truncados en filas de TOTAL

Patron repetido en varias hojas K-3.x: el rango de la formula SUM no llega hasta diciembre (ej.
`=SUM(E51:E60)` cuando deberia ser `=SUM(E51:E62)`). Revisar cada TOTAL antes de confiar en el,
especialmente si el cliente tiene datos de los 12 meses.

## 4. K-3.10, fila de "visita interina" -- signo inconsistente

`G36 = B36+C36+E36` (suma) mientras que la fila equivalente de "visita final" usa
`G41 = B41+C41-E41` (resta). Una de las dos formulas esta mal; no se sabe cual sin mas contexto del
diseñador original. No corregir ninguna sin autorizacion.

## 5. K-3.5, formulas de diferencia hardcodeadas en cero

`D27 = -E27` (no `=C27-E27`). Asume que la columna "Anexo" (C) siempre sera 0. Esto refleja una
realidad metodologica real (el ATS no captura ventas de forma util con facturacion electronica), no
es necesariamente un error -- pero si en algun cliente futuro el ATS SI trae datos utiles de ventas,
esta formula ignoraria esos datos silenciosamente. Vigilar este caso.

## 6. K-3.4, bucket "Importaciones tarifa 12%" -- datos de ejemplo pre-cargados

La version en blanco del modelo trae numeros especificos ya escritos en la columna "Segun
Declaracion" de este bucket (ej. 16758.08, 75151.92, etc. para distintos meses). Son datos de
ejemplo de un cliente/ejercicio anterior, no ceros. **Sobrescribir siempre**, nunca asumir que ya
corresponden al cliente actual.

## 7. Errores #REF! preexistentes (no relacionados a formulas de calculo)

Las hojas A-1 (Hoja Resumen), K-1 GTOS ACUMULADOS, K-1.1 Hoja Resumen, K-3.11 y K-3.12 tienen
celdas con `#REF!` ya en la version en blanco del modelo (referencias a filas/hojas que fueron
eliminadas del archivo original en algun momento). No es necesario corregirlas si esas hojas estan
fuera de alcance (ver SKILL.md, seccion "Hojas ocultas"). Si en algun momento se necesita trabajar
en esas hojas, senalar estos errores al usuario antes de continuar.
