# Notas oficiales de K-3.1 ANEXO A4 (transcritas del propio modelo)

Estas notas (a) a (k) estan escritas al pie de la hoja K-3.1 en el modelo original y son la
definicion autorizada de cada columna. Consultar aqui antes de reinterpretar una columna.

- **(a)** Valores que deben ser tomados de los registros de ingresos del contribuyente. En este
  campo deben ya disminuirse las devoluciones en ventas mediante notas de credito. Se registrara el
  valor total de ventas sin considerar si fueron a credito o al contado. **Incluye ventas de
  activos fijos.**
- **(b)** Ventas gravadas con tarifa 0% de IVA con derecho a credito tributario de conformidad con
  la normativa tributaria vigente para el ejercicio fiscal auditado.
- **(c)** Ventas gravadas con tarifa 0% de IVA que no dan derecho a credito tributario, en atencion
  a lo establecido en la normativa tributaria vigente para el ejercicio fiscal auditado.
- **(d)** La tarifa del IVA debe aplicarse de acuerdo a lo establecido en la normativa tributaria
  vigente para el ejercicio fiscal auditado. **Nunca asumir un valor fijo -- confirmar con el
  usuario o verificar aritmeticamente contra la declaracion real (impuesto generado / base neta).**
- **(e)** Corresponde al valor del IVA generado en ventas a credito registrado y no pagado en la
  declaracion del mes anterior, que debe liquidarse en el mes corriente. Para enero, este dato NO se
  calcula por formula -- debe tomarse directamente de los datos de diciembre del año anterior.
- **(f)** Corresponde al IVA generado en ventas al contado a liquidar este mes, mas el IVA generado
  en la diferencia entre ventas y notas de credito con distinta tarifa.
- **(g)** Corresponde al IVA generado en ventas a credito de este mes, liquidable hasta el mes
  siguiente.
- **(h)** Factor de proporcionalidad calculado en base a los registros contables del contribuyente.
  Si el contribuyente usa 100% como factor, debe revelarse el detalle de los documentos que
  sustenten esa decision.
- **(i)** Corresponde al credito tributario de IVA generado en la declaracion del mes anterior,
  utilizable en el mes corriente. Para enero, tomar directamente de diciembre del año anterior
  (igual que la nota (e)).
- **(j)** Corresponde a los casilleros del Formulario 104 vigente para el ejercicio fiscal auditado.
- **(k)** En caso de diferencias u observaciones, revelar la explicacion tanto al pie del anexo como
  en la seccion de Recomendaciones sobre Aspectos Tributarios.

## Marca "i" de la hoja Marcas

`i = Diferencia inmaterial`. Es una marca que el auditor coloca MANUALMENTE, con su propia
justificacion escrita junto a la marca. Nunca es un filtro automatico de la herramienta -- toda
diferencia se muestra primero, y el auditor decide caso por caso si la marca como inmaterial.
