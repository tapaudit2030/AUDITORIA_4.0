---
name: "auditoria-nomina-nia"
description: "Auditoría de nómina y beneficios a empleados bajo NIA en Ecuador: cruza rol, planillas IESS, mayores y documentos MDT/SUT; genera el legajo K-4, requerimiento REQ-NOM, carta de control interno y PPC."
---

# Auditoría de nómina – GLOBALAUDITORS (legajo K-4)

Actúa como Gerente de Auditoría. Ejecuta la auditoría del ciclo de nómina y beneficios a empleados de un cliente ecuatoriano con base en NIA, NIIF para las PYMES (o NIIF completas, según el encargo), Código del Trabajo, Ley de Seguridad Social y LRTI. Todo cruce sale de los documentos del cliente: **no inventes nada**.

## 0. Antes de empezar

1. Lee el proyecto del encargo (estado, materialidad y marco ya confirmados). Si el marco contable o la materialidad no constan, pregúntalos: es una decisión bloqueante.
2. Carga la skill `entregables-globalauditors`: identidad, paleta, logotipo y ciclo de verificación. El logotipo de GLOBALAUDITORS viene incrustado en los formatos de la firma (`xl/media/*.png` del formato K-4); extráelo de ahí si no está en el entorno.
3. Si el usuario entrega un formato de la firma (p. ej., «K-4 Nómina_FORMATO REQUERIDO.xlsx», plantilla REQ o modelo de carta), estúdialo y respeta su estructura de hojas, secciones y columnas. Los formatos suelen traer datos de otro cliente: no se copian.
4. Crea la lista de tareas y avisa en cada hito con lo hallado.

## 1. Insumos (copiar a un directorio de trabajo; los `.xls` se leen con `xlrd`)

| Fuente | Uso |
|---|---|
| Rol de pagos (Excel, una hoja por mes) | Detalle por empleado, subtotales por sección, asiento contable impreso, roles individuales |
| Consolidado de planillas IESS | Base, días, patronal, individual, CCC por cédula y mes; relación de trabajo (cód. 06 Código del Trabajo; cód. 109 gerente sin relación de dependencia) |
| Balance de comprobación mensual (incluir dic. del año anterior) | Saldos y movimientos de 2.1.2, 2.1.3, 2.1.4.1.06, 2.2.7, 5.1.x.1 |
| Mayor (A-4) | Pagos de sueldos, IESS, préstamos, FR, liquidaciones, asientos manuales |
| Formularios MDT (13°, 14°, utilidades) | SBU vigente, días, valores, fechas de registro, IR declarado |
| Egresos de tesorería (PDF escaneado) | Montos, cheques, firmas «Recibí conforme» y «Aprobado por», secuencia |
| Listado de personal activo/inactivo, capturas SUT, políticas | Movimiento de personal, contratos, actas, descuentos |

PDF escaneados: `pdftoppm` y lectura de imágenes; rota y recorta las hojas apaisadas para leer cifras. Arma hojas de contacto (6 recortes por imagen) para revisar muchos egresos con pocas lecturas. Transcribe a mano cada egreso (número, cheque, banco, beneficiario, monto, firmas) y verifica que el total cuadre con el formulario y el mayor.

## 2. Parseo del rol (verificar, no asumir)

- Ubica la fila de encabezado (`Ref.`), las secciones (filas con texto en A y B vacío), las filas `Subtotal` y `TOTAL GENERAL`. Después del total puede haber: fila «EN RELACIÓN DEPENDENCIA / IESS», cuadro de viáticos de ruta, bloque «ASIENTO CONTABLE» (cuenta, nombre, debe, haber) y bloques de rol individual a la derecha (columnas ≥ 40).
- Normaliza la cédula como texto de 10 dígitos (las celdas numéricas pierden el cero inicial).
- Valida: suma de empleados = TOTAL GENERAL por columna; V = salario fijo + variable; aporte personal = 9,45 % de V (gerente cód. 109: 17,6 %); patronal = 11,15 % de V; CCC = 1 % de V; 13° = V/12; 14° = SBU/360 × días; vacaciones = V/24; FR = 8,33 % de V desde el segundo año; neto = V + bono + FR mensualizado − descuentos.
- El SBU del año se toma del formulario MDT de 14° (valor por 360 días). Revisa que enero ya use el SBU nuevo.

## 3. Cruces obligatorios (cada uno en su hoja)

1. **K-4 sumaria y K-1.1**: saldos mensuales de pasivos laborales enlazados al balance; control de completitud contra la cuenta de control del grupo (Σ|dif| = 0); gasto 5.1.x.1 por mes.
2. **K-4.0 gasto rol vs libros**: por sección (Administración → 5.1.2.1, Ventas → 5.1.3.1) y concepto. Explica cada diferencia con la partida del mayor (bono de alimentación registrado en bonificación, FR acumulado no llevado a gasto, facturas de terceros en comisiones, comisiones bancarias). Concilia con el alcance de nómina asignado en el legajo de gastos (P).
3. **K.4 recálculo nómina** (formato de la firma: Rol / Dif. / IESS por mes y empleado) + tablas mensuales de base, aporte personal, patronal, CCC y obligación total.
4. **K-4.1 prueba global**: lista de cada diferencia > 0,05 con días de rol e IESS; separa las salidas del mes que el IESS aporta pero el rol no incluye (pagadas en liquidación). Control: Σ excepciones = diferencia total.
5. **K-4.2 beneficios sociales**: recálculo vs rol vs libros (13°, 14°, vacaciones, FR); excepciones por empleado (FR en el mes de aniversario, provisiones al gerente cód. 109, SBU antiguo en enero); movimiento de los pasivos; 14° esperado al corte = provisión del último mes si el período ya cerró.
6. **K-4.3 pasivos IESS**: el «Total aporte» del reporte IESS excluye el CCC, pero el pago real = patronal + individual + CCC. Compara cada pago (planillas normales + ajustes) con la provisión del rol; saldo esperado = planilla del último mes. Préstamos: retenido en rol vs pagado; saldo esperado = retención del último mes. FR acumulado: rol vs gasto vs pasivo.
7. **K-4.4 discapacidad**: trabajadores en relación de dependencia (excluye cód. 109) × porcentaje legal; lo declarado en el formulario MDT; listado y carné.
8. **K-4.5 actuarial**: jubilación y desahucio vs estudio; costo del período; débitos por liquidaciones.
9. **K-4.6 vacaciones**: saldo inicial + provisión − liquidaciones − goce = saldo; detalle valorizado.
10. **K-4.7 décimo cuarto**: formulario MDT = recálculo = egresos = mayor; firmas; secuencia de egresos y cheques; trabajadores salientes pagados en liquidación.
11. **K-4.8 participación 15 %**: utilidad × 15 %, formulario, pasivo, pago, fechas, IR declarado vs libros.
12. **K-4.9 sueldos por pagar**: empareja cada pago «SUELDO <MES> – <EMPLEADO>» del mayor con el neto del rol (por tokens del nombre, con alias de apodos); identifica netos pagados en liquidación o por «cuadre»; compón el saldo (neto del último mes + impagos de relacionados + saldo antiguo + diferencias) hasta una diferencia de centavos.
13. **K-4.10 movimiento de personal**: listado vs meses IESS vs meses rol; liquidación (haber 2.1.2.2.07) vs pago (debe); desahucio; descuentos compensados; acta SUT.
14. **K-4.11 roles individuales y descuentos**: líquido del rol individual vs neto; descuentos sobre el límite de la política; multas y su destino.
15. **H-K4 hallazgos** (condición, criterio, efecto, monto por fórmula, riesgo ALTO/MEDIO/BAJO, tipo, ref., recomendación) y **AJ-K4 ajustes propuestos** (nunca contabilizados); evaluación NIA 450 contra trivial y ME.

PPC de respaldo dentro del legajo: PPC-1 rol (extracción íntegra + recálculo por fórmula), PPC-2 IESS, PPC-3 mayor de cuentas de nómina, PPC-4 balance. Las hojas de análisis usan `SUMIFS` sobre los PPC (rangos acotados; si no hay condición usa `SUM`, porque un `SUMIFS` sin criterios da #VALUE! en LibreOffice).

## 4. Alertas frecuentes que se deben buscar

- Asientos manuales de «cuadre», «encerar cuentas» o reclasificación en cuentas de nómina (NIA 240).
- Pagos al IESS mayores que la provisión (planilla de diciembre, préstamos de personas fuera del rol).
- Gerente-socio con netos impagos en sueldos por pagar; préstamos IESS de relacionados reclasificados a sus cuentas.
- Remuneraciones pagadas fuera del rol (liquidaciones del mes de salida) y su gasto.
- Bonos no aportados al IESS; facturas de terceros en cuentas de nómina.
- Parámetros del rol desactualizados (SBU, tasas, tabla de IR rotulada con el año anterior).
- Archivos con nombre engañoso (p. ej., «avisos de entrada y salida» que en realidad son el listado del rol) y capturas del SUT que no muestran una consulta ejecutada.

## 5. Entregables (formato GLOBALAUDITORS; Excel + PDF; guardar en la carpeta del cliente)

1. **Legajo K-4** («<AAAA>_Audit<Cliente>_K-4 Nómina.xlsx»): K-2 programa, K-1.1, K-4, K-4.0, K.4, K-4.1 a K-4.11, H-K4, AJ-K4, Marcas, PPC-1 a PPC-4. Cada papel: Objetivo → Procedimiento → Análisis → Marcas → Referencia → Observaciones → Conclusión (SATISFACTORIA / CON EXCEPCIONES / NO SATISFACTORIA / LIMITACIÓN AL ALCANCE) + bloque Hecho/Revisado/Aprobado.
2. **Requerimiento REQ-NOM** sobre la plantilla REQ de la firma: genérica (30 documentos en 8 grupos: roles, IESS, libros, beneficios, movimiento de personal, políticas, tributario y relacionadas, papel del contador) y versión del cliente con estado por mes y anual (Entregado/Pendiente/Observado/Por verificar/No aplica) y observación por documento.
3. **Carta de control interno** sobre el modelo Word de la firma (editar el XML del modelo, no recrearlo: separar bloques de primer nivel, clonar título/antecedente/cita/observación/viñeta, conservar portada, firma, apéndice y confirmación; quitar `w14:paraId`; `keepNext` en títulos; validar con `validate.py --original`). La primera condición es «Información no incluida». Solo van entre comillas los textos que constan en el modelo o en documentos del cliente; las normas se parafrasean. Reemplaza el nombre del cliente anterior también en los encabezados (los runs vienen partidos).
4. **PPC de la carta**: PPC-00 índice con hipervínculos + un PPC por condición con fuente, referencia K-4 y diferencias por fórmula.

## 6. Verificación antes de entregar

- Recalcular con LibreOffice y buscar `#REF!`, `#VALUE!`, `#DIV/0!`, `#NAME?`, `#N/A`; entregar la versión recalculada (con valores en caché).
- Comprobar los controles: completitud = 0, Σ excepciones = diferencia total, composición de sueldos por pagar ≈ saldo, 14° formulario = egresos = mayor, ajustes cuadrados.
- Convertir a PDF y mirar las páginas (membrete completo, logo en cada hoja, sin títulos huérfanos). En la carta: 0 apariciones de `NIC `, `NIIF 9` y `marco aplicable` si el marco es NIIF para las PYMES, y 0 del nombre del cliente del modelo.
- Actualizar el documento del proyecto del encargo con archivos, cuadres, hallazgos y pendientes.

## 7. Al cerrar, informar

Los cuadres con sus cifras, los hallazgos por nivel de riesgo, las incorrecciones frente a trivial y ME, lo pendiente del cliente y lo que debe confirmar el auditor responsable: número de oficio, fecha, firmante, nombre del contador y artículos legales citados (contrastarlos con el texto oficial si no hubo acceso web).