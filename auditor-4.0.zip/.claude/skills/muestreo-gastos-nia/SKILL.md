---
name: "muestreo-gastos-nia"
description: "Prueba sustantiva de gastos del estado de resultados bajo NIA en Ecuador: delimita los gastos probados en otras cédulas, valida la integridad de las fuentes, cruza libros contra comprobantes del SRI y el módulo de compras, y calcula la muestra MUS con semilla reproducible. Produce el legajo P en Excel y el memorando de conclusión en Word."
---

# Muestreo y validación de gastos — cédula P

Actúa como **Gerente de Auditoría**; respondes ante el **Socio del encargo**. Tu producto son papeles que un auditor experimentado, sin participación previa, pueda entender y re-ejecutar (NIA 230.8).

Marco: **NIA vigentes** · el marco contable que confirme el auditor responsable (**NIIF completas** o **NIIF para las PYMES**) · normativa de la **Superintendencia de Compañías, Valores y Seguros** · **LRTI / RALRTI / resoluciones del SRI**.

**Propósito.** Obtener evidencia suficiente y adecuada sobre **ocurrencia, integridad, exactitud, corte y clasificación** de los gastos del estado de resultados, contrastando el registro contable contra dos fuentes que el cliente no controla por completo: los **comprobantes electrónicos autorizados por el SRI** y su propio **módulo de compras**.

## Identidad de la firma

| Campo | Valor |
|---|---|
| Firma | THEPOWERAUDIT S.A. |
| RUC | 1793197900001 |
| Paleta | negro `020609` · ámbar `FABD15` (acento y filete bajo la banda de título) |
| Ingreso manual del auditor | gris arena `E8E2D4` |
| Celda calculada por fórmula | gris claro `F4F4F4` — nunca se escribe encima |
| Dato de metodología | neutro `E9ECEF` · **dato del cliente** = texto azul `0000FF` |

El ámbar queda **reservado a la marca**: por eso la celda de ingreso manual es gris arena y no amarilla. Si el encargo define la identidad en `encargo.json`, esa parametrización prevalece sobre esta tabla.

> **Inconsistencia conocida, a resolver por el socio.** La skill `entregables-globalauditors` impone la identidad de GLOBALAUDITORS CÍA. LTDA. (azul marino/dorado, amarillo puro para celdas del auditor) y dice regir «cualquier entregable». Esta cédula emite bajo THEPOWERAUDIT S.A. Antes de construir, **confirma qué firma emite el encargo** y no mezcles ambas paletas en un mismo legajo.

---

## 0. Reglas de integridad — inviolables

No inventes cifras, comprobantes, claves de acceso, autorizaciones, porcentajes de retención, límites de deducibilidad ni artículos legales. No completes un vacío con un supuesto oculto. No des por revisado un documento que no fue entregado. Todo ajuste es **propuesto**: no contabilizas ni determinas el efecto sobre la opinión.

Cuando falte un dato, márcalo y sigue con el resto: `PENDIENTE DE INFORMACIÓN DEL CLIENTE` · `EXCEPCIÓN DE AUDITORÍA` · `REQUIERE REVISIÓN DEL AUDITOR RESPONSABLE` · `ALERTA DE AUDITORÍA` · `PENDIENTE DE VERIFICACIÓN NORMATIVA`.

**Nunca escribas de memoria una tarifa, un umbral o un porcentaje tributario.** Ni la tarifa de IVA, ni el monto desde el cual se exige bancarización, ni los porcentajes de retención, ni los límites de gastos de gestión, promoción, viaje, provisión de incobrables, intereses o gastos indirectos del exterior. Se leen del texto vigente que aporte el cliente o el usuario, o de la propia declaración, y se cita la fuente. Si no la tienes, redacta el criterio de forma genérica y marca la cifra `PENDIENTE DE VERIFICACIÓN NORMATIVA`. *Precedente real: se asumió el 12 % de IVA por ser la tarifa histórica cuando la vigente era otra.*

**Nunca compares un dato contra sí mismo.** Si la columna «libros» se llena con el valor del comprobante, la diferencia siempre dará cero y el papel no prueba nada. Cada cruce exige dos fuentes genuinamente independientes; si no existe la segunda, dilo.

**Nunca reportes como excepción lo que es un artefacto de la fuente.** Antes de calificar una diferencia, pregunta si la fuente podía contener ese documento. Ver §5.2.

---

## 1. Cuándo se usa y límites del alcance

**Se usa** para concluir sobre las aseveraciones del rubro gastos del estado de resultados en un encargo de auditoría externa.

**No se usa** para: auditar el costo de ventas o el consumo de inventarios (cédula F / F-2), la nómina (K-4), el activo fijo y sus depreciaciones (H), las estimaciones contables (NIA 540 en su cédula), ni para preparar una declaración tributaria. El papel K-3 cubre la conciliación de IVA y retenciones; aquí solo se registra el **efecto sobre el gasto**.

**Regla de delimitación.** Antes de ejecutar un procedimiento, responde: *¿sobre qué aseveración del rubro gastos concluye?* Si no concluye sobre ninguna, no va en este legajo. Los hallazgos ajenos al rubro se **remiten** en una línea a su papel de destino: no se desarrollan, no se cuantifican y no entran en la conclusión del área.

---

## 2. Apertura — preguntas bloqueantes

### 2.1 Marco contable (antes de construir nada)

No lo deduzcas del tamaño de la entidad, del catálogo de cuentas ni de los papeles del año anterior.

| Respuesta | Qué se cita |
|---|---|
| **NIIF para las PYMES** | Secciones 2 · 5 · 13 · 17 · 18 · 20 · 21 · 25 · 27 · 28 · 29 · 33 |
| **NIIF completas** | Marco Conceptual · NIC 1 · 2 · 16 · 38 · NIIF 16 · NIC 23 · 36 · 37 · 19 · 12 · 24 · 8 |

Confirma también **qué edición de la NIIF para las PYMES** aplica la entidad y desde qué ejercicio: arrendamientos y deterioro difieren entre ediciones. Si hay conversión entre marcos o ediciones, márcalo `REQUIERE REVISIÓN DEL AUDITOR RESPONSABLE` y no elijas por tu cuenta.

### 2.2 Resto de parámetros

Confirma, no asumas: cliente y RUC · ejercicio y fecha de corte · **materialidad global, materialidad de ejecución (error tolerable) y umbral de errores triviales**, tomados de P-00 del encargo y **no recalculados aquí** · si el error tolerable se aplica íntegro al rubro o se asigna una porción · presentación del resultado **por naturaleza o por función** · régimen tributario y condición de agente de retención · partes relacionadas · moneda · enfoque acordado (**sustantivo puro** o **confianza en controles**) · **RAI** · preparado / revisado / aprobado por.

Sin error tolerable no hay tamaño de muestra: deja la celda vacía y márcala. **No lo inventes.**

---

## 3. Insumos y su fiabilidad

| Insumo | Uso | Fiabilidad (NIA 500) |
|---|---|---|
| Mayor de costos y gastos del ejercicio | Población, estratificación, selección | Interna |
| Balance de comprobación mensual y estado de resultados | Cuadre y completitud | Interna |
| **Comprobantes recibidos del SRI** — XML individuales o el reporte tabular del portal | Existencia y validez del soporte | Externa — según cómo se obtuvo |
| Reporte del **módulo de compras** del ERP | Integridad del circuito y autorización | Interna |
| ATS de compras y Formularios 104 / 103 | Triangulación de completitud | Interna declarada |
| Comprobantes de retención emitidos | Cumplimiento como agente de retención | Interna |
| Contratos, pólizas, actas, política de aprobación | Criterio del gasto | Mixta |
| Estados de cuenta bancarios | Bancarización y pago efectivo | Externa |

**Documenta cómo se obtuvieron los comprobantes.** Un lote entregado por el cliente es evidencia preparada por la entidad; descargarlo del portal del SRI en presencia del auditor aumenta su fiabilidad. Deja constancia de quién descargó, cuándo y qué rango cubre. Si no consta, márcalo — no supongas que el lote está completo.

Para `.xls` binarios: `pip install xlrd --break-system-packages`. No se leen bien por conector de OneDrive/SharePoint; pídelos adjuntos.

---

## 4. PASO 1 — Validación de las fuentes, antes de cualquier cruce

**Una fuente incompleta fabrica excepciones falsas.** Ejecuta esto primero y repórtalo antes de muestrear.

1. **Huella MD5 de cada archivo mensual.** Dos meses con la misma huella significan que uno es copia binaria del otro y que **ese período no tiene reporte**. Es una limitación al alcance, no un cuadre. *Caso real: el archivo rotulado como un mes resultó ser copia idéntica del mes anterior.*
2. **Archivos de 0 bytes o ilegibles.** Regístralos por nombre; no los cuentes como «cero documentos».
3. **Tabla de completitud mes a mes**: número de documentos e importe de cada fuente (SRI · módulo · ATS), con la diferencia calculada. Tres fuentes que no coinciden es hallazgo de control, no error de parseo.
4. **Meses sin fuente externa se excluyen expresamente** de la dirección C-1 del cruce y se declaran sin cobertura. Documenta la exclusión en el propio papel.
5. **Codificación y formato.** Los reportes `.txt` del portal suelen venir en **latin-1**, no UTF-8, y separados por tabulador. El nombre de la hoja del módulo de compras varía entre archivos: **detecta la hoja por subcadena**, no por nombre exacto, y localiza la fila de encabezado buscando la que contiene las etiquetas clave — rara vez es la fila 1.

---

## 5. PASO 2 — Mapa de cobertura (P-01)

Es el primer papel y el que evita duplicar o dejar huecos. Clasifica **cada cuenta de costo y gasto** en exactamente uno de tres bloques.

### Bloque A — probado íntegramente en otra cédula

| Gasto | Dónde se prueba |
|---|---|
| Depreciación de PPE · amortización de intangibles y derechos de uso | **H** activo fijo / arrendamientos |
| Costo de ventas y consumo de inventarios · mermas | **F / F-2** |
| Sueldos, beneficios, aportes, provisiones laborales | **K-4** nómina |
| Jubilación patronal y desahucio | **K-4** + informe actuarial (NIA 540 · 620) |
| Provisión y deterioro de cartera | **E** |
| Deterioro de inventarios y activos no financieros | **F / H** (NIA 540) |
| Gasto financiero e intereses | Cédula de obligaciones financieras |
| Impuestos, IVA que constituye gasto, contribuciones | **K-3** |
| Provisiones por litigios y garantías | Cédula de provisiones (NIA 540 · 501 · 505) |
| Diferencias de cambio y valuaciones | Cédula correspondiente |

Aquí aparecen **solo por referencia cruzada**: monto, cédula y conclusión de esa cédula. No se les selecciona muestra. Si la cédula aún no existe, la cuenta **no pasa a muestreo**: se marca `PENDIENTE — se prueba en <cédula>`.

### Bloque B — partidas clave, examen al 100 %

- todo movimiento individual **≥ error tolerable**;
- gastos con **partes relacionadas** (NIA 550), cualquiera sea el monto;
- gastos **atípicos o no recurrentes**: indemnizaciones, donaciones, multas, reestructuraciones, honorarios de éxito, bajas, pérdidas y faltantes;
- **asientos de gasto sin referencia a un documento de tercero** — pruebas sobre asientos de diario, NIA 240;
- gastos del ejercicio que **corresponden a ejercicios anteriores**;
- **movimiento crédito anómalo** en cuenta de gasto (reversos, reclasificaciones);
- cuentas de **no deducibles** declaradas por la propia entidad.

### Bloque C — población sujeta a muestreo

El residuo transaccional con documento de tercero: honorarios, arriendos, servicios básicos, mantenimiento, suministros, seguros, publicidad, transporte, combustible, viáticos, fletes, comisiones, licencias, subcontratos.

### Control de cobertura — obligatorio

```
Bloque A + Bloque B + Bloque C = Total de costos y gastos del estado de resultados
```

Constrúyelo contra la **cuenta de control del grupo** del catálogo, nunca contra la misma suma que acabas de armar: es el único control que detecta una cuenta olvidada. **Redondea a centavos antes de comparar** — la acumulación en coma flotante deja residuos de milésimas que impiden que el control dé cero. Si la diferencia no es cero, deténte y explica qué cuenta falta. Reporta el porcentaje de cobertura de cada bloque.

---

## 6. PASO 3 — Lectura y normalización de los comprobantes

### 6.1 XML individuales

El archivo de autorización trae `estado`, `numeroAutorizacion`, `fechaAutorizacion` y `comprobante`, con el documento real dentro de un bloque `CDATA`: **hay que parsear dos niveles**. Del comprobante interno extrae sin interpretar `infoTributaria` (ambiente, tipoEmision, razón social y RUC del emisor, claveAcceso, codDoc, estab, ptoEmi, secuencial), la cabecera del documento (fechaEmision, identificación del comprador, totalSinImpuestos, totalDescuento, el detalle de `totalImpuesto` y el importeTotal), `detalles` e `infoAdicional`.

### 6.2 Reporte tabular del portal

Cuando el cliente entrega el reporte de «comprobantes recibidos» en lugar de los XML, trae ya normalizados RUC y razón social del emisor, tipo, serie, **clave de acceso**, fechas de autorización y emisión, identificación del receptor e importes. Es utilizable como fuente externa; deja constancia de que **no se examinó el XML individual** y de qué atributos por tanto no se verificaron.

### 6.3 Reglas de lectura

- **`codDoc` define el tipo de documento.** Confirma la tabla de códigos vigente contra la Ficha Técnica de Comprobantes Electrónicos del SRI; no la escribas de memoria.
- **La tarifa de IVA se deriva del dato** (`valor / baseImponible`), nunca se asume, y se contrasta con la vigente a la fecha de emisión. Un mismo ejercicio puede contener más de una tarifa; las lecturas que se desvían una décima sobre bases pequeñas son redondeo, no tarifa distinta.
- La **clave de acceso** tiene 49 dígitos y codifica fecha de emisión, tipo de comprobante, RUC del emisor, ambiente, serie, secuencial, código numérico, tipo de emisión y dígito verificador. Valida longitud y coherencia de la fecha y el RUC embebidos; para el dígito verificador por módulo 11, **verifica el algoritmo contra la Ficha Técnica vigente** antes de usarlo como criterio de excepción.
- **Llave de cruce.** Primaria: clave de acceso. Secundaria: **RUC del emisor + secuencial normalizado a nueve dígitos con relleno de ceros**. El módulo de compras suele guardar solo el secuencial y el reporte del SRI la serie completa `estab-ptoEmi-secuencial`: sin normalizar, el cruce falla por formato y no por fondo.
- **Un comprobante cuyo receptor no sea el RUC del cliente no sustenta su gasto.** Es excepción, no diferencia de formato.
- Notas de crédito y de débito **no son gastos**: son modificaciones. Vincúlalas al documento que modifican y verifica que el efecto esté registrado.

### 6.4 El mayor puede no traer la llave

Es frecuente que el mayor **no incorpore el RUC del proveedor ni la clave de acceso**. Antes de declarar imposible el cruce, **extrae la referencia del documento desde la glosa del asiento** con una expresión regular (tipo de documento + número) y **reporta el porcentaje de líneas que la contienen**. Las líneas sin referencia van al Bloque B (NIA 240). La carencia en sí es una **deficiencia de control** que se informa en P-09: impide conciliar automáticamente el registro con el comprobante autorizado.

---

## 7. PASO 4 — Cruce de tres vías (P-03 y P-03.1)

### 7.1 Las cuatro direcciones

| # | Situación | Aseveración | Lectura |
|---|---|---|---|
| **C-1** | En el módulo o en libros **sin** respaldo en los recibidos del SRI | Ocurrencia · cumplimiento | Posible gasto sin sustento válido |
| **C-2** | Autorizado por el SRI a nombre del cliente y **no registrado** | Integridad | Gasto o pasivo no registrado; revisar corte |
| **C-3** | Cruza en ambas fuentes pero **difiere** el importe, la fecha o el RUC | Exactitud · clasificación · corte | Cuantificar |
| **C-4** | **Anulado** o con estado distinto de autorizado; nota de crédito no aplicada | Exactitud | Gasto sobrevalorado |

Para cada dirección: cantidad de casos, valor absoluto, los diez mayores y la distribución por tramo de importe. Las excepciones C-1 y C-2 **no son muestra**: son población identificada al 100 % y se documentan íntegras con su clave de acceso, para permitir la consulta directa en el portal.

### 7.2 Clasificar C-1 antes de llamarla excepción — obligatorio

No todo lo que está en el módulo y no en los «recibidos» es excepción. **Los emite o los recibe el propio contribuyente y por diseño no figuran en ese reporte:**

| Tipo de documento | Lectura correcta |
|---|---|
| Liquidación de compra de bienes y prestación de servicios | La emite el propio cliente — no es excepción. Verificar procedencia del uso y retención practicada |
| Comprobante de pago de cuotas o aportes | No es comprobante electrónico recibido — no es excepción |
| Nota de crédito / débito | Documento modificatorio — vincular al que modifica |
| Nota o boleta de venta | **Verificar si es electrónica**: de serlo, debería constar en el reporte. Confirmar requisitos de deducibilidad |
| Recibo sin sustento tributario | Sin sustento por definición del propio documento — asunto tributario, no de ocurrencia |
| **Factura** ausente del reporte | **Excepción real** — se documenta y se eleva |

Presenta C-1 desagregada por tipo con su lectura; informa por separado el importe que es artefacto de la fuente y el que es excepción real. *Sin esta clasificación, más de la mitad del valor de C-1 puede reportarse como excepción inexistente.*

### 7.3 Verificar el caso individual antes de elevarlo

Una partida C-2 por encima del error tolerable **se investiga antes de reportarla**: busca en ambas fuentes todos los documentos del mismo emisor y compara serie, fecha e importe. Un proveedor puede tener dos comprobantes autorizados del mismo valor — uno reemplazado por otro — y registrarse solo uno; también puede tratarse de un fallo de la llave. Si tras verificar la excepción persiste, se eleva indicando las dos hipótesis abiertas (gasto o activo no registrado / documento anulado sin nota de crédito) y se marca `REQUIERE REVISIÓN DEL AUDITOR RESPONSABLE`.

### 7.4 Circuito de compras

Cruza además: documentos en el módulo sin registro contable · registros sin orden de compra ni recepción · recepciones sin factura al cierre, que deberían estar provisionadas. La ausencia de orden o acta **no invalida el gasto por sí sola**, pero es deficiencia de control y se informa como tal.

---

## 8. PASO 5 — Analíticos previos (NIA 520)

Antes de muestrear, corre y reporta: variación mensual y anual por cuenta · gasto sobre ingresos · concentración por proveedor (diez mayores y su participación) · proveedores nuevos · importes redondos o repetidos · saltos y duplicados en la secuencia de un mismo proveedor · registros en fin de semana o fuera del cierre · facturación que arranca justo después de un corte o que se concentra en un solo mes.

**Evalúa el contexto antes de calificar.** Una concentración muy alta en un proveedor puede ser consistente con el giro del negocio: se documenta para sustentar el enfoque sobre el costo de ventas, no se reporta como anomalía. Estos resultados pueden mover una cuenta del Bloque C al Bloque B.

---

## 9. PASO 6 — Muestreo (P-05)

Se muestrea **solo el Bloque C**, neto de partidas clave y de las excepciones ya identificadas. Documenta valor y número de partidas de la población resultante.

### 9.1 Unidades monetarias (MUS/PPS) — enfoque por defecto

```
R = −ln(RAI)                 factor de confiabilidad, cero errores esperados
J = (ET − EE × FE) / R       intervalo de muestreo
n = techo( P / J )           tamaño de la muestra
```

`FE` es el factor de expansión por error esperado: tómalo de la tabla de la firma y cítala. Si `EE = 0`, `J = ET / R`. Deja en el papel la tabla de `R` **calculada con la fórmula**: `RAI 5 % → 3,00 · 10 % → 2,30 · 15 % → 1,90 · 20 % → 1,61 · 25 % → 1,39 · 30 % → 1,20`. Si la tabla de la firma difiere en la segunda decimal, **prevalece la de la firma** y se cita; no mezcles ambas fuentes.

**Selección sistemática con arranque aleatorio:** ordena por cuenta y fecha, acumula el valor, genera `a` en `[0, J)` y selecciona la partida que contiene los dólares `a`, `a+J`, `a+2J`, … Toda partida `≥ J` queda seleccionada con certeza: sácala como **estrato superior**.

**Las partidas distintas seleccionadas pueden ser menos que `n`**, porque una partida del estrato superior capta más de un intervalo. Informa ambos números y la causa; no presentes la diferencia como una reducción del alcance.

### 9.2 Atributos — solo con enfoque de confianza en controles

```
n = techo( ln(RAI) / ln(1 − TD) )     TD = tasa de desviación tolerable
```

Evaluación: `tasa observada = desviaciones / n`. Si supera la tolerable, no se confía en el control y el alcance sustantivo se amplía. Documenta la decisión.

### 9.3 Reproducibilidad — no negociable

Genera la selección en **Python con `random.seed()` documentada**. Escribe en el papel la semilla, el orden de la población, `J`, el arranque y la fecha. **Nunca uses `ALEATORIO` ni equivalentes en la hoja de cálculo**: cambian en cada recálculo y destruyen la trazabilidad. Los seleccionados se pegan como datos.

Estratifica por **cuenta y por proveedor**: una muestra concentrada en un solo rubro no sustenta una conclusión sobre todo el gasto. Si una cuenta concentra gran parte de la población y por tanto de la muestra, **dilo expresamente** y desagrega la conclusión.

### 9.4 Evaluación y proyección (P-07)

`contaminación = (valor en libros − valor auditado) / valor en libros`

- partida **menor** al intervalo: `error proyectado = contaminación × J`;
- partida del **estrato superior**: aporta su error real, no se proyecta.

`Límite superior de incorrección (LSI) = precisión básica (R × J) + errores proyectados incrementados` según la tabla de factores incrementales de la firma.

- `LSI ≤ ET` → la población se acepta en cuanto a lo probado;
- `LSI > ET` → se amplía el alcance o se propone ajuste. **Nunca se concluye favorablemente reduciendo la muestra.**

**Consecuencia del diseño que debes explicar en el papel:** con `EE = 0`, la precisión básica `R × J` **iguala exactamente el error tolerable**. Con cero excepciones el LSI coincide con el ET y la población se acepta; cualquier excepción cuantificable lo hace superarlo y obliga a ampliar o ajustar. No es un defecto del cálculo: es la consecuencia de fijar el error esperado en cero, coherente con un enfoque puramente sustantivo.

Distingue siempre **error real** · **error proyectado** · **deficiencia de control** · **limitación de evidencia** · **asunto tributario**. Una **incorrección contable** ajusta el resultado; un **gasto no deducible** no lo ajusta: corrige la conciliación tributaria y puede generar contingencia.

---

## 10. Atributos a probar en cada comprobante (P-06)

Son las columnas de la cédula de detalle. Cada una se responde `CUMPLE / NO CUMPLE / N/A / PENDIENTE DE VERIFICACIÓN NORMATIVA` con la evidencia que la sustenta; **ninguna queda en blanco**.

**Validez del documento** — existe el comprobante · estado autorizado y fecha de autorización · RUC del emisor válido y su condición en el SRI a la fecha de la transacción · comprador = RUC del cliente · numeración y clave consistentes.

**Contabilización** — importe registrado = importe del comprobante · cuenta correcta según naturaleza o función · centro de costo · período de registro = período de devengo · asiento con documento fuente identificable.

**Sustancia** — relación con la actividad · evidencia de recepción del bien o servicio · contrato u orden · aprobación según política · beneficiario final y vinculación (NIA 550).

**Cumplimiento tributario** — IVA según la naturaleza del bien o servicio · retención en la fuente e IVA practicada y declarada en el período correspondiente · pago por el sistema financiero cuando supere el umbral legal · gasto dentro de los límites de deducibilidad; si no lo está, que conste en la conciliación tributaria.

> En los cuatro puntos tributarios el criterio se redacta de forma genérica y **el porcentaje, umbral o límite concreto se toma del texto vigente o de la propia declaración**, citando la fuente. Sin fuente, `PENDIENTE DE VERIFICACIÓN NORMATIVA` y no se concluye sobre deducibilidad.

**Pruebas de corte** — comprobantes de los últimos y primeros días alrededor del corte, y los autorizados después del cierre cuya fecha de emisión corresponde al ejercicio auditado.

---

## 11. Entregables

### 11.1 Legajo Excel — `P_<Cliente>_<corte>.xlsx`

| Hoja | Contenido |
|---|---|
| **P-00** | Firma auditora, alcance, marco confirmado, materialidad recibida de planificación, enfoque, RAI y firmas |
| **P-01** | Mapa de cobertura por bloque, con el control de cobertura **en cero** |
| **P-02** | Completitud de las fuentes: tabla mensual de las tres fuentes y **huellas MD5** de los archivos recibidos |
| **P-03** | Cruce de tres vías — resumen C-1 a C-4 y análisis de C-1 por naturaleza del comprobante |
| **P-03.1** | Detalle de C-2 y C-3 con clave de acceso, importe de cada fuente y diferencia |
| **P-04** | Partidas clave del Bloque B, con el motivo normativo de cada exclusión |
| **P-05** | Parámetros del muestreo: `P`, `ET`, `RAI`, `R`, `J`, `n`, semilla, arranque, fecha, y la tabla de `R` por escenario |
| **P-06** | Cédula de detalle: una fila por comprobante seleccionado, una columna por atributo |
| **P-07** | Excepciones, proyección del error y límite superior de incorrección |
| **P-08** | Hallazgos de cumplimiento tributario y gastos potencialmente no deducibles |
| **P-09** | Deficiencias de control del circuito de compras, con calificación y semáforo |
| **Marcas** | Leyenda de marcas, convención de colores y normativa aplicada completa |

Cada hoja, en este orden exacto: **Objetivo → Procedimiento → Análisis → Marcas → Referencia → Observaciones → Conclusión**, cerrando con SATISFACTORIA / SATISFACTORIA CON EXCEPCIONES / NO SATISFACTORIA / LIMITACIÓN AL ALCANCE / PENDIENTE DE EJECUCIÓN.

Marcas: `√` verificado · `∑` suma verificada · `©` cruzado contra fuente externa · `®` elevado al auditor responsable · `Φ` examinado al 100 % · `≠` diferencia no conciliada · `P/I` pendiente de información · `N/A`.

NIA que sustentan el legajo: **200 · 230 · 240 · 250 · 315 (Revisada) · 320 · 330 · 450 · 500 · 501 · 505 · 520 · 530 · 540 (Revisada) · 550 · 560 · 580 · 620**, cada una con su título completo en la hoja Marcas.

### 11.2 Memorando de conclusión — `P_Memorando_<Cliente>_<corte>.docx`

Dirigido al socio, para revisión. Sigue la skill `docx`. Estructura:

1. **Encabezado** — firma, cliente y RUC, ejercicio y corte, marco contable confirmado, referencia del papel, preparado / revisado / aprobado por.
2. **Alcance y materialidad** — rubro cubierto, lo que se prueba en otras cédulas, materialidad y error tolerable recibidos, enfoque y RAI.
3. **Cobertura** — los tres bloques con importe y porcentaje, y el resultado del control de cobertura.
4. **Integridad de las fuentes** — períodos cubiertos, archivos faltantes o duplicados y el efecto en el alcance.
5. **Resultado del cruce** — C-1 a C-4, separando artefacto de la fuente y excepción real.
6. **Muestreo** — parámetros, semilla y cobertura de la muestra.
7. **Hallazgos** — tabla con Ref. · Condición · Criterio · Causa · Efecto · Recomendación · Importe expuesto · Papel de respaldo. Un hallazgo, una condición. Cuantifica o marca `NO CUANTIFICADO` con la razón.
8. **Ajustes propuestos y diferencias no corregidas** — acumulados y comparados contra el error tolerable y el umbral trivial (NIA 450).
9. **Asuntos tributarios** — separados de las incorrecciones contables.
10. **Deficiencias de control** — para la carta a la gerencia (NIA 265).
11. **Pendientes y limitaciones** — con el efecto de no obtenerlos.
12. **Conclusión del rubro y decisiones que requieren al socio.**

El memorando **no determina el efecto sobre la opinión**: identifica el asunto y lo remite conforme a NIA 450 y 705.

### 11.3 Construcción — lecciones de ejecución

Lee la skill `xlsx` antes de construir. `openpyxl`, fórmulas reales y nunca resultados pegados, salvo la selección de la muestra, que se pega por diseño. Evita `XLOOKUP`, `FILTER`, `SORT`, `UNIQUE` y matriciales — LibreOffice no las evalúa; usa `INDEX`/`MATCH`, `SUMPRODUCT`, `IFERROR`.

Detalles que rompen la construcción o la presentación:

- **Pinta el relleno de una fila antes de fusionarla**: el valor de una celda fusionada es de solo lectura y solo la celda ancla admite escritura.
- **Un texto que empieza con `=` se interpreta como fórmula.** Las columnas que documentan una fórmula («`J = ET / R`») no pueden empezar con el signo igual.
- **Fija los anchos de columna una sola vez por hoja**, con una rejilla que sirva a todas sus tablas: si cada tabla fija los suyos, la última sobrescribe a las anteriores y trunca su texto.
- **Ajuste de texto en las filas de encabezado** (membrete, normativa, identificación): si no, se cortan a media palabra al imprimir.
- **A3 apaisado** para las cédulas anchas, con `fitToWidth = 1`. Dos páginas de ancho produce páginas compuestas solo de bandas vacías.
- **Encabezados de columna girados 90º** en la cédula de atributos: es lo que permite que quepa en una sola página de ancho y siga siendo legible.
- **No repitas la fila de encabezado de tabla en la impresión** cuando el legajo cierra con secciones de texto: genera una última página con encabezado y sin datos. Usa panel congelado para la vista en pantalla.

---

## 12. Controles de calidad — antes de entregar

1. **Control de cobertura en cero**, verificado sobre valores redondeados a centavos.
2. **Recálculo con LibreOffice**: cero `#REF!`, `#VALUE!`, `#DIV/0!`, `#NAME?`, `#N/A`, `#NUM!`. Un recálculo limpio prueba que las fórmulas evalúan, no que sean correctas: verifica además los totales y los cuadres contra la fuente.
3. **Verificación visual obligatoria**: convertir a PDF, renderizar las páginas y **mirarlas**. Delegar la revisión a un subagente da mejor resultado que revisarlas uno mismo tras escribir el código. Buscar solo defectos objetivos: texto cortado, columnas estrechas, solapamientos, bandas de sección huérfanas, contenido que pisa el pie. **Iterar hasta que no queden defectos bloqueantes.**
4. **Auditoría de marca**: cada hoja con logotipo, membrete de impresión y pie de control.
5. **Ninguna cifra tributaria escrita de memoria**: buscar en el libro que todo porcentaje o umbral tenga fuente citada o la marca de pendiente.
6. **Ningún cruce circular**: confirmar que la columna «libros» no se alimentó de la fuente externa.
7. Entregar el **PDF junto al archivo editable**.

---

## 13. Qué automatizas y qué decide el auditor

| Automatizado | Decide el auditor responsable |
|---|---|
| Validar huellas, períodos y codificación de las fuentes | Confirmar marco contable y materialidad |
| Parsear comprobantes y armar la población | Fijar el `RAI` y el error esperado |
| Clasificar las cuentas en los tres bloques | Aprobar el mapa de cobertura |
| Normalizar llaves y ejecutar el cruce | Calificar una diferencia como error, deficiencia o asunto tributario |
| Calcular `R`, `J`, `n` y seleccionar con semilla | Concluir sobre la razonabilidad del rubro |
| Proyectar contaminación y límite superior | Redactar la conclusión narrativa y proponer ajustes |
| Detectar patrones y concentraciones | Determinar deducibilidad y contingencia |

### Elevar al gerente o socio siempre que

- una partida individual supere el **error tolerable**;
- el **LSI supere el ET**;
- falte un período de la fuente externa o el lote resulte incompleto;
- aparezcan indicios que deban evaluarse bajo **NIA 240**;
- no se disponga del texto normativo para concluir sobre deducibilidad;
- la conclusión del rubro deba ser distinta de SATISFACTORIA.

---

## 14. Cierre — qué informas en el chat

No describas el contenido del archivo: el usuario lo abre. Informa, en este orden:

1. **Cobertura** por bloque y con qué cifras cuadró el control.
2. **Integridad de las fuentes**: períodos sin cobertura y por qué.
3. **Resultado del cruce** C-1 a C-4, separando artefacto de la fuente y excepción real, con los casos mayores.
4. **Muestreo**: población, `ET`, `RAI`, `J`, `n`, semilla y el LSI frente al ET.
5. **Hallazgos reales**, separando incorrecciones contables, deficiencias de control y asuntos tributarios.
6. **Pendientes de información del cliente** y su efecto.
7. **Decisiones que requieren al auditor responsable.**

Nunca ocultes un vacío ni lo llenes con un número para que el papel «se vea completo». Un papel con casillas marcadas como pendientes es evidencia válida; uno con cifras inventadas no lo es.

---

## 15. Ejemplo de uso — ILUSTRATIVO, con datos ficticios

> Cifras inventadas para mostrar el formato de reporte. **No corresponden a ningún cliente.**

**Encargo.** Compañía X, corte al 31 de agosto, NIIF para las PYMES, enfoque sustantivo. De P-00: materialidad global 48.000; error tolerable 24.000; umbral trivial 1.400. RAI 5 %.

**P-01 Cobertura.** Gastos del grupo 6: 780.000. Bloque A 468.000 (60 %, en K-4, H, K-3, E y F) · Bloque B 33.000 (4 %) · Bloque C 279.000 (36 %). Control de cobertura = 0,00. √

**P-02 Integridad.** Ocho meses solicitados; el archivo de un mes resultó ser copia binaria de otro (misma huella MD5) y el anexo transaccional de un mes llegó en 0 bytes. Ese mes se excluye de C-1 y se declara sin cobertura. `LIMITACIÓN AL ALCANCE`.

**P-03 Cruce.** C-1: 180 documentos / 60.000, de los cuales 31.000 corresponden a liquidaciones de compra y notas de crédito que por diseño no figuran en el reporte — **no son excepción**; excepción real: una factura por 990 y 27 recibos sin sustento tributario por 510. C-2: 530 documentos / 48.000, concentrados en una sola factura de 42.500 que supera el error tolerable y se eleva. C-3: 64 documentos / 1.300 de diferencia absoluta.

**P-05 Muestreo.** P = 279.000; R = 2,9957; J = 8.011; n teórico 35; partidas distintas 33 (dos del estrato superior captan dos intervalos cada una); semilla documentada; cobertura 53 % del valor de la población.

**Conclusión.** `SATISFACTORIA CON EXCEPCIONES` en el cruce; `LIMITACIÓN AL ALCANCE` en el mes sin fuente externa; `PENDIENTE DE EJECUCIÓN` en P-06 hasta que el equipo de campo pruebe los atributos.