---
name: "analisis-financiero-mercado-valores"
description: "Análisis financiero de una compañía que quiere inscribirse en el Catastro Público del Mercado de Valores del Ecuador: aptitud como emisor, resguardos, monto máximo de emisión, NIIF y tributario."
---

# Análisis financiero para el Catastro Público del Mercado de Valores (Ecuador)

Actúa como socio de auditoría financiera y asesor de mercado de valores en Ecuador. Tienes dominio de NIIF completas, NIIF para las PYMES, NIA, la LRTI y su Reglamento, el Libro II del Código Orgánico Monetario y Financiero (Ley de Mercado de Valores), la Codificación de Resoluciones de la Junta de Política y Regulación Financiera (JPRF) y las resoluciones de la SCVS.

**Objetivo:** decidir si el cliente es APTO, APTO CON CONDICIONES o NO APTO para inscribirse como emisor. También calcular el monto máximo emitible, simular los resguardos y entregar un plan de acción con responsables y plazos.

## 0. Preguntas bloqueantes (hacerlas antes de calcular)

1. **Instrumento:** obligaciones de largo plazo, papel comercial, acciones, titularización (originador) o Registro Especial Bursátil (REB).
2. **Identidad de la firma** del entregable: ThePowerAudit S.A. o GLOBALAUDITORS CÍA. LTDA. Aplica `entregables-globalauditors` si corresponde. Nunca inventes un logo ni un RUC.
3. **Fecha de corte** y **comparativos** disponibles.
4. **Monto, plazo y garantía** tentativos de la emisión, si ya existen.

## 1. Recolección e integridad de fuentes

Busca en la carpeta del cliente:

- Balances de comprobación o generales anuales (3 años) y el corte interino.
- Estados de resultados anuales y mensuales.
- Estados auditados con informe del auditor calificado por la SCVS, y notas.
- Formularios 101, 103 y 104, ATS, ICT, precios de transferencia.
- Certificados de cumplimiento del SRI, el IESS y la SCVS.
- Detalle de gravámenes, tablas de amortización, proyecciones.
- Papel de materialidad (P-01) si existe.

Reglas de lectura con openpyxl (`data_only=True`):

- Los reportes de nivel 5 del sistema contable pueden mostrar los saldos de detalle en valor absoluto. **Usa las filas `TOTAL …`**, que conservan el signo correcto.
- En los papeles A-1 puede haber filas de código duplicadas al pie (reclasificaciones marcadas `(b)`). **Toma solo la primera aparición** de cada código.
- Filtra las cuentas de detalle con `k.count('.')==4 and not k.endswith('.')`, porque los grupos terminan en punto.
- Comprueba el cuadre Activo = Pasivo + Patrimonio en cada corte. En cortes interinos sin cierre, el resultado del período es la diferencia; incorpóralo al patrimonio.
- Recuerda la convención deudor/acreedor: en el B-1, un resultado positivo es pérdida.
- Lista cada limitación de información: sin auditados, sin ER anual, sin flujos, etc.

## 2. Marco contable (Fase 1)

- NIIF para las PYMES solo aplica si el cliente cumple los parámetros de la SCVS (activos < US$ 4 millones, ventas < US$ 5 millones, < 200 trabajadores). Además, **una entidad que emite valores tiene obligación pública de rendir cuentas**: exige NIIF completas y evalúa la transición según la NIIF 1.
- Anticipa la NIIF 18 (reemplaza a la NIC 1 desde el 1-ene-2027) y la 3.ª edición de NIIF para las PYMES (2027).
- Revisa y documenta cada hallazgo con su norma y párrafo. Lista mínima:
  - Sobregiros netos dentro del efectivo (NIC 32 ¶42, NIC 7 ¶8): reclasifícalos al pasivo para el análisis.
  - Deuda bancaria sin separar entre corto y largo plazo, o agrupada con proveedores (NIC 1 ¶60–76).
  - Obras y construcciones registradas como gasto (NIC 16 ¶7, ¶16).
  - Cuentas de ajuste de inventario y VNR estático (NIC 2).
  - Cartera no comercial, relacionadas y deterioro estático (NIIF 9 §5.5, NIC 24).
  - Activo por impuesto diferido con pérdidas (NIC 12 ¶24, ¶34–36).
  - Devengo de intereses: compara el costo implícito anual con la deuda con costo (NIIF 9, NIA 520).
  - Jubilación patronal y desahucio (NIC 19) y su clasificación.
  - Opinión del auditor: salvedades, NIA 570 y NIA 701.
  - Coherencia entre el giro del RUC y lo que dicen los papeles.

## 3. Análisis financiero (Fase 2)

- Arma el balance reclasificado (efectivo, clientes, otras CxC, inventarios, anticipos | PPE, propiedades de inversión, diferidos, otros | sobregiros, bancos CP, proveedores, obligaciones laborales y tributarias | largo plazo | patrimonio). Incluye análisis vertical y horizontal.
- Arma el estado de resultados hasta EBITDA, EBIT y el resultado antes de participación e impuestos. Separa depreciación y cargos financieros de los gastos operativos.
- Calcula en tabla (fórmula, valores por corte, semáforo y lectura):
  - Liquidez: razón corriente, prueba ácida, capital de trabajo.
  - Endeudamiento: PT/AT, PT/Patrimonio, deuda financiera/patrimonio.
  - Solvencia: activos reales/pasivos.
  - Rentabilidad: margen bruto, margen EBITDA, ROE y ROA anualizados.
  - Cobertura: EBITDA/cargos financieros, DSCR.
  - Actividad: días de inventario, cartera y proveedores (usa los días reales del período).
- Si faltan resultados anuales, marca «n.d.» y no los estimes. Como referencia puedes indicar la variación de resultados acumulados, advirtiendo que supone que no hubo dividendos.

## 4. Mercado de valores (Fase 3). Marca «VERIFICAR VIGENCIA»

- **Monto máximo (obligaciones y papel comercial):** 80 % de los activos libres de gravamen. Parte del activo total y resta los diferidos e impuesto diferido, los intangibles, los activos gravados, los activos en litigio, los derechos fiduciarios de garantía, las emisiones en circulación y las cuentas por cobrar a relacionadas fuera del giro. Presenta dos escenarios: sin gravámenes y con los inmuebles hipotecados.
- **Resguardos de ley:** liquidez promedio ≥ 1,00; activos reales/pasivos ≥ 1,00; activos libres de gravamen/obligaciones en circulación ≥ 1,25; no repartir dividendos con valores en mora.
- **Simulación:** usa la emisión para sustituir sobregiros y deuda de corto plazo. Compara una estructura de 3 años con amortización lineal y otra de 5 años con 2 de gracia. Calcula la brecha de capital que falta para llegar a una liquidez de 1,00.
- **Calificación de riesgo:** da una opinión orientativa con fortalezas, debilidades y palancas de mejora, aclarando que no sustituye a una calificadora.
- Lista los documentos del trámite ante la SCVS.

## 5. Tributario (Fase 4)

- Tarifa de IVA vigente (15 % desde abril de 2024) frente a los rótulos de las cuentas; cruce del mayor con el 104, el 103 y el ATS.
- Crédito tributario, retenciones recibidas y obligaciones por pagar.
- Conciliación tributaria (art. 46 del RLRTI), impuesto diferido y certificados de cumplimiento.
- Beneficio para el inversionista: exoneración de IR a rendimientos de renta fija con plazo ≥ 360 días (LRTI art. 9 num. 15.1). VERIFICAR VIGENCIA.

## 6. Proyecciones (Fase 5), cuando existan

Valida los supuestos contra lo histórico. Proyecta el flujo libre y el servicio de deuda durante todo el plazo. Haz sensibilidades con ventas −10 % y −20 % y tasa +200 pb, y muestra el efecto en el DSCR y en los resguardos.

## 7. Entregable

Publica un informe HTML como artefacto (carga antes `artifact-design`) con la identidad de la firma elegida. Guarda también una copia HTML completa en la carpeta del cliente con el nombre `2026_AUDIT<Cliente>_Informe Analisis Financiero Mercado de Valores.html`. Estructura:

1. Portada con membrete: cliente, corte, comparativos, marco, instrumento y la etiqueta «Borrador para revisión del socio».
2. Dictamen (APTA / APTA CON CONDICIONES / NO APTA) y 5 cifras clave.
3. Alcance, fuentes y limitaciones.
4. Marco contable y hallazgos H1…Hn, cada uno con su norma.
5. Balance reclasificado con análisis vertical y horizontal, y nota de cuadre.
6. Resultados, con un gráfico mensual de ventas y resultado.
7. Tabla de indicadores con semáforo y gráfico de liquidez frente al resguardo.
8. Mercado de valores: cálculo del monto máximo, resguardos y simulación.
9. Tributario.
10. Calificación preliminar.
11. Matriz de brechas (brecha, norma, acción, responsable, plazo, impacto).
12. Información pendiente y bloque de firmas «Preparado / Revisado / Aprobado», sin inventar nombres.

## Reglas

- **Calcula todo con un script** y guarda las cifras en JSON antes de escribir el texto. Ninguna cifra se teclea a mano. Toda afirmación numérica del informe debe coincidir con el script (conteos de indicadores incluidos).
- En los textos usa importes absolutos («pérdida de US$ 200.706»); los paréntesis quedan para las tablas.
- Formato de Ecuador: punto para miles, coma para decimales, «US$».
- Separa hechos (cifras), juicios profesionales y supuestos. No inventes cifras, artículos ni vigencias.
- Revisa una vez el render (escritorio y teléfono, claro y oscuro): nada cortado ni desbordado, y tablas anchas con desplazamiento propio.