---
name: papeles-trabajo-nia
description: "Usar al construir o modificar libros de Excel formulados para auditoría bajo NIA — papeles de trabajo por fase, matrices de riesgos y controles, muestreo, materialidad — especialmente cuando varios libros deben quedar enlazados entre sí."
---

# Papeles de trabajo NIA formulados en Excel

Cómo construir un sistema de papeles de trabajo que calcula, en vez de una plantilla que se llena a mano.

## Principio rector

**Ninguna conclusión se escribe a mano: se calcula desde la evidencia registrada.** La tasa de desviación sale de las partidas cargadas; la eficacia del control sale de comparar esa tasa con la tolerable; el enfoque de auditoría sale de la eficacia. El auditor verifica y firma; no transcribe.

Corolario práctico: si falta un eslabón de la cadena, los siguientes deben mostrar «Sin partidas probadas» o quedar en blanco. Que el sistema **no** permita concluir sin evidencia es una característica, no un defecto.

## Arquitectura por fases

Un libro por fase, más un libro maestro concentrador:

```
00_MAESTRO      parámetros del encargo, índice de papeles, cronograma, tablero
01_PLANIFICACION  aceptación, riesgos, materialidad, control interno, programa
02_CONTROLES      narrativa, recorrido y evaluación de controles POR CICLO
03_EJECUCION      balance, sumarias, pruebas sustantivas, hallazgos, ajustes
04_CONCLUSION     errores, negocio en marcha, KAM, tipo de opinión
05_ENTREGABLES    campos que alimentan las cartas y el informe en Word
```

Cada libro de fase lleva tres hojas técnicas:

- **`00_ENLACE`** — única hoja con fórmulas externas; espeja los parámetros del maestro y los resultados de las fases anteriores. Ninguna otra hoja referencia otro libro.
- **`Z_RESULTADOS`** — publica los resultados de la fase en filas de posición fija. **El orden de las filas es un contrato**: los demás libros y el tablero leen por número de fila. Documentar el mapa de filas y no reordenarlo.
- **`T_TABLAS`** — listas de validación con nombre, rangos de materialidad, escalas de riesgo, tamaños de muestra. Idéntica en todos los libros.

## Doctrina NIA que determina dónde va cada papel

- **NIA 315 (Rev. 2019) 25 y 26(c)**: la narrativa del proceso, la prueba de recorrido y la evaluación del **diseño e implementación** de los controles son valoración del riesgo → van en la fase de controles, no en la ejecución.
- **NIA 330.8 a .17**: solo la **eficacia operativa** es respuesta del auditor → esa sí se prueba después.
- Un control con diseño inadecuado o no implementado **no se prueba**: se documenta como deficiencia (NIA 265).
- **NIA 240.26** presume riesgo de fraude en el reconocimiento de ingresos: el ciclo de ingresos se documenta siempre.
- **NIA 240.32(a)**: los asientos manuales exigen su propio control; el ciclo de cierre contable es de riesgo elevado.
- **NIA 330.15**: un riesgo marcado como significativo recibe tratamiento de riesgo alto sea cual sea su puntaje.
- **NIA 230.14**: el archivo final se conforma dentro de los 60 días desde la fecha del informe.

## Documentar los controles por ciclo, no de forma genérica

Una hoja por cuenta o proceso significativo (efectivo, ingresos, cuentas por cobrar, compras y cuentas por pagar, inventarios, PPE, nómina, impuestos, obligaciones financieras, patrimonio y partes relacionadas, cierre contable, ITGC). Cada hoja con cuatro secciones en orden:

1. **Narrativa** — nueve aspectos: objetivo y vínculo con los estados financieros, sistemas y módulos, personal clave y segregación, volumen y frecuencia, políticas y matrices de autorización, punto de inicio y fin del flujo, cambios del período, tercerización (NIA 402), riesgos asociados.
2. **Recorrido** — ocho pasos con documento generado, sistema, área, responsable, código del control clave, verificación, documento inspeccionado y desviación.
3. **Riesgos y controles** — cinco controles con riesgo, afirmación, tipo, naturaleza, frecuencia, evidencia y si es clave. El auditor solo califica **diseño** e **implementación**; la hoja concluye el resto.
4. **Conclusión del ciclo** — dos preguntas de cierre más la conclusión narrativa obligatoria.

Una fila de resumen calculada (fila 8) por hoja, consolidada después en el índice de la fase.

## Fórmulas que resuelven los casos difíciles

```excel
' aptitud del control para probar su eficacia
=IF($L{r}="","",IF(AND($I{r}="Sí",OR($J{r}="Adecuado",$J{r}="Parcialmente adecuado"),$K{r}="Sí"),"Sí","No"))

' tamaño de muestra según frecuencia, duplicado si el diseño es parcial
=IF($M{r}<>"Sí","",IFERROR(VLOOKUP($H{r},TBL_MUESTRA,2,FALSE)*IF($J{r}="Parcialmente adecuado",2,1),""))

' materialidad global con calibración por riesgo
=MEDIAN(D17,D18*D21,D19)      ' %mín, %sugerido × factor de riesgo, %máx

' contar controles distintos en una cédula de detalle
=IFERROR(SUMPRODUCT(($B$12:$B$211<>"")/COUNTIF($B$12:$B$211,$B$12:$B$211&"")),0)
```

Trampas verificadas:
- `SUMPRODUCT` sobre un rango con `""` devuelve `#VALUE!` → que las fórmulas de apoyo devuelvan `0`, no `""`.
- `SUMPRODUCT(ABS(rango))` falla igual → usar `SUMIF(">0") - SUMIF("<0")`.
- Nombres de hoja con guion o dígito inicial **deben ir entre comillas simples** en toda fórmula: `'P-01_PARAMETROS'!C8`, `'00_ENLACE'!$C$5`.
- `openpyxl` no permite escribir en una `MergedCell` que no sea la superior izquierda.
- Un `titulo_seccion` y un `fila_encabezado` en la misma fila se pisan; verificar el mapa de filas antes de generar.

## Vínculos externos entre libros (sin Excel)

Se inyectan a mano en el OOXML tras guardar con openpyxl:

1. `xl/externalLinks/externalLinkN.xml` con `sheetNames` y `sheetDataSet` en caché.
2. `xl/externalLinks/_rels/externalLinkN.xml.rels` con `TargetMode="External"` y el nombre de archivo relativo.
3. `Override` en `[Content_Types].xml`.
4. `<externalReferences>` en `workbook.xml`, insertado **antes** de `<definedNames>`.
5. `Relationship` en `xl/_rels/workbook.xml.rels`.
6. `<calcPr calcId="191029" fullCalcOnLoad="1"/>`.

**Crítico:** cada `<externalReference>` debe declarar su propio `xmlns:r`, porque openpyxl no declara el prefijo `r:` en la raíz del workbook. Sin eso, LibreOffice y Excel rechazan el archivo:

```python
refs.append(f'<externalReference xmlns:r="{NS_REL}" r:id="{rid}"/>')
```

El índice en la lista de referencias es el `[1]`, `[2]`, … de las fórmulas. Al reordenar o insertar un libro **hay que reindexar todas las fórmulas de todos los libros**, y hacerlo en el orden correcto (`[4]→[5]` antes que `[3]→[4]`). Verificar después leyendo los `.rels` de cada archivo generado y comparándolos con el mapa esperado.

LibreOffice **nunca** actualiza vínculos externos, ni siquiera los que él mismo escribió. Que no los resuelva en la verificación no es un defecto; Excel sí los resuelve.

## Verificación

1. Recalcular cada libro con `soffice --headless --convert-to xlsx`, recargar con `openpyxl(data_only=True)` y buscar `#REF!`, `#VALUE!`, `#DIV/0!`, `#NAME?`, `#N/A`, `#NUM!`. Objetivo: **cero errores**.
2. Comprobar el mapa de vínculos: para cada archivo, leer los `externalLinkN.xml.rels` y verificar que el orden coincide con los índices usados en las fórmulas.
3. **Prueba funcional de la cadena**: sembrar datos realistas en una copia (recorrido completo, controles con distintos diseños, partidas con desviaciones), recalcular y comprobar que las conclusiones encadenadas salen correctas de punta a punta. Es la única forma de detectar un eslabón roto.
4. Auditoría de marca: logo y membrete de impresión en todas las hojas.