---
name: fase-final
description: Fase 3 de AUDITOR_4.0 — Visita final y cierre de la auditoría bajo NIA. Sumarias al cierre, actualización desde el corte interino, pruebas sustantivas, confirmaciones, estimaciones, hechos posteriores, empresa en marcha, resumen de diferencias NIA 450, carta de representación NIA 580, borrador del informe NIA 700/705/706 y soporte del informe de cumplimiento tributario. Usar cuando se pida "auditoría final", "visita final", "cierre de la auditoría", "ajustes propuestos", "carta de representación", "hechos posteriores", "borrador del informe" o "ICT".
---

# Fase 3 — Final (cierre)

Requisito: balances al cierre del ejercicio (`corte_final` de `encargo.json`)
validados con el Paso 3 del `motor-auditoria-nia`, y las fases 1 y 2 con sus
pendientes identificados. Los papeles van en `encargos/<PREFIJO>/03_Final/`.

## Índice de papeles de la fase

| Ref. | Papel | NIA | Cómo se produce |
|---|---|---|---|
| P-01.2 | **Materialidad — reevaluación final**: recalcula con los estados financieros finales; si resulta menor que la usada, evalúa si los procedimientos y muestras siguen siendo suficientes. Es la materialidad contra la que se evalúa AJ-01 | 320.12-13, 450.10 | `build_materialidad.py` con los balances de cierre; decisión del gerente o socio |
| F-SUM | Sumarias finales y estados comparativos al cierre | 330, 500 | Generadores de `auditoria-preliminar-nia` con los balances de cierre (`meses` hasta DICIEMBRE) |
| F-RF | Actualización (roll-forward) del corte interino al cierre | 330 | Por cada cuenta probada en la fase 2: saldo interino, movimiento y procedimientos sobre el periodo restante |
| F-SUS | Pruebas sustantivas al cierre por ciclo | 330, 500, 530 | Skills de área (`muestreo-cierres-caja-efectivo-nia`, `auditoria-inventarios`, `muestreo-gastos-nia`, `auditoria-nomina-nia`, `papel-k3-impuestos`) y `papeles-trabajo-nia` para los demás ciclos |
| F-CONF | Confirmaciones externas (bancos, clientes, proveedores, abogados) | 505, 501 | Control de envío y respuesta; procedimientos alternativos para las no respondidas. Nunca se da por confirmada una cuenta sin respuesta |
| F-COR | Pruebas de corte de ventas, compras e inventarios | 500 | Papel con las transacciones antes y después del cierre |
| F-EST | Estimaciones contables (deterioro de cartera, VNR, beneficios definidos, impuesto diferido, provisiones) | 540 | Revisión de método, supuestos y datos; informes de actuario o peritos como evidencia (NIA 500/620) |
| F-PR | Partes relacionadas al cierre y revelaciones | 550 | Actualiza PL-06 |
| F-HP | Hechos posteriores al cierre | 560 | Procedimientos hasta la fecha del informe; actas, abogados, cobros y pagos posteriores |
| F-EM | Empresa en marcha — evaluación final | 570 | Actualiza PL-07 con cifras de cierre y plan de la dirección |
| F-RA | Revisión analítica final | 520 | Compara estados finales contra RA-01 y expectativas |
| AJ-01 | Resumen de ajustes y diferencias (corregidas y no corregidas) | 450 | Acumula todas las diferencias propuestas de las fases 2 y 3 frente a materialidad global y de ejecución. **Nunca se contabilizan** |
| F-EF | Revisión de estados financieros y notas contra el marco confirmado | 700 | Lista de verificación de revelaciones de NIIF completas o NIIF para las PYMES, según `marco` |
| F-REP | Carta de representación de la dirección (borrador) | 580 | Word sobre el modelo de la firma, fechada a la fecha del informe |
| F-COM | Comunicación con los responsables del gobierno | 260, 265 | Asuntos significativos, deficiencias significativas, diferencias no corregidas |
| F-INF | Borrador del informe del auditor | 700, 701, 705, 706 | Word con la identidad de la firma, marcado `BORRADOR — OPINIÓN A DEFINIR POR EL SOCIO` |
| F-ICT | Soporte para el informe de cumplimiento tributario | 250 | Anexos y conciliaciones que pida el SRI para el ejercicio: confirma el formato y la resolución vigentes antes de preparar; si no puedes, `PENDIENTE DE VERIFICACIÓN NORMATIVA` |
| F-CIE | Lista de cierre del legajo y revisión del socio | 220, 230 | Celdas amarillas vacías = 0, marcas pendientes = 0 o justificadas, firmas de revisión |

## Cómo trabajar

1. Empieza por F-SUM, F-RF y P-01.2: sin cifras de cierre validadas y materialidad
   reevaluada no hay fase final.
2. Lleva las diferencias de la fase 2 a AJ-01 y agrega las nuevas en cuanto
   aparezcan. Compara el total no corregido contra la materialidad en cada
   actualización e informa al usuario cuando se acerque al umbral.
3. **No determines la opinión.** En F-INF prepara el texto según el tipo de
   informe que **indique el socio** (sin salvedades, con salvedades, adversa,
   abstención; párrafos de énfasis u otros asuntos). Si el socio no lo ha
   indicado, deja la sección de opinión marcada y lista los asuntos que debe
   considerar (AJ-01, limitaciones, empresa en marcha, hechos posteriores).
4. Las cartas e informes usan el modelo de la firma del encargo. Los modelos están
   en `formatos_referencias/<firma_id>/` (o `formatos_referencias/comunes/`); si el que necesitas no está, pídelo y no lo inventes.
5. Antes de entregar al socio, pide al subagente `revisor-calidad` que revise
   todo el legajo (`01_`, `02_` y `03_`).

## Cierre de la fase

Informa: diferencias corregidas y no corregidas frente a la materialidad,
confirmaciones pendientes y procedimientos alternativos aplicados, asuntos de
empresa en marcha y hechos posteriores, revelaciones faltantes en las notas,
lo pendiente del cliente para emitir y las decisiones del socio (tipo de
opinión, párrafos adicionales, fecha del informe).
