# -*- coding: utf-8 -*-
"""Lee los balances de comprobación del cliente, los normaliza a CSV y ejecuta
las cuatro validaciones obligatorias.

Uso típico:

    pip install xlrd --break-system-packages        # lector de .xls binarios
    python3 extraer_meses.py --dir <carpeta-con-los-balances> \\
        --meses ENERO FEBRERO MARZO ABRIL MAYO JUNIO JULIO \\
        --anterior "*DIC2025*.xls"

Produce `tb_<mes>.csv` por cada mes y `tb_dic_anterior.csv` para el cierre del
ejercicio anterior, y deja el informe de validaciones en pantalla.

NO inventa datos. Si un mes falta, lo dice y no lo deriva de los demás. Si una
validación no cuadra, termina con código de salida distinto de cero: NO
construyas papeles mientras eso ocurra.
"""
import argparse
import glob
import os
import re
import sys

import pandas as pd

# Disposición habitual del ERP ecuatoriano, por índice de columna (base 0).
# VERIFÍCALA EN CADA CLIENTE con --inspeccionar antes de confiar en ella.
COLS_POR_DEFECTO = dict(cuenta=1, nombre=5, ant=8, deb=9, cred=10, act=13)

RE_CUENTA = re.compile(r"^\d(\.\d+)*\.?$")
RE_PERIODO = re.compile(r"MES DE\s*:?\s*([A-ZÁÉÍÓÚÑ]+)\s*(\d{4})")


def leer(path):
    """Devuelve el DataFrame crudo, sin encabezados."""
    return pd.read_excel(path, header=None)


def periodo_de(df):
    txt = " ".join(str(x) for x in df.head(15).values.flatten() if pd.notna(x))
    m = RE_PERIODO.search(txt.upper())
    return f"{m.group(1)} {m.group(2)}" if m else "?"


def parse(path, cols):
    """Extrae (periodo, DataFrame) de un balance de comprobación."""
    df = leer(path)
    filas = []
    for i in range(len(df)):
        try:
            cta, nom = df.iat[i, cols["cuenta"]], df.iat[i, cols["nombre"]]
        except IndexError:
            continue
        if pd.isna(cta) or pd.isna(nom):
            continue
        cta = str(cta).strip()
        if not RE_CUENTA.match(cta):          # descarta encabezados de página
            continue
        nom = re.sub(r"[.\s]+$", "", str(nom)).strip()

        def num(c):
            try:
                v = df.iat[i, cols[c]]
            except IndexError:
                return 0.0
            return float(v) if pd.notna(v) and isinstance(v, (int, float)) else 0.0

        filas.append(dict(cuenta=cta, nombre=nom, ant=num("ant"),
                          deb=num("deb"), cred=num("cred"), act=num("act")))
    return periodo_de(df), pd.DataFrame(filas)


def buscar(directorio, patron):
    """Archivos que coinciden con el patrón, en cualquier extensión soportada."""
    encontrados = []
    for ext in ("xls", "xlsx", "XLS", "XLSX"):
        encontrados += glob.glob(os.path.join(directorio, f"*.{ext}"))
    if patron.startswith("*") or "*" in patron:
        return sorted(glob.glob(os.path.join(directorio, patron)))
    return sorted(p for p in encontrados if patron.upper() in os.path.basename(p).upper())


# --------------------------------------------------------------- validaciones
def val_identidad(t):
    """saldo anterior + débito − crédito − saldo actual ≈ 0, por cuenta."""
    return (t.ant + t.deb - t.cred - t.act).abs().max()


def val_cuadre_grupos(t):
    """Suma de TODOS los grupos de nivel 1 = 0.

    Recorre los grupos que existan en el archivo. Es frecuente un grupo 7
    (impuesto a la renta y participación de trabajadores) que solo aparece en
    diciembre; si lo omites, el balance no cuadra.
    """
    g1 = t[t.cuenta.str.rstrip(".").str.count(r"\.") == 0]
    return g1.act.sum(), sorted(g1.cuenta.tolist())


def val_apertura_cero(t):
    """Devuelve las cuentas de balance (grupos 1, 2 y 3) con saldo anterior 0."""
    bal = t[t.cuenta.str.rstrip(".").str.count(r"\.") == 0]
    bal = bal[bal.cuenta.str[0].isin(list("123"))]
    return all(abs(v) < 0.005 for v in bal.ant) and len(bal) > 0


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--dir", required=True, help="carpeta con los balances del cliente")
    ap.add_argument("--meses", nargs="+", required=True,
                    help="meses entregados, en orden y en mayúsculas")
    ap.add_argument("--anterior", default="",
                    help="patrón del balance de diciembre del ejercicio anterior")
    ap.add_argument("--salida", default=".", help="carpeta donde escribir los CSV")
    ap.add_argument("--inspeccionar", metavar="ARCHIVO", default="",
                    help="imprime las 20 primeras filas de un archivo para verificar "
                         "la disposición de columnas, y termina")
    ap.add_argument("--cols", default="",
                    help="disposición alterna, p. ej. cuenta=0,nombre=2,ant=5,deb=6,cred=7,act=8")
    args = ap.parse_args()

    if args.inspeccionar:
        df = leer(args.inspeccionar)
        pd.set_option("display.max_columns", None, "display.width", 250)
        print(df.head(20))
        return 0

    cols = dict(COLS_POR_DEFECTO)
    if args.cols:
        for par in args.cols.split(","):
            k, v = par.split("=")
            cols[k.strip()] = int(v)

    os.makedirs(args.salida, exist_ok=True)
    meses = [m.upper() for m in args.meses]
    datos, faltan, problemas = {}, [], []

    print("=" * 78)
    print("LECTURA Y VALIDACIÓN 1 — identidad aritmética por cuenta")
    print("=" * 78)

    objetivos = [(m, m) for m in meses]
    if args.anterior:
        objetivos.append(("ANTERIOR", args.anterior))

    for etiqueta, patron in objetivos:
        encontrados = buscar(args.dir, patron)
        if not encontrados:
            faltan.append(etiqueta)
            print(f"{etiqueta:<10} FALTA — no se encontró ningún archivo para «{patron}»")
            continue
        if len(encontrados) > 1:
            problemas.append(f"{etiqueta}: {len(encontrados)} archivos coinciden con «{patron}»")
            print(f"{etiqueta:<10} AMBIGUO — coinciden {len(encontrados)} archivos; "
                  f"afina el patrón:\n            " +
                  "\n            ".join(os.path.basename(p) for p in encontrados))
            continue

        per, t = parse(encontrados[0], cols)
        if t.empty:
            problemas.append(f"{etiqueta}: 0 cuentas leídas — verifica la disposición de columnas con --inspeccionar")
            print(f"{etiqueta:<10} 0 CUENTAS — la disposición de columnas no coincide. "
                  f"Usa --inspeccionar «{encontrados[0]}»")
            continue

        datos[etiqueta] = t
        desv = val_identidad(t)
        marca = "OK " if desv < 0.005 else "REVISAR"
        if desv >= 0.005:
            problemas.append(f"{etiqueta}: identidad aritmética desvío máx. {desv:,.4f}")
        nombre = "tb_dic_anterior.csv" if etiqueta == "ANTERIOR" else f"tb_{etiqueta.lower()}.csv"
        t.to_csv(os.path.join(args.salida, nombre), index=False)
        print(f"{etiqueta:<10} periodo={per:<15} cuentas={len(t):<5} "
              f"desvío_máx={desv:.2e}  {marca}  → {nombre}")

    print()
    print("=" * 78)
    print("VALIDACIÓN 2 — encadenamiento mensual (saldo actual mes N = saldo anterior mes N+1)")
    print("=" * 78)
    for a, b in zip(meses, meses[1:]):
        if a in datos and b in datos:
            ma = datos[a].set_index("cuenta").act
            mb = datos[b].set_index("cuenta").ant
            com = ma.index.intersection(mb.index)
            d = (ma[com] - mb[com]).abs().max()
            marca = "OK " if d < 0.005 else "REVISAR"
            if d >= 0.005:
                problemas.append(f"encadenamiento {a}->{b}: desvío máx. {d:,.4f}")
            print(f"{a:<10} -> {b:<10} desvío_máx={d:>12.4f}  cuentas_comunes={len(com):<5} {marca}")

    print()
    print("=" * 78)
    print("VALIDACIÓN 3 — cuadre del balance: suma de TODOS los grupos de nivel 1 = 0")
    print("=" * 78)
    for etiqueta, t in datos.items():
        suma, grupos = val_cuadre_grupos(t)
        marca = "OK " if abs(suma) < 0.005 else "NO CUADRA"
        if abs(suma) >= 0.005:
            problemas.append(f"{etiqueta}: los grupos de nivel 1 suman {suma:,.2f}")
        print(f"{etiqueta:<10} grupos={','.join(grupos):<28} suma={suma:>15,.2f}  {marca}")

    print()
    print("=" * 78)
    print("VALIDACIÓN 4 — ¿el primer mes abre en cero?")
    print("=" * 78)
    primero = meses[0]
    if primero in datos:
        if val_apertura_cero(datos[primero]):
            print(f"{primero}: TODAS las cuentas de balance abren en CERO.")
            print("  → Estos archivos NO contienen los saldos al cierre del ejercicio anterior.")
            print("  → Pide el balance de comprobación de diciembre del año anterior (NIA 510).")
            print("  → NO derives el saldo de apertura.")
            if "ANTERIOR" not in datos:
                problemas.append(f"{primero} abre en cero y no se entregó el balance del cierre anterior")
        else:
            print(f"{primero}: las cuentas de balance traen saldo anterior. Arrastre correcto.")

    print()
    print("=" * 78)
    if faltan:
        print("PENDIENTE DE INFORMACIÓN DEL CLIENTE:", ", ".join(faltan))
    if problemas:
        print("REQUIERE REVISIÓN DEL AUDITOR RESPONSABLE:")
        for p in problemas:
            print("  -", p)
        print()
        print("NO construyas papeles de trabajo mientras estos puntos no estén resueltos.")
        return 1
    if faltan:
        return 1
    print("Las cuatro validaciones cuadran. Puedes construir los papeles.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
