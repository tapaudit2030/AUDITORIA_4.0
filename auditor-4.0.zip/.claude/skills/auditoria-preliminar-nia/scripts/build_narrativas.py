# -*- coding: utf-8 -*-
"""Narrativas y pruebas de controles por proceso — formato ThePowerAudit S.A."""
from openpyxl import Workbook
from openpyxl.styles import Alignment
from openpyxl.worksheet.datavalidation import DataValidation
from firma import *
import re
from narrativas_data import PROCESOS

ASEV6 = ["Existencia", "Integridad", "Presentación", "Exactitud", "Propiedad", "Valuación"]

NOTA_SEGREGACION = (
    "IMPORTANTE — Con base en el entendimiento del proceso se identifican los riesgos que amenacen la integridad, "
    "existencia, exactitud, presentación y revelación de las cifras. Antes de empezar a revisar cada actividad "
    "debemos concluir si el proceso cuenta con una adecuada segregación de funciones. La función de la segregación "
    "de funciones es asegurar que un individuo no pueda llevar a cabo todas las fases de una operación, desde su "
    "autorización, pasando por la custodia de activos y el mantenimiento de los registros maestros necesarios. En "
    "los casos en que no existe una adecuada segregación de funciones es probable que los controles implementados "
    "no sean confiables.")

NOTA_RECORRIDO = (
    "PRUEBA DE RECORRIDO — El auditor realiza pruebas de recorrido como parte de la obtención del entendimiento "
    "del sistema de información relevante a la emisión de información financiera, para identificar y entender "
    "mejor lo que podría fallar en el proceso e identificar los controles relevantes que la gerencia haya "
    "implementado. Con ello se obtiene información suficiente para evaluar el diseño y la implementación de los "
    "controles relevantes sin realizar procedimientos adicionales. Una prueba de recorrido que combine indagación, "
    "observación e inspección es generalmente suficiente para evaluar diseño e implementación; NO es suficiente "
    "para concluir sobre la eficacia operativa del control.")

MARCAS_NARR = [
    ("a", "El control se cumple / la condición se verificó."),
    ("r", "El control no se cumple / la condición no se verificó."),
    ("√", "Verificado mediante inspección de documentación."),
    ("Φ", "Verificado mediante observación directa del control en ejecución."),
    ("N/A", "No aplica al proceso; debe justificarse la razón."),
    ("P/I", "Pendiente de información o de entrevista."),
]

indice = []
LIBROS = []


def bloque_titulo(ws, r, texto, nc):
    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=nc)
    c = ws.cell(r, 1, texto)
    c.font = F(9, True, MARCA_AMBAR)
    for k in range(1, nc + 1):
        ws.cell(r, k).fill = FILL_TITULO
        ws.cell(r, k).border = BOT
    return r + 1


def texto_largo(ws, r, texto, nc, col_ini=1, fuente=None):
    ws.merge_cells(start_row=r, start_column=col_ini, end_row=r, end_column=nc)
    c = ws.cell(r, col_ini, texto)
    c.font = fuente or F(8)
    c.alignment = Alignment(wrap_text=True, vertical="top")
    ws.row_dimensions[r].height = max(13, 11 * (len(texto) // (nc * 11) + 1))
    return r + 1


# ============================================================ hojas por proceso
for P in PROCESOS:
    wb = Workbook()
    wb.remove(wb.active)
    # ---------------------------------------------------- hoja de entendimiento
    NC = 10
    ws = wb.create_sheet(P["hoja"])
    anchos(ws, [6, 34, 26, 20, 16, 12, 12, 12, 14, 32])
    ref_txt = P["ref"] if P["confirmada"] else P["ref"] + " (prov.)"
    r = encabezado(ws, ref_txt, f"Entendimiento del proceso de {P['nombre'].lower()} y "
                                f"pruebas de controles", NC)
    r = seccion(ws, r, "Objetivo", [
        "Realizar el recorrido del proceso, identificar los controles relevantes y el tipo de control al que "
        "pertenecen, evaluar su diseño e implementación, y documentar el entendimiento del ciclo conforme a la "
        "NIA 315.",
        f"Ciclo contable relacionado: {P['ciclo_cuenta']}.",
    ], NC)
    r = seccion(ws, r, "Procedimiento", [
        "Entrevistar a la persona encargada del área, observar la ejecución de los controles e inspeccionar la "
        "documentación de una transacción seguida de principio a fin.",
    ], NC)
    r = seccion(ws, r, "Alcance", [
        "Se realizará el entendimiento de los principales procesos a cargo del responsable del área. El alcance "
        "de este papel es la evaluación del DISEÑO y la IMPLEMENTACIÓN de los controles; la eficacia operativa "
        "requiere pruebas de controles de mayor extensión que no forman parte de la planificación aprobada, en la "
        "que se definió un enfoque sustantivo.",
    ], NC)

    r = bloque_normativa(ws, r, NC, P["nias"],
        marco_niif="NIIF para las PYMES — marco de información financiera aplicable a la entidad.",
        otras=[("Fuente", f"Narrativas del archivo del ejercicio anterior de {CLIENTE} y entrevista del ejercicio corriente."),
               ("Equivalencia", f"Referencia del archivo 2024: {P['ref_2024']}."
                                if P["ref_2024"] else
                                "Sin referencia equivalente en el archivo 2024.")])

    r = texto_largo(ws, r, NOTA_SEGREGACION, NC, fuente=F(8, italic=True))
    r += 1
    r = texto_largo(ws, r, NOTA_RECORRIDO, NC, fuente=F(8, italic=True))
    r += 1

    # datos de la entrevista
    r = bloque_titulo(ws, r, "DATOS DE LA ENTREVISTA", NC)
    for et in ("Entrevistador", "Entrevistado", "Departamento", "Cargo", "Sistema contable",
               "Responsable del procedimiento", "Fecha y hora de la entrevista"):
        ws.cell(r, 1, "").border = BOX
        c = ws.cell(r, 2, et); c.font = F(8, True); c.border = BOX
        ws.merge_cells(start_row=r, start_column=3, end_row=r, end_column=NC)
        for k in range(3, NC + 1):
            ws.cell(r, k).fill = FILL_AMARILLO; ws.cell(r, k).border = BOX
        ws.row_dimensions[r].height = 14
        r += 1
    r += 1

    # riesgos significativos del negocio
    r = bloque_titulo(ws, r, "RIESGO(S) SIGNIFICATIVO(S) DEL NEGOCIO", NC)
    r = cabecera(ws, r, ["No.", "DESCRIPCIÓN", "", "REF. P/T",
                         "IMPLICACIONES EN LOS EF (INCLUYA LA ASEVERACIÓN)", "", "", "", "", ""], alto=26)
    for n, desc, asev in P["riesgos_negocio"]:
        ws.cell(r, 1, n).font = F(8, True)
        ws.cell(r, 1).alignment = Alignment(horizontal="center")
        ws.merge_cells(start_row=r, start_column=2, end_row=r, end_column=3)
        c = ws.cell(r, 2, desc); c.font = F(8)
        c.alignment = Alignment(wrap_text=True, vertical="top")
        ws.cell(r, 4).fill = FILL_AMARILLO
        ws.merge_cells(start_row=r, start_column=5, end_row=r, end_column=NC)
        c = ws.cell(r, 5, asev); c.font = F(8, True)
        c.alignment = Alignment(wrap_text=True, vertical="top")
        for k in range(1, NC + 1): ws.cell(r, k).border = BOX
        ws.row_dimensions[r].height = max(22, 11 * (len(desc) // 58 + 1))
        r += 1
    for _ in range(3):      # filas libres
        ws.cell(r, 1, "").border = BOX
        ws.merge_cells(start_row=r, start_column=2, end_row=r, end_column=3)
        ws.merge_cells(start_row=r, start_column=5, end_row=r, end_column=NC)
        for k in range(1, NC + 1):
            ws.cell(r, k).fill = FILL_AMARILLO; ws.cell(r, k).border = BOX
        r += 1
    r = texto_largo(ws, r, "El auditor deberá documentar cada riesgo significativo, así como especificar su "
                           "papel de trabajo y su implicación en los estados financieros.", NC,
                    fuente=F(7, italic=True))
    r += 1

    # clases significativas de transacciones
    r = bloque_titulo(ws, r, "CLASES SIGNIFICATIVAS DE TRANSACCIONES", NC)
    r = cabecera(ws, r, ["Cuenta", "DESCRIPCIÓN", "", "REF. P/T", "TIPO",
                         "ASEVERACIÓN(ES) EN LOS EF", "", "", "", ""], alto=26)
    for cod, desc, tipo, asev in P["transacciones"]:
        desc = re.sub(r"\s*\((?:USD|[^)]*USD)[^)]*\)", "", desc)   # sin saldos de otros encargos
        ws.cell(r, 1, cod).font = F(8, True)
        ws.merge_cells(start_row=r, start_column=2, end_row=r, end_column=3)
        ws.cell(r, 2, desc).font = F(8)
        ws.cell(r, 4).fill = FILL_AMARILLO
        ws.cell(r, 5, tipo).font = F(8, True)
        ws.cell(r, 5).alignment = Alignment(horizontal="center")
        ws.merge_cells(start_row=r, start_column=6, end_row=r, end_column=NC)
        c = ws.cell(r, 6, asev); c.font = F(8)
        c.alignment = Alignment(wrap_text=True, vertical="top")
        for k in range(1, NC + 1): ws.cell(r, k).border = BOX
        r += 1
    r += 1

    # mapa del proceso
    r = bloque_titulo(ws, r, "OBJETIVOS DEL PROCESO", NC)
    r = texto_largo(ws, r, P["objetivo"], NC)
    r = bloque_titulo(ws, r, "ENTRADA", NC)
    for e in P["entrada"]:
        r = texto_largo(ws, r, "• " + e, NC)
    r = bloque_titulo(ws, r, "ACTIVIDADES — ETAPAS DEL PROCESO", NC)
    r = cabecera(ws, r, ["N°", "Etapa", "Descripción de la actividad", "", "",
                         "Responsable", "", "Sistema utilizado", "", "Documento que genera"], alto=26)
    for i, (etapa, desc) in enumerate(P["etapas"], start=1):
        ws.cell(r, 1, i).font = F(8, True)
        ws.cell(r, 1).alignment = Alignment(horizontal="center")
        c = ws.cell(r, 2, etapa); c.font = F(8, True)
        c.alignment = Alignment(wrap_text=True, vertical="top")
        ws.merge_cells(start_row=r, start_column=3, end_row=r, end_column=5)
        c = ws.cell(r, 3, desc); c.font = F(8)
        c.alignment = Alignment(wrap_text=True, vertical="top")
        ws.merge_cells(start_row=r, start_column=6, end_row=r, end_column=7)
        ws.merge_cells(start_row=r, start_column=8, end_row=r, end_column=9)
        for k in list(range(6, NC + 1)):
            ws.cell(r, k).fill = FILL_AMARILLO
        for k in range(1, NC + 1): ws.cell(r, k).border = BOX
        ws.row_dimensions[r].height = max(24, 11 * (len(desc) // 62 + 1))
        r += 1
    r = bloque_titulo(ws, r, "SALIDA", NC)
    for sx in P["salida"]:
        r = texto_largo(ws, r, "• " + sx, NC)
    r = bloque_titulo(ws, r, "SISTEMAS DE INFORMACIÓN", NC)
    r = cabecera(ws, r, ["", "SISTEMA", "DESCRIPCIÓN", "", "", "", "",
                         "¿Registro automático o manual?", "", "Controles generales de TI relevantes"], alto=26)
    for sis, desc in P["sistemas"]:
        c = ws.cell(r, 2, sis); c.font = F(8, True)
        c.alignment = Alignment(wrap_text=True, vertical="top")
        ws.merge_cells(start_row=r, start_column=3, end_row=r, end_column=7)
        c = ws.cell(r, 3, desc); c.font = F(8)
        c.alignment = Alignment(wrap_text=True, vertical="top")
        ws.merge_cells(start_row=r, start_column=8, end_row=r, end_column=9)
        for k in (8, 9, 10):
            ws.cell(r, k).fill = FILL_AMARILLO
        for k in range(1, NC + 1): ws.cell(r, k).border = BOX
        ws.row_dimensions[r].height = 24
        r += 1
    r += 1

    # personal involucrado y politicas
    r = bloque_titulo(ws, r, "1.  PERSONAL INVOLUCRADO EN EL PROCESO", NC)
    r = cabecera(ws, r, ["", "NOMBRE", "CARGO", "DEPARTAMENTO", "Funciones que ejecuta", "", "",
                         "¿Concentra funciones incompatibles?", "", "Descripción del conflicto"], alto=26)
    for _ in range(6):
        ws.merge_cells(start_row=r, start_column=5, end_row=r, end_column=7)
        ws.merge_cells(start_row=r, start_column=8, end_row=r, end_column=9)
        for k in range(2, NC + 1):
            ws.cell(r, k).fill = FILL_AMARILLO
        for k in range(1, NC + 1): ws.cell(r, k).border = BOX
        ws.row_dimensions[r].height = 16
        r += 1
    r += 1
    r = bloque_titulo(ws, r, "2.  POLÍTICAS Y PROCEDIMIENTOS", NC)
    r = cabecera(ws, r, ["", "Documento", "Fecha de aprobación", "Fecha de última actualización",
                         "¿Vigente?", "", "Responsable de su custodia", "", "Observación", ""], alto=26)
    for _ in range(4):
        ws.merge_cells(start_row=r, start_column=5, end_row=r, end_column=6)
        ws.merge_cells(start_row=r, start_column=7, end_row=r, end_column=8)
        ws.merge_cells(start_row=r, start_column=9, end_row=r, end_column=NC)
        for k in range(2, NC + 1):
            ws.cell(r, k).fill = FILL_AMARILLO
        for k in range(1, NC + 1): ws.cell(r, k).border = BOX
        ws.row_dimensions[r].height = 16
        r += 1
    r += 1

    # cuestionario de entendimiento
    dvr = dv_riesgo(ws)
    dvm = dv_lista(ws, MARCAS_LISTA, "Marca de auditoría")
    dvsn = dv_lista(ws, SINO_LISTA, "Sí / No")
    r = bloque_titulo(ws, r, "3.  CUESTIONARIO DE ENTENDIMIENTO", NC)
    if P["preguntas"]:
        r = texto_largo(ws, r,
            "Banco de preguntas consolidado de los papeles de la firma. Las respuestas del ejercicio anterior NO "
            "se trasladan: deben levantarse de nuevo en la entrevista de 2026. El nivel de riesgo se selecciona "
            "de la lista ALTO / MEDIO / BAJO.", NC, fuente=F(7, italic=True))
    else:
        r = texto_largo(ws, r,
            "La firma no levantó un cuestionario estructurado para este proceso en el ejercicio anterior: el "
            "entendimiento se documentó en forma narrativa. Se incluye la estructura en blanco para levantarlo "
            "en 2026, y el banco de riesgos de la hoja siguiente sirve de guía para formular las preguntas.",
            NC, fuente=F(8, True, ROJO))
    r = cabecera(ws, r, ["No.", "Pregunta", "Respuesta del entrevistado", "", "", "",
                         "NIVEL DE RIESGO", "Controles identificados", "", "Evidencia obtenida"], alto=28)
    q_ini = r
    n = 0
    if P["preguntas"]:
        for seccion_nombre, preguntas in P["preguntas"]:
            ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=NC)
            c = ws.cell(r, 1, seccion_nombre); c.font = F(8, True)
            for k in range(1, NC + 1):
                ws.cell(r, k).fill = FILL_SUB; ws.cell(r, k).border = BOX
            r += 1
            for q in preguntas:
                n += 1
                ws.cell(r, 1, n).font = F(8, True)
                ws.cell(r, 1).alignment = Alignment(horizontal="center", vertical="top")
                c = ws.cell(r, 2, q); c.font = F(8)
                c.alignment = Alignment(wrap_text=True, vertical="top")
                ws.merge_cells(start_row=r, start_column=3, end_row=r, end_column=6)
                ws.merge_cells(start_row=r, start_column=8, end_row=r, end_column=9)
                for k in (3, 7, 8, 10):
                    ws.cell(r, k).fill = FILL_AMARILLO
                for k in (4, 5, 6, 9):
                    ws.cell(r, k).fill = FILL_AMARILLO
                cc = ws.cell(r, 7); cc.alignment = Alignment(horizontal="center")
                cc.font = F(8, True); dvr.add(cc)
                for k in range(1, NC + 1):
                    ws.cell(r, k).border = BOX
                ws.row_dimensions[r].height = max(24, 11 * (len(q) // 40 + 1))
                r += 1
    else:
        for _ in range(20):
            ws.merge_cells(start_row=r, start_column=3, end_row=r, end_column=6)
            ws.merge_cells(start_row=r, start_column=8, end_row=r, end_column=9)
            for k in range(1, NC + 1):
                ws.cell(r, k).fill = FILL_AMARILLO; ws.cell(r, k).border = BOX
            cc = ws.cell(r, 7); cc.alignment = Alignment(horizontal="center"); dvr.add(cc)
            ws.row_dimensions[r].height = 22
            r += 1
    formato_riesgo(ws, f"G{q_ini}:G{r-1}")
    r += 1

    r = bloque_titulo(ws, r, "4.  COMENTARIOS Y OBSERVACIONES FINALES DE LA ENTREVISTA", NC)
    for _ in range(3):
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=NC)
        for k in range(1, NC + 1):
            ws.cell(r, k).fill = FILL_AMARILLO; ws.cell(r, k).border = BOX
        ws.row_dimensions[r].height = 26
        r += 1
    r += 1

    # AUDITOR_4.0: las notas del banco de datos venían de un encargo anterior (con cifras de ese cliente).
    # Solo se conservan las advertencias metodológicas; el resto lo redacta el auditor en este encargo.
    notas = [n for n in (P["notas"] or []) if n.startswith("ADVERTENCIA")]
    notas.append("Observaciones del auditor para este encargo: completar en las celdas amarillas con base en la "
                 "evidencia obtenida del cliente. No se trasladan observaciones de otros encargos.")
    r = seccion(ws, r, "Observaciones del auditor sobre el ejercicio anterior y sobre el encargo", notas, NC)

    r = cierre(ws, r, NC, marcas=MARCAS_NARR, referencias=[
        f"Papeles del archivo del ejercicio anterior de {CLIENTE} — cuestionarios de entendimiento por proceso y hojas de "
        f"identificación de riesgos y controles de {FIRMA}",
        "Documentación preparada por el cliente (PPC): manuales de procedimientos, recorridos y respaldos que se "
        "soliciten durante la entrevista.",
    ])
    ws.freeze_panes = "C1"

    # -------------------------------------------- hoja de riesgos y controles
    NC2 = 18
    ws2 = wb.create_sheet(f"{P['ref']} Riesgos y controles"[:31])
    anchos(ws2, [7, 46, 9] + [8] * 6 + [12, 10, 13, 9, 26, 12, 12, 12, 26])
    r = encabezado(ws2, (P["ref"] + ".1") if P["confirmada"] else (P["ref"] + ".1 (prov.)"),
                   f"Identificación de riesgos y controles — {P['nombre'].lower()}", NC2)
    r = seccion(ws2, r, "Objetivo", [
        "Identificar los riesgos de incorrección material del proceso, vincularlos con las aseveraciones "
        "afectadas, calificar su probabilidad e impacto para determinar el riesgo inherente, e identificar los "
        "controles que la administración ha implementado para mitigarlos (NIA 315).",
    ], NC2)
    r = seccion(ws2, r, "Procedimiento", [
        "Para cada riesgo del banco se indica si APLICA a la entidad, se marcan con «X» las aseveraciones "
        "afectadas y se califican probabilidad e impacto seleccionándolos de la lista ALTO / MEDIO / BAJO.",
        "El riesgo inherente NO se escribe: es una fórmula que aplica la matriz 3x3 (ALTO=3, MEDIO=2, BAJO=1); un "
        "producto igual o mayor a 6 resulta ALTO, entre 3 y 4 MEDIO, y entre 1 y 2 BAJO.",
        "Para cada riesgo que aplique debe identificarse el control que lo mitiga y evaluarse su diseño e "
        "implementación. Un riesgo sin control identificado constituye una deficiencia de control interno que se "
        "comunica conforme a la NIA 265.",
    ], NC2)
    r = bloque_normativa(ws2, r, NC2, P["nias"],
        marco_niif="NIIF para las PYMES — marco de información financiera aplicable a la entidad.",
        otras=[("Fuente", f"Bancos de riesgos y controles del archivo del ejercicio anterior de {CLIENTE}")])

    r = seccion(ws2, r, "Análisis", [], NC2)

    dv_sino = DataValidation(type="list", formula1=SINO_LISTA, allow_blank=True)
    ws2.add_data_validation(dv_sino)
    dvr2 = dv_riesgo(ws2)

    r = cabecera(ws2, r, ["Ref.", "RIESGO Y/O CAUSA DEL RIESGO", "¿APLICA?"] + ASEV6 +
                         ["PROBABILIDAD", "IMPACTO", "RIESGO INHERENTE", "Ref. control",
                          "Control identificado que lo mitiga", "¿Diseño adecuado?", "¿Implementado?",
                          "Ref. P/T de la prueba", "Observación"], alto=40)
    ri_ini = r
    if P["riesgos"]:
        for etapa, riesgos in P["riesgos"]:
            ws2.merge_cells(start_row=r, start_column=1, end_row=r, end_column=NC2)
            c = ws2.cell(r, 1, etapa); c.font = F(8, True)
            for k in range(1, NC2 + 1):
                ws2.cell(r, k).fill = FILL_SUB; ws2.cell(r, k).border = BOX
            r += 1
            for cod, desc in riesgos:
                ws2.cell(r, 1, cod).font = F(8, True)
                ws2.cell(r, 1).alignment = Alignment(horizontal="center", vertical="top")
                c = ws2.cell(r, 2, desc); c.font = F(8)
                c.alignment = Alignment(wrap_text=True, vertical="top")
                cc = ws2.cell(r, 3); cc.fill = FILL_AMARILLO
                cc.alignment = Alignment(horizontal="center"); dv_sino.add(cc)
                for k in range(4, 10):
                    ws2.cell(r, k).fill = FILL_AMARILLO
                    ws2.cell(r, k).alignment = Alignment(horizontal="center")
                for k in (10, 11):
                    cc = ws2.cell(r, k); cc.fill = FILL_AMARILLO
                    cc.alignment = Alignment(horizontal="center"); cc.font = F(8, True)
                    dvr2.add(cc)
                cc = ws2.cell(r, 12, formula_nivel_riesgo("J", "K", r))
                cc.font = F(8, True); cc.alignment = Alignment(horizontal="center")
                for k in range(13, NC2 + 1):
                    ws2.cell(r, k).fill = FILL_AMARILLO
                for k in (15, 16):
                    cc = ws2.cell(r, k); cc.alignment = Alignment(horizontal="center")
                    cc.font = F(8, True); dv_sino.add(cc)
                for k in range(1, NC2 + 1):
                    ws2.cell(r, k).border = BOX
                ws2.row_dimensions[r].height = max(24, 11 * (len(desc) // 52 + 1))
                r += 1
            # filas libres para riesgos adicionales identificados en el recorrido
            for _ in range(2):
                ws2.cell(r, 1).fill = FILL_AMARILLO
                ws2.cell(r, 2).fill = FILL_AMARILLO
                cc = ws2.cell(r, 3); cc.fill = FILL_AMARILLO
                cc.alignment = Alignment(horizontal="center"); dv_sino.add(cc)
                for k in range(4, 10):
                    ws2.cell(r, k).fill = FILL_AMARILLO
                    ws2.cell(r, k).alignment = Alignment(horizontal="center")
                for k in (10, 11):
                    cc = ws2.cell(r, k); cc.fill = FILL_AMARILLO
                    cc.alignment = Alignment(horizontal="center"); cc.font = F(8, True)
                    dvr2.add(cc)
                cc = ws2.cell(r, 12, formula_nivel_riesgo("J", "K", r))
                cc.font = F(8, True); cc.alignment = Alignment(horizontal="center")
                for k in range(13, NC2 + 1):
                    ws2.cell(r, k).fill = FILL_AMARILLO
                for k in range(1, NC2 + 1):
                    ws2.cell(r, k).border = BOX
                ws2.row_dimensions[r].height = 20
                r += 1
    else:
        r = texto_largo(ws2, r,
            "La firma no levantó un banco estructurado de riesgos para este proceso en el ejercicio anterior. "
            "Las filas siguientes están en blanco para documentar los riesgos que se identifiquen durante el "
            "recorrido, organizados por las etapas del proceso descritas en la hoja de entendimiento.",
            NC2, fuente=F(8, True, ROJO))
        for etapa, _ in P["etapas"]:
            ws2.merge_cells(start_row=r, start_column=1, end_row=r, end_column=NC2)
            c = ws2.cell(r, 1, etapa.upper()); c.font = F(8, True)
            for k in range(1, NC2 + 1):
                ws2.cell(r, k).fill = FILL_SUB; ws2.cell(r, k).border = BOX
            r += 1
            for _ in range(4):
                cc = ws2.cell(r, 3); cc.fill = FILL_AMARILLO
                cc.alignment = Alignment(horizontal="center"); dv_sino.add(cc)
                for k in (10, 11):
                    cc = ws2.cell(r, k); cc.fill = FILL_AMARILLO
                    cc.alignment = Alignment(horizontal="center"); dvr2.add(cc)
                cc = ws2.cell(r, 12, formula_nivel_riesgo("J", "K", r))
                cc.font = F(8, True); cc.alignment = Alignment(horizontal="center")
                for k in list(range(1, 12)) + list(range(13, NC2 + 1)):
                    if k != 12: ws2.cell(r, k).fill = FILL_AMARILLO
                for k in range(1, NC2 + 1):
                    ws2.cell(r, k).border = BOX
                ws2.row_dimensions[r].height = 20
                r += 1
    formato_riesgo(ws2, f"J{ri_ini}:L{r-1}")
    r += 1

    # catalogo de controles
    r = bloque_titulo(ws2, r, "CATÁLOGO DE CONTROLES DEL PROCESO", NC2)
    r = texto_largo(ws2, r,
        "Registre para cada control si la entidad efectivamente lo ejecuta, su tipo y frecuencia, el responsable "
        "y la evidencia. Los controles listados provienen del catálogo de la firma para este proceso: si la "
        "entidad no los ejecuta, así debe indicarse, y ello constituye una deficiencia de control interno a "
        "comunicar (NIA 265). No deben darse por existentes sin haberlos verificado.", NC2,
        fuente=F(7, italic=True))
    r = cabecera(ws2, r, ["Ref.", "ACTIVIDAD DE CONTROL", "¿Existe?", "Prev.", "Detect.", "Manual",
                          "Mixto", "Sistema", "Frec.", "Responsable", "Evidencia del control",
                          "¿Diseño adecuado?", "¿Implementado?", "Riesgos que mitiga",
                          "Documento seleccionado", "Resultado", "Ref. P/T", "Observación"], alto=40)
    c_ini = r
    controles = P["controles"] or []
    filas_ctrl = max(len(controles), 12)
    for i in range(filas_ctrl):
        if i < len(controles):
            cod, desc = controles[i]
            ws2.cell(r, 1, cod).font = F(8, True)
            ws2.cell(r, 1).alignment = Alignment(horizontal="center", vertical="top")
            c = ws2.cell(r, 2, desc); c.font = F(8)
            c.alignment = Alignment(wrap_text=True, vertical="top")
            ws2.row_dimensions[r].height = max(22, 11 * (len(desc) // 52 + 1))
        else:
            ws2.cell(r, 1).fill = FILL_AMARILLO
            ws2.cell(r, 2).fill = FILL_AMARILLO
            ws2.row_dimensions[r].height = 20
        cc = ws2.cell(r, 3); cc.fill = FILL_AMARILLO
        cc.alignment = Alignment(horizontal="center"); dv_sino.add(cc)
        for k in range(4, NC2 + 1):
            ws2.cell(r, k).fill = FILL_AMARILLO
            if k <= 9:
                ws2.cell(r, k).alignment = Alignment(horizontal="center")
        for k in (4, 5, 6, 7, 8, 12, 13):
            cc = ws2.cell(r, k); cc.alignment = Alignment(horizontal="center")
            cc.font = F(8, True); dv_sino.add(cc)
        for k in range(1, NC2 + 1):
            ws2.cell(r, k).border = BOX
        r += 1
    r += 1

    r = bloque_titulo(ws2, r, "CONCLUSIÓN SOBRE EL DISEÑO Y LA IMPLEMENTACIÓN DE LOS CONTROLES", NC2)
    for et in ("¿El diseño de los controles del proceso es adecuado para prevenir o detectar incorrecciones "
               "materiales? Fundamente.",
               "¿Los controles clave están implementados? Indique la evidencia obtenida en el recorrido.",
               "¿Existe una adecuada segregación de funciones en el proceso?",
               "Deficiencias de control interno identificadas para comunicación (NIA 265).",
               "Enfoque de auditoría resultante y su justificación."):
        ws2.merge_cells(start_row=r, start_column=1, end_row=r, end_column=5)
        c = ws2.cell(r, 1, et); c.font = F(8, True); c.fill = FILL_GRIS
        c.alignment = Alignment(wrap_text=True, vertical="top")
        ws2.merge_cells(start_row=r, start_column=6, end_row=r, end_column=NC2)
        for k in range(6, NC2 + 1):
            ws2.cell(r, k).fill = FILL_AMARILLO
        for k in range(1, NC2 + 1):
            ws2.cell(r, k).border = BOX
        ws2.row_dimensions[r].height = 34
        r += 1
    r += 1
    r = cierre(ws2, r, NC2, marcas=MARCAS_NARR, referencias=[
        "Hoja de entendimiento del proceso de este mismo libro.",
        f"Papeles de identificación de riesgos y controles del archivo del ejercicio anterior de {CLIENTE}",
    ])
    ws2.freeze_panes = "C1"

    for h in wb.sheetnames:
        w = wb[h]
        w.sheet_view.showGridLines = False
        w.page_setup.orientation = "landscape"
        w.page_setup.paperSize = 9
        w.sheet_properties.pageSetUpPr.fitToPage = True
        w.page_setup.fitToWidth = 1
        w.page_setup.fitToHeight = 0
        w.oddFooter.left.text = f"{CLIENTE} — {CORTE}"
        w.oddFooter.left.size = 7
        w.oddFooter.right.text = "&P / &N"
        w.oddFooter.right.size = 7
    nombre_archivo = f"{PREFIJO}_{P['archivo']}.xlsx"
    wb.save(nombre_archivo)
    LIBROS.append(nombre_archivo)

    indice.append((ref_txt, P["hoja"], P["nombre"], P["ciclo_cuenta"],
                   len([q for _, qs in P["preguntas"] for q in qs]),
                   len([x for _, rs in P["riesgos"] for x in rs]),
                   len(P["controles"]), P["confirmada"], P["ref_2024"], nombre_archivo))
    print(f"  {ref_txt:<16}{P['nombre'][:40]:<42} preguntas={indice[-1][4]:>3}  riesgos={indice[-1][5]:>3}  "
          f"controles={indice[-1][6]:>3}")

# ==================================================================== ÍNDICE
wb = Workbook()
wb.remove(wb.active)
NC0 = 8
ws0 = wb.create_sheet("Índice narrativas")
anchos(ws0, [14, 44, 40, 12, 11, 12, 16, 30])
r = encabezado(ws0, "NAR", "Índice de narrativas y pruebas de controles por proceso", NC0)
r = seccion(ws0, r, "Objetivo", [
    "Presentar el índice de las narrativas y de las pruebas de controles por proceso, con el ciclo contable al "
    "que se vincula cada una y el tamaño del banco de preguntas, riesgos y controles consolidado.",
], NC0)
r = seccion(ws0, r, "Procedimiento", [
    "Los bancos de preguntas, riesgos y controles fueron consolidados a partir de los papeles del archivo 2025 de "
    "la firma: cuestionarios de entendimiento por proceso y hojas de identificación de riesgos y controles.",
    "Las respuestas y calificaciones del ejercicio anterior NO se trasladaron: todas las celdas de respuesta, "
    "calificación de riesgo y evaluación de controles están en blanco para ser levantadas en la entrevista y el "
    "recorrido de 2026. Las observaciones del auditor recogen las condiciones calificadas como de riesgo alto en "
    "el ejercicio anterior, únicamente como guía para verificar si persisten.",
], NC0)
r = cabecera(ws0, r, ["Referencia", "Proceso", "Ciclo contable relacionado", "Preguntas",
                      "Riesgos", "Controles", "Ref. 2024", "Archivo individual"], alto=28)
for ref_txt, hoja, nombre, ciclo, nq, nr, ncl, conf, r24, arch in indice:
    ws0.cell(r, 1, ref_txt).font = F(9, True, MARCA_AMBAR)
    ws0.cell(r, 1).alignment = Alignment(horizontal="center")
    ws0.cell(r, 2, nombre).font = F(8, True)
    c = ws0.cell(r, 3, ciclo); c.font = F(8)
    c.alignment = Alignment(wrap_text=True, vertical="top")
    for col, val in ((4, nq), (5, nr), (6, ncl)):
        c = ws0.cell(r, col, val if val else "—"); c.font = F(8)
        c.alignment = Alignment(horizontal="center")
    c = ws0.cell(r, 7, r24 or "—")
    c.font = F(8, True if r24 else False)
    c.alignment = Alignment(horizontal="center")
    c = ws0.cell(r, 8, arch); c.font = F(7)
    c.alignment = Alignment(wrap_text=True, vertical="top")
    if not conf: ws0.cell(r, 1).fill = FILL_ALERTA
    for k in range(1, NC0 + 1): ws0.cell(r, k).border = BOX
    ws0.row_dimensions[r].height = 22
    r += 1
r += 1
r = seccion(ws0, r, "Criterio de referenciación aplicado", [
    "Las narrativas del archivo 2025 de la firma referencian cada papel por la LETRA DE LA CUENTA del índice de "
    "papeles de trabajo: el cuestionario de compras y el de recepción, almacenamiento y despacho llevan la "
    "referencia «F» (inventarios) y el de activos fijos lleva «H» (activo fijo). Se adoptó esa misma convención "
    "y se emitió un papel individual por cuenta.",
    "En el archivo 2024 la firma utilizó una codificación distinta, con el prefijo «C» seguido de una letra "
    "secuencial por proceso: CE-01 tesorería, CA-01 ventas y cuentas por cobrar y CC-01 nómina. La equivalencia "
    "con la referencia actual consta en cada papel y en la columna «Ref. 2024» de este índice.",
    "La única narrativa sin letra de cuenta es la de tecnologías de la información, por ser transversal a todos "
    "los ciclos; se le asignó la referencia TIC-01, que REQUIERE CONFIRMACIÓN DEL AUDITOR RESPONSABLE.",
], NC0)
r = nota_alerta(ws0, r, NC0,
    "ENFOQUE DE AUDITORÍA — Conforme a la planificación aprobada no se deposita confianza en los controles "
    "internos y el enfoque es sustantivo. Estas narrativas cumplen el requerimiento de la NIA 315 de obtener el "
    "entendimiento del control interno y de evaluar el DISEÑO y la IMPLEMENTACIÓN de los controles; no "
    "constituyen pruebas de eficacia operativa y no habilitan una reducción del alcance de las pruebas de "
    "detalle. Las deficiencias que se identifiquen se comunican conforme a la NIA 265.")
r = bloque_normativa(ws0, r, NC0, [200, 230, 240, 250, 265, 315, 330, 402, 500],
    marco_niif="NIIF para las PYMES — marco de información financiera aplicable a la entidad.",
    otras=[("Societaria", "Ley de Compañías y normativa de la Superintendencia de Compañías, Valores y Seguros."),
           ("Tributaria", "Ley de Régimen Tributario Interno, su Reglamento y resoluciones vigentes del SRI.")])
r = cierre(ws0, r, NC0, marcas=MARCAS_NARR,
           referencias=[f"Archivo del ejercicio anterior de {CLIENTE} — carpeta de narrativas por proceso de {FIRMA}",
                        "Check List — Herramienta de Auditoría de la firma (índice de papeles de trabajo)."])

for h in wb.sheetnames:
    w = wb[h]
    w.sheet_view.showGridLines = False
    w.page_setup.orientation = "landscape"
    w.page_setup.paperSize = 9
    w.sheet_properties.pageSetUpPr.fitToPage = True
    w.page_setup.fitToWidth = 1
    w.page_setup.fitToHeight = 0
    w.oddFooter.left.text = f"{CLIENTE} — {CORTE}"
    w.oddFooter.left.size = 7
    w.oddFooter.right.text = "&P / &N"
    w.oddFooter.right.size = 7

wb.save(f"{PREFIJO}_NAR_00_Indice_narrativas.xlsx")
print("\nOK  libros individuales generados:")
for x in [f"{PREFIJO}_NAR_00_Indice_narrativas.xlsx"] + LIBROS:
    print("   ", x)
