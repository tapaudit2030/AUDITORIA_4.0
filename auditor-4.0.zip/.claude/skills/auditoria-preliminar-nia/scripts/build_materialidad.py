# -*- coding: utf-8 -*-
"""Materialidad por fase — AUDITOR_4.0.

    P-01  Planificación          (balance del corte de planificación)
    P-01.1  Revisión interina      (balance del corte interino; compara contra P-01)
    P-01.2  Reevaluación final     (balance de cierre; compara contra P-01 y P-01.1)

Uso (en la carpeta de la fase, con encargo.json y los tb_*.csv):

    python3 build_materialidad.py --fase P-01
    python3 build_materialidad.py --fase P-01.1 --mes JULIO
    python3 build_materialidad.py --fase P-01.2 --mes DICIEMBRE

La base y los porcentajes se leen de encargo.json y NO tienen valor por defecto:
dependen del tipo de cliente y los define el auditor en cada encargo. Si faltan,
la celda sale amarilla y vacía, y el cálculo queda pendiente.

Campos de encargo.json que usa:
    materialidad_base            "Total de activos" | "Activos corrientes" | "Ingresos" | "Utilidad antes de impuestos"
                                 | "Patrimonio" | "Gastos totales"
    materialidad_global_pct      p. ej. 0.02
    materialidad_ejecucion_pct   p. ej. 0.6   (sobre la materialidad global)
    umbral_errores_triviales_pct p. ej. 0.05  (sobre la materialidad global)
    materialidad_por_fase        opcional: {"P-01.1": {...mismos campos...}} para cambiar
                                 los parámetros en una fase (decisión del socio)

Cada corrida guarda el resultado en materialidad_<fase>.json para que la fase
siguiente lo compare. Las cuentas de nivel 1 siguen el catálogo habitual de los
ERP ecuatorianos (1 activo, 3 patrimonio, 4 ingresos, 5 costos, 6 gastos); si el
plan de cuentas del cliente es distinto, pásalo con --cuentas.
"""
import argparse
import json
import os
import sys

from openpyxl import Workbook
from openpyxl.styles import Alignment

from firma import *  # noqa: F401,F403  (encabezado, seccion, ENCARGO, MESES, ...)

ap = argparse.ArgumentParser()
ap.add_argument("--fase", required=True, choices=["P-01", "P-01.1", "P-01.2"])
ap.add_argument("--mes", help="mes del balance a usar (por defecto, el último de 'meses')")
ap.add_argument("--cuentas", default='{"activo":"1.","activo_corriente":"1.1.","patrimonio":"3.",'
                                    '"ingresos":"4.","costos":"5.","gastos":"6."}',
                help="JSON con los códigos de nivel 1 del plan de cuentas del cliente")
ap.add_argument("--salida", default=".")
args = ap.parse_args()

FASE = args.fase
TITULOS = {"P-01": "Materialidad de planificación",
           "P-01.1": "Materialidad — revisión con cifras interinas",
           "P-01.2": "Materialidad — reevaluación con cifras finales"}
CTAS = json.loads(args.cuentas)

if not MESES:
    sys.exit("encargo.json no declara 'meses'. Pregunta al auditor qué balances entregó el cliente.")
MES = (args.mes or MESES[-1]).upper()
if MES not in MESES:
    sys.exit(f"El mes {MES} no está en 'meses' de encargo.json: {MESES}")
_ORDEN = ["ENERO", "FEBRERO", "MARZO", "ABRIL", "MAYO", "JUNIO", "JULIO", "AGOSTO",
          "SEPTIEMBRE", "OCTUBRE", "NOVIEMBRE", "DICIEMBRE"]
# Meses transcurridos del ejercicio al corte (ejercicio calendario, como exige la normativa societaria).
N_MESES = _ORDEN.index(MES) + 1 if MES in _ORDEN else None

dic, mes = cargar_todo()
tb = mes[MES]


def saldo(df, cta):
    r = df[df.cuenta == cta]
    return float(r.iloc[0]["act"]) if len(r) else None


def componentes(df):
    a, p, i, c, g = (saldo(df, CTAS[k]) for k in ("activo", "patrimonio", "ingresos", "costos", "gastos"))
    res = None if None in (i, c, g) else -(i + c + g)   # ingresos acreedores (negativos) → utilidad positiva
    ac = saldo(df, CTAS.get("activo_corriente", "1.1."))
    return {
        "Total de activos": a,
        "Activos corrientes": ac,
        "Patrimonio": None if p is None else abs(p) + (res or 0),
        "Ingresos": None if i is None else abs(i),
        "Utilidad antes de impuestos": res,
        "Gastos totales": None if None in (c, g) else abs(c) + abs(g),
    }


ES_RESULTADOS = {"Ingresos", "Utilidad antes de impuestos", "Gastos totales"}

# ---- parámetros: encargo.json, con posible ajuste por fase
par = {k: ENCARGO.get(k) for k in ("materialidad_base", "materialidad_global_pct",
                                    "materialidad_ejecucion_pct", "umbral_errores_triviales_pct")}
par.update((ENCARGO.get("materialidad_por_fase") or {}).get(FASE, {}))
BASE = par["materialidad_base"]
if BASE not in componentes(tb):
    BASE = None

C_ACT = componentes(tb)
C_ANT = componentes(dic)

previas = {}
for f in ("P-01", "P-01.1"):
    for ruta in (f"materialidad_{f}.json", f"../01_Planificacion/materialidad_{f}.json",
                 f"../02_Preliminar/materialidad_{f}.json"):
        if f != FASE and os.path.exists(ruta):
            with open(ruta, encoding="utf-8") as fh:
                previas[f] = json.load(fh)
            break

# ============================================================ libro
wb = Workbook()
ws = wb.active
ws.title = FASE
NC = 8
anchos(ws, [44, 18, 18, 18, 18, 14, 14, 40])
etq_corte = f"{MES.title()} {ENCARGO.get('ejercicio', '')}".strip()
r = encabezado(ws, FASE, TITULOS[FASE], NC)

objetivo = {
    "P-01": "Determinar la materialidad para los estados financieros en su conjunto, la materialidad de "
            "ejecución y el umbral de incorrecciones claramente triviales que se aplicarán en el encargo.",
    "P-01.1": "Revisar la materialidad de planificación con las cifras al corte interino y concluir si se "
            "mantiene o debe modificarse antes de ejecutar las pruebas de la fase preliminar.",
    "P-01.2": "Reevaluar la materialidad con las cifras finales del ejercicio y concluir si los procedimientos "
            "ejecutados siguen siendo suficientes. Es la materialidad contra la que se evalúa el resumen de "
            "diferencias AJ-01.",
}[FASE]
r = seccion(ws, r, "Objetivo", [objetivo], NC)
r = seccion(ws, r, "Procedimiento", [
    f"Tipo de cliente: {ENCARGO.get('tipo_cliente') or 'PENDIENTE DE CONFIRMACIÓN'}. La base y los porcentajes "
    "dependen del tipo de cliente y fueron definidos por el auditor responsable para este encargo (celdas "
    "amarillas). No se usan porcentajes por defecto.",
    f"Los saldos de los componentes se toman del balance de comprobación de {etq_corte} y del cierre del "
    "ejercicio anterior (celdas azules). Los cálculos son fórmulas.",
    "Cuando la base es de resultados y el corte no es de doce meses, se anualiza con el factor que consta en "
    "celda amarilla; el auditor debe confirmar que la anualización es razonable para la estacionalidad del cliente.",
], NC)
r = bloque_normativa(ws, r, NC, [320, 450] + ([300] if FASE == "P-01" else []),
                     otras=[("Fuente", f"Balances de comprobación de {CLIENTE}")])

# ---- parámetros de referencia de la firma (formato P-01 de la firma)
r = cabecera(ws, r, ["Cálculo materialidad", "Parámetros", "", "", "", "", "", ""], alto=18)
for nom, rango in (("Utilidad antes de participación e impuestos", "3% al 10%"),
                   ("Total ingresos ordinarios (ventas)", "0,5% al 2%"),
                   ("Total activos", "1% al 3%"),
                   ("Activos corrientes", "1% al 3%"),
                   ("Patrimonio", "1% al 5%")):
    ws.cell(r, 1, nom).font = F(10, italic=True)
    c = ws.cell(r, 2, rango); c.font = F(10, italic=True); c.alignment = Alignment(horizontal="center")
    r += 1
ws.cell(r, 1, "Rangos de referencia de la firma. El % de este cliente lo decide el auditor según el tipo de "
              "cliente y queda en las celdas amarillas.").font = F(9, italic=True)
r += 2

# ---- componentes
r = seccion(ws, r, "Análisis", [], NC)
r = cabecera(ws, r, ["Componente", "Cierre ejercicio anterior", f"Corte {etq_corte}", "", "", "",
                     "", "Observación"], alto=30)
fila_comp = {}
for nom in C_ACT:
    ws.cell(r, 1, nom).font = F(8, nom == BASE)
    for col, val in ((2, C_ANT[nom]), (3, C_ACT[nom])):
        c = ws.cell(r, col, val)
        c.font = F(8, nom == BASE, AZUL)
        c.number_format = FMT_USD
        if val is None:
            c.value = "PENDIENTE DE INFORMACIÓN DEL CLIENTE"
            c.font = F(7, color=ROJO)
    if nom == BASE:
        for k in range(1, NC + 1):
            ws.cell(r, k).fill = FILL_TOT
    if nom in ES_RESULTADOS:
        ws.cell(r, 8, "Base de resultados: se anualiza si el corte no es de 12 meses.").font = F(7)
    fila_comp[nom] = r
    r += 1
r += 1

# ---- parámetros y cálculo
r = cabecera(ws, r, ["Parámetro", "Valor", "", "", "", "", "", "Nota"], alto=18)


def fila_param(r, rotulo, valor, fmt, nota):
    ws.cell(r, 1, rotulo).font = F(8, True)
    c = ws.cell(r, 2, valor)
    c.number_format = fmt
    c.fill = FILL_AMARILLO
    c.font = F(9, True)
    ws.cell(r, 8, nota).font = F(7)
    return r + 1


f_base = r
r = fila_param(r, "Base seleccionada", BASE or "", "@",
               "Lista: Total de activos · Activos corrientes · Ingresos · Utilidad antes de impuestos · Patrimonio · Gastos totales")
dv = dv_lista(ws, '"Total de activos,Activos corrientes,Ingresos,Utilidad antes de impuestos,Patrimonio,Gastos totales"')
dv.add(f"B{f_base}")
f_anual = r
factor = (12 / N_MESES) if (BASE in ES_RESULTADOS and N_MESES and N_MESES < 12) else 1
r = fila_param(r, "Factor de anualización", factor, '0.0000',
               "1 si la base es de balance o el corte es de 12 meses.")
f_pg = r
r = fila_param(r, "% materialidad global", par["materialidad_global_pct"], FMT_PCT, "Definido por el auditor.")
f_pe = r
r = fila_param(r, "% materialidad de ejecución (sobre la global)", par["materialidad_ejecucion_pct"], FMT_PCT,
               "Definido por el auditor.")
f_pt = r
r = fila_param(r, "% umbral de errores claramente triviales (sobre la global)",
               par["umbral_errores_triviales_pct"], FMT_PCT, "Definido por el auditor.")
r += 1

rango_nom = f"$A${min(fila_comp.values())}:$A${max(fila_comp.values())}"
rango_val = f"$C${min(fila_comp.values())}:$C${max(fila_comp.values())}"
f_valbase = r
ws.cell(r, 1, "Valor de la base (anualizado si corresponde)").font = F(8, True)
c = ws.cell(r, 2, f'=IFERROR(INDEX({rango_val},MATCH(B{f_base},{rango_nom},0))*B{f_anual},"")')
c.number_format = FMT_USD; c.font = F(9, True)
r += 1
filas_res = {}
for clave, rot, frm in (("global", "MATERIALIDAD GLOBAL", f'=IF(OR(B{f_valbase}="",B{f_pg}=""),"",B{f_valbase}*B{f_pg})'),
                        ("ejecucion", "MATERIALIDAD DE EJECUCIÓN", None),
                        ("trivial", "UMBRAL DE ERRORES CLARAMENTE TRIVIALES", None)):
    if clave == "ejecucion":
        frm = f'=IF(OR(B{filas_res["global"]}="",B{f_pe}=""),"",B{filas_res["global"]}*B{f_pe})'
    if clave == "trivial":
        frm = f'=IF(OR(B{filas_res["global"]}="",B{f_pt}=""),"",B{filas_res["global"]}*B{f_pt})'
    ws.cell(r, 1, rot).font = F(9, True)
    c = ws.cell(r, 2, frm); c.number_format = FMT_USD; c.font = F(10, True); c.fill = FILL_TOT
    for k in range(1, 3):
        ws.cell(r, k).border = BOX
    filas_res[clave] = r
    r += 1
r += 1

# ---- comparación con fases anteriores
if FASE != "P-01":
    r = seccion(ws, r, "Comparación con la materialidad de fases anteriores", [], NC)
    r = cabecera(ws, r, ["Concepto", "P-01", "P-01.1", FASE, "Variación vs P-01", "", "", "Observación"], alto=18)
    for clave, rot in (("global", "Materialidad global"), ("ejecucion", "Materialidad de ejecución"),
                       ("trivial", "Umbral de trivialidad")):
        ws.cell(r, 1, rot).font = F(8, True)
        for col, f in ((2, "P-01"), (3, "P-01.1")):
            if f == FASE:
                v = "—"
            elif f not in previas:
                v = "PAPEL NO ENCONTRADO"
            else:
                v = previas[f].get(clave)
                v = "PENDIENTE" if v is None else v
            c = ws.cell(r, col, v)
            c.number_format = FMT_USD; c.font = F(8, color=AZUL)
        c = ws.cell(r, 4, f"=B{filas_res[clave]}"); c.number_format = FMT_USD; c.font = F(8, True)
        ws.cell(r, 5, f'=IFERROR(D{r}/B{r}-1,"")').number_format = FMT_PCT
        r += 1
    r = nota_alerta(ws, r, NC,
                    "Si la materialidad de esta fase es MENOR que la utilizada en las pruebas ya ejecutadas, el "
                    "auditor debe evaluar si la naturaleza, el momento y la extensión de los procedimientos siguen "
                    "siendo adecuados (NIA 320, párrafos 12 y 13). La decisión de modificar la materialidad es del "
                    "gerente o del socio y debe documentarse en Observaciones.")

r = cierre(ws, r, NC,
           marcas=[("✓", "Saldo cotejado con el balance de comprobación"),
                   ("Σ", "Sumado / recalculado")],
           referencias=[f"Balance de comprobación de {etq_corte}", "Sumarias del encargo",
                        "AJ-01 Resumen de diferencias (fase final)" if FASE == "P-01.2" else
                        "Programas de auditoría por ciclo"])

os.makedirs(args.salida, exist_ok=True)
nombre = os.path.join(args.salida, f"{PREFIJO}_{FASE}_Materialidad.xlsx")
wb.save(nombre)

# ---- resultado para la fase siguiente (valores calculados en Python, mismo criterio que las fórmulas)
vb = C_ACT.get(BASE) if BASE else None
res = {"fase": FASE, "mes": MES, "base": BASE, "valor_base": vb, "factor": factor}
pg, pe, pt = (par["materialidad_global_pct"], par["materialidad_ejecucion_pct"],
              par["umbral_errores_triviales_pct"])
res["global"] = vb * factor * pg if (vb is not None and pg) else None
res["ejecucion"] = res["global"] * pe if (res["global"] is not None and pe) else None
res["trivial"] = res["global"] * pt if (res["global"] is not None and pt) else None
with open(os.path.join(args.salida, f"materialidad_{FASE}.json"), "w", encoding="utf-8") as fh:
    json.dump(res, fh, ensure_ascii=False, indent=2)

print(f"{nombre} generado.")
for k in ("global", "ejecucion", "trivial"):
    print(f"  {k:10s}: {res[k] if res[k] is not None else 'PENDIENTE (falta base o porcentaje)'}")
