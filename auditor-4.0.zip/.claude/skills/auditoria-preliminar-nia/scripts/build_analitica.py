# -*- coding: utf-8 -*-
"""RA-01: BB-01 Revisión analítica (horizontal y vertical) · BB-02 Indicadores financieros."""
from openpyxl import Workbook
from openpyxl.styles import Alignment
from openpyxl.utils import get_column_letter
from firma import *

dic, mes = cargar_todo()
jul = mes["JULIO"]


def v(df, cta):
    r = df[df.cuenta == cta]
    return float(r.iloc[0]["act"]) if len(r) else 0.0


def suma(df, ctas):
    return sum(v(df, c) for c in ctas)


ASEV = ["Integridad", "Exactitud", "Existencia", "Presentación", "Propiedad",
        "Valuación", "Derechos y ob.", "Revelaciones"]
RIESGO = ["Probabilidad", "Impacto", "Nivel de riesgo"]

wb = Workbook()

# =============================================== BB-01  REVISIÓN ANALÍTICA
ws = wb.active
ws.title = "BB-01 Revisión Analítica"
BASE = ["CÓDIGO", "CUENTA", "31-jul-2026", "31-dic-2025", "Variación",
        "Variación relativa", "Clasificación", "% participación", "Clasificación",
        "Proceso asociado"]
COLS = BASE + ASEV + RIESGO + ["Observaciones del auditor"]
W = [12, 38, 14, 14, 14, 11, 11, 12, 11, 16] + [8] * 8 + [11, 9, 12] + [34]
NC = len(COLS)
anchos(ws, W)

r = encabezado(ws, "BB-01", "Revisión Analítica — análisis horizontal y vertical", NC)
r = seccion(ws, r, "Objetivo", [
    "Obtener evidencia suficiente y adecuada que permita concluir si existen riesgos adicionales a los "
    "identificados en la etapa de planificación, además de la identificación de incongruencias, transacciones o "
    "hechos inusuales, cantidades, ratios y tendencias que puedan tener implicaciones en la auditoría (NIA 520).",
], NC)
r = seccion(ws, r, "Procedimiento", [
    "De acuerdo con el entendimiento obtenido en la fase inicial de la planificación, se definen expectativas "
    "sobre el estado de situación financiera y el estado de resultados.",
    "Se diligencia el formato de revisión analítica con los saldos del balance de comprobación al 31 de julio de "
    "2026 y al 31 de diciembre de 2025 (columnas en azul).",
    "Se clasifican las variaciones en esperadas o no esperadas conforme a las expectativas definidas (análisis "
    "horizontal) y se determina el peso de cada cuenta sobre el total de activos y sobre los ingresos (análisis "
    "vertical).",
    "Se seleccionan las variaciones superiores al valor de la materialidad de planificación; para cada una se "
    "explica el motivo de la variación y se confirma o descarta la expectativa.",
    "Para las variaciones no esperadas se indaga el motivo y se concluye si existe un riesgo adicional que deba "
    "incorporarse a la matriz de riesgos y responderse con procedimientos sustantivos (NIA 330).",
], NC)
r = seccion(ws, r, "Alcance", [
    "Este papel de trabajo debe ser completado y revisado en su totalidad y ajustarse al sector e industria a los "
    "que pertenece la organización. Las columnas de proceso asociado, aseveraciones, calificación de riesgo y "
    "observaciones del auditor están vacías: se completan con el juicio del auditor una vez indagadas las "
    "variaciones.",
], NC)

r = bloque_normativa(ws, r, NC, [230, 300, 315, 320, 330, 500, 520, 540, 570, 240],
    marco_niif="NIIF para las PYMES — Secciones 4 y 5 (presentación de los estados financieros).",
    otras=[("Fuente", f"Balance de comprobación del cierre anterior y al corte de {CLIENTE}")])

# --- parámetros generales
r = seccion(ws, r, "Parámetros generales", [], NC)
r = cabecera(ws, r, ["Clasificación de las variaciones", "Rango desde", "Rango hasta",
                     "Clasificación", "", "", "", "", "", ""] + [""] * (NC - 10), alto=18)
f_par = r
RANGOS = [("Análisis horizontal", 0.00, 0.10, "Baja"),
          ("", 0.11, 0.20, "Media"),
          ("", 0.21, None, "Alta"),
          ("Análisis vertical", 0.00, 0.10, "Baja"),
          ("", 0.11, 0.20, "Media"),
          ("", 0.21, None, "Alta")]
for nom, d, h, cl in RANGOS:
    ws.cell(r, 1, nom).font = F(8, True)
    c = ws.cell(r, 2, d); c.number_format = FMT_PCT; c.fill = FILL_AMARILLO
    c.font = F(8); c.border = BOX
    c = ws.cell(r, 3, h if h is not None else "superiores")
    c.number_format = FMT_PCT if h is not None else "@"
    c.fill = FILL_AMARILLO; c.font = F(8); c.border = BOX
    c = ws.cell(r, 4, cl); c.font = F(8, True); c.border = BOX
    c.alignment = Alignment(horizontal="center")
    for k in range(1, 5): ws.cell(r, k).border = BOX
    r += 1
F_H_MEDIA, F_H_ALTA = f_par + 1, f_par + 2      # límites del análisis horizontal
F_V_MEDIA, F_V_ALTA = f_par + 4, f_par + 5
r += 1

r = seccion(ws, r, "Convención de signos", [
    "Los saldos se presentan tal como constan en el balance de comprobación: saldos deudores en positivo y saldos "
    "acreedores en negativo (pasivo, patrimonio e ingresos). Esta convención se conserva para mantener la "
    "trazabilidad directa con el registro contable del cliente, por lo que el porcentaje de participación de las "
    "cuentas de pasivo y patrimonio sobre el total de activos aparece con signo negativo. La clasificación de la "
    "variación se determina siempre sobre el valor absoluto del porcentaje.",
], NC)

r = nota_alerta(ws, r, NC,
    "ADVERTENCIA DE COMPARABILIDAD — El estado de situación financiera compara dos saldos a una fecha determinada y "
    "es plenamente comparable. El estado de resultados, en cambio, compara siete meses de 2026 contra doce meses de "
    "2025: la variación NO mide crecimiento ni caída. Para el análisis exigido por la NIA 520 se requiere el "
    "acumulado de enero a julio de 2025, PENDIENTE DE INFORMACIÓN DEL CLIENTE. Mientras no se disponga de esa "
    "cifra, la clasificación de las variaciones del estado de resultados no debe utilizarse como base de "
    "conclusión.")


def bloque_analitico(ws, r, titulo, grupos, base_vertical_cta, etiqueta_vertical):
    """Escribe un bloque de análisis horizontal y vertical."""
    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=NC)
    c = ws.cell(r, 1, titulo)
    c.font = F(9, True, MARCA_AMBAR); c.fill = FILL_TITULO
    for k in range(1, NC + 1):
        ws.cell(r, k).fill = FILL_TITULO; ws.cell(r, k).border = BOT
    r += 1
    cols = list(COLS)
    cols[7] = etiqueta_vertical
    r = cabecera(ws, r, cols, alto=42)
    f_cab_local = r - 1
    ini = r
    dvr = dv_riesgo(ws)
    cat = catalogo(dic, mes, grupos=grupos, niveles=(1, 2, 3))
    filas = {}
    for cta, _ in cat:
        filas[cta] = r
        r += 1
    r = ini
    f_base_v = filas.get(base_vertical_cta)
    for cta, nombre in cat:
        lvl = cta.rstrip(".").count(".") + 1
        hijos = [c for c, _ in cat
                 if c.startswith(cta) and c != cta and c.rstrip(".").count(".") + 1 == lvl + 1]
        grupo = bool(hijos)
        ws.cell(r, 1, cta).font = F(8, grupo)
        c = ws.cell(r, 2, ("   " * (lvl - 1)) + nombre)
        c.font = F(9 if lvl == 1 else 8, grupo)
        for col, df in ((3, jul), (4, dic)):
            L = get_column_letter(col)
            if grupo:
                rng = ",".join(f"{L}{filas[x]}" for x in hijos)
                cc = ws.cell(r, col, f"=SUM({rng})"); cc.font = F(8, True)
            else:
                cc = ws.cell(r, col, v(df, cta)); cc.font = F(8, color=AZUL)
            cc.number_format = FMT_USD
        ws.cell(r, 5, f"=C{r}-D{r}").number_format = FMT_USD
        ws.cell(r, 5).font = F(8, grupo)
        ws.cell(r, 6, f'=IF(D{r}=0,"",E{r}/ABS(D{r}))').number_format = FMT_PCT
        ws.cell(r, 6).font = F(8, grupo)
        ws.cell(r, 7, f'=IF(F{r}="","",IF(ABS(F{r})<=$C${F_H_MEDIA-1},$D${F_H_MEDIA-1},'
                      f'IF(ABS(F{r})<=$C${F_H_MEDIA},$D${F_H_MEDIA},$D${F_H_ALTA})))')
        ws.cell(r, 7).font = F(8, True)
        ws.cell(r, 7).alignment = Alignment(horizontal="center")
        ws.cell(r, 8, f'=IF($C${f_base_v}=0,"",C{r}/$C${f_base_v})').number_format = FMT_PCT
        ws.cell(r, 8).font = F(8, grupo)
        ws.cell(r, 9, f'=IF(H{r}="","",IF(ABS(H{r})<=$C${F_V_MEDIA-1},$D${F_V_MEDIA-1},'
                      f'IF(ABS(H{r})<=$C${F_V_MEDIA},$D${F_V_MEDIA},$D${F_V_ALTA})))')
        ws.cell(r, 9).font = F(8, True)
        ws.cell(r, 9).alignment = Alignment(horizontal="center")
        # columnas de proceso y aseveraciones a completar
        for k in range(10, 19):
            ws.cell(r, k).fill = FILL_AMARILLO
        # calificación de riesgo: probabilidad (S) e impacto (T) con lista; nivel (U) por fórmula
        for k in (19, 20):
            cc = ws.cell(r, k); cc.fill = FILL_AMARILLO
            cc.alignment = Alignment(horizontal="center")
            cc.font = F(8, True)
            dvr.add(cc)
        cc = ws.cell(r, 21, formula_nivel_riesgo("S", "T", r))
        cc.font = F(8, True); cc.alignment = Alignment(horizontal="center")
        ws.cell(r, 22).fill = FILL_AMARILLO
        for k in range(1, NC + 1):
            ws.cell(r, k).border = BOX
            if grupo and k < 10:
                ws.cell(r, k).fill = FILL_TOT if lvl == 1 else FILL_SUB
        r += 1
    formato_riesgo(ws, f"S{ini}:U{r-1}")
    return r, filas, ini


r, filas_esf, ini_esf = bloque_analitico(
    ws, r, "ANÁLISIS HORIZONTAL Y VERTICAL DEL ESTADO DE SITUACIÓN FINANCIERA",
    ("1", "2", "3"), "1.", "% participación sobre total activo")

# control del balance
r += 1
ws.cell(r, 2, "Diferencia:  Activo + Pasivo + Patrimonio  (sin resultado del período)").font = F(8, True)
for col in (3, 4):
    L = get_column_letter(col)
    ws.cell(r, col, "={0}{1}+{0}{2}+{0}{3}".format(L, filas_esf["1."], filas_esf["2."], filas_esf["3."]))
    ws.cell(r, col).font = F(8, True); ws.cell(r, col).number_format = FMT_USD
ws.cell(r, 10, "Se compensa con el resultado del período — ver bloque siguiente").font = F(7, italic=True)
for k in range(1, NC + 1):
    ws.cell(r, k).border = BOX; ws.cell(r, k).fill = FILL_SUB
r += 2

r, filas_eri, ini_eri = bloque_analitico(
    ws, r, "ANÁLISIS HORIZONTAL Y VERTICAL DEL ESTADO DE RESULTADOS",
    ("4", "5", "6", "7"), "4.", "% participación sobre ingresos")

r += 1
f_res_an = r
ws.cell(r, 2, "RESULTADO DEL PERÍODO  (4. + 5. + 6. + 7.)   —   positivo = pérdida").font = F(9, True)
for col in (3, 4):
    L = get_column_letter(col)
    partes = "+".join(f"{L}{filas_eri[g]}" for g in ("4.", "5.", "6.", "7.") if g in filas_eri)
    ws.cell(r, col, f"={partes}"); ws.cell(r, col).font = F(9, True)
    ws.cell(r, col).number_format = FMT_USD
ws.cell(r, 5, f"=C{r}-D{r}").number_format = FMT_USD; ws.cell(r, 5).font = F(9, True)
for k in range(1, NC + 1):
    ws.cell(r, k).border = BOX; ws.cell(r, k).fill = FILL_TOT
r += 1
ws.cell(r, 2, "CUADRE:  Activo + Pasivo + Patrimonio + Resultado del período  (debe ser cero)").font = F(9, True)
for col in (3, 4):
    L = get_column_letter(col)
    ws.cell(r, col, "={0}{1}+{0}{2}+{0}{3}+{0}{4}".format(
        L, filas_esf["1."], filas_esf["2."], filas_esf["3."], f_res_an))
    ws.cell(r, col).font = F(9, True); ws.cell(r, col).number_format = FMT_USD
c = ws.cell(r, 7, f'=IF(AND(ABS(C{r})<0.01,ABS(D{r})<0.01),"CUADRA","≠ REVISAR")')
c.font = F(8, True); c.alignment = Alignment(horizontal="center")
for k in range(1, NC + 1):
    ws.cell(r, k).border = BOX; ws.cell(r, k).fill = FILL_TOT
r += 2

r = cierre(ws, r, NC,
    marcas=[("©", "Saldo tomado del balance de comprobación del período indicado."),
            ("Alta", "Variación superior al 21%: exige indagación y explicación documentada."),
            ("Media", "Variación entre el 11% y el 20%."),
            ("Baja", "Variación de hasta el 10%.")],
    referencias=[
        "Balance de comprobación al 31 de julio de 2026 y al 31 de diciembre de 2025.",
        "Papeles A-1 y B-1 del libro de comparativos (los saldos de este papel deben coincidir con aquellos).",
        "Papel P-01 Determinación de la Materialidad: la materialidad de planificación es de USD 228.758,42 y el "
        "error tolerable de USD 114.379,21.",
    ])
ws.freeze_panes = "C1"
print("BB-01 listo")

# =============================================== BB-02  INDICADORES
ws2 = wb.create_sheet("BB-02 Indicadores")
C2 = ["No.", "Indicador", "Fórmula", "31-jul-2026", "31-dic-2025", "Variación",
      "Variación relativa", "Probabilidad", "Impacto", "Nivel de riesgo",
      "Proceso al que impacta", "Observaciones"]
W2 = [5, 30, 34, 15, 15, 14, 12, 11, 9, 12, 18, 34]
NC2 = len(C2)
anchos(ws2, W2)

r = encabezado(ws2, "BB-02", "Indicadores Financieros", NC2)
r = seccion(ws2, r, "Objetivo", [
    "Evaluar el comportamiento de los indicadores financieros para determinar los riesgos inherentes que podrían "
    "afectar el cumplimiento de los objetivos de la auditoría (NIA 315 y NIA 520).",
], NC2)
r = seccion(ws2, r, "Procedimiento", [
    "Se construyen las bases de cálculo a partir de los saldos del balance de comprobación de cada período "
    "(bloque siguiente, celdas azules, con el código de la cuenta que las origina).",
    "Cada indicador es una fórmula que referencia esas bases; no se registran resultados calculados fuera del "
    "libro.",
    "Los indicadores que combinan magnitudes de flujo (ingresos, costos) con magnitudes de saldo se calculan "
    "sobre el flujo ANUALIZADO del período de siete meses, aplicando el factor 12/7 que consta en celda amarilla. "
    "Sin esa anualización los índices de rotación de siete meses no son comparables con los de doce meses del "
    "ejercicio anterior.",
], NC2)

dvr2 = dv_riesgo(ws2)
r = bloque_normativa(ws2, r, NC2, [315, 320, 500, 520, 570],
    marco_niif="NIIF para las PYMES — Secciones 4, 5 y 27 (deterioro del valor de los activos).",
    otras=[("Fuente", "Bases de cálculo del bloque siguiente, tomadas del balance de comprobación.")])

r = seccion(ws2, r, "Bases de cálculo", [], NC2)
r = cabecera(ws2, r, ["Ref.", "Base", "Cuentas que la integran", "31-jul-2026", "31-dic-2025",
                      "", "", "", "", "", "", ""], alto=18)
f_b = r
CXC = ["1.1.2.01.", "1.1.2.02.", "1.1.2.03.", "1.1.2.04.", "1.1.2.05.",
       "1.1.2.06.", "1.1.2.07.", "1.1.2.08.", "1.1.2.10."]
DEPAM = ["5.1.4.06.", "5.1.4.07.", "6.1.1.12.", "6.1.1.13.", "6.1.2.12.", "6.1.2.13."]
BASES = [
    ("b1", "Activo corriente", "1.1.", lambda d: v(d, "1.1.")),
    ("b2", "Total activo", "1.", lambda d: v(d, "1.")),
    ("b3", "Efectivo y equivalentes", "1.1.1.", lambda d: v(d, "1.1.1.")),
    ("b4", "Inventarios", "1.1.4.", lambda d: v(d, "1.1.4.")),
    ("b5", "Cuentas por cobrar comerciales y otras", "1.1.2.01 a 1.1.2.10 (excluye 1.1.2.11 inversiones)",
     lambda d: suma(d, CXC)),
    ("b6", "Pasivo corriente", "2.1.", lambda d: -v(d, "2.1.")),
    ("b7", "Total pasivo", "2.", lambda d: -v(d, "2.")),
    ("b8", "Cuentas por pagar proveedores", "2.1.1. + 2.1.2. + 2.1.7.",
     lambda d: -suma(d, ["2.1.1.", "2.1.2.", "2.1.7."])),
    ("b9", "Obligaciones financieras", "2.2.4. Pasivo por arrendamientos (la entidad no registra deuda bancaria)",
     lambda d: -v(d, "2.2.4.")),
    ("b10", "Ingresos netos", "4.1. + 4.2. + 4.3. + 4.4.",
     lambda d: -suma(d, ["4.1.", "4.2.", "4.3.", "4.4."])),
    ("b11", "Costo de ventas y producción", "5.", lambda d: v(d, "5.")),
    ("b12", "Gastos financieros", "6.2.1.", lambda d: v(d, "6.2.1.")),
    ("b13", "Depreciación y amortización", "5.1.4.06/07 + 6.1.1.12/13 + 6.1.2.12/13",
     lambda d: suma(d, DEPAM)),
    ("b14", "Resultado antes de impuestos", "-(4. + 5. + 6.)   positivo = utilidad",
     lambda d: -(v(d, "4.") + v(d, "5.") + v(d, "6."))),
    ("b15", "Resultado después de impuestos", "-(4. + 5. + 6. + 7.)   positivo = utilidad",
     lambda d: -(v(d, "4.") + v(d, "5.") + v(d, "6.") + v(d, "7."))),
]
REF = {}
for ref, nom, ctas, fn in BASES:
    ws2.cell(r, 1, ref).font = F(8, True, MARCA_AMBAR)
    ws2.cell(r, 1).alignment = Alignment(horizontal="center")
    ws2.cell(r, 2, nom).font = F(8)
    c = ws2.cell(r, 3, ctas); c.font = F(7); c.alignment = Alignment(wrap_text=True, vertical="top")
    c = ws2.cell(r, 4, fn(jul)); c.font = F(8, color=AZUL); c.number_format = FMT_USD
    c = ws2.cell(r, 5, fn(dic)); c.font = F(8, color=AZUL); c.number_format = FMT_USD
    for k in range(1, 6): ws2.cell(r, k).border = BOX
    REF[ref] = r
    r += 1
f_anual = r
ws2.cell(r, 2, "Factor de anualización del período de 7 meses  (12 / 7)").font = F(8, True)
c = ws2.cell(r, 4, 12 / 7); c.fill = FILL_AMARILLO; c.number_format = "0.0000"
c.font = F(8, True); c.border = BOX
c.comment = Comment("Se aplica a los flujos de 2026 (ingresos, costos, depreciación, gastos financieros y "
                    "resultado) en los indicadores que los combinan con saldos, para hacerlos comparables con "
                    "los doce meses de 2025. Los papeles de la firma de ejercicios anteriores no aplicaron esta "
                    "anualización al comparar seis meses contra doce.", "Auditoría")
c2 = ws2.cell(r, 5, 1.0); c2.number_format = "0.0000"; c2.font = F(8); c2.border = BOX
for k in range(1, 6): ws2.cell(r, k).border = BOX
r += 2


def B(ref, per):     # per: 4 = jul-2026, 5 = dic-2025
    return f"${get_column_letter(per)}${REF[ref]}"


def A(per):
    return f"${get_column_letter(per)}${f_anual}"


IND = [
    ("1. INDICADORES DE LIQUIDEZ", [
        ("Capital de trabajo", "Activo corriente − Pasivo corriente",
         lambda p: f"={B('b1',p)}-{B('b6',p)}", FMT_USD),
        ("Razón corriente", "Activo corriente / Pasivo corriente",
         lambda p: f"=IF({B('b6',p)}=0,\"\",{B('b1',p)}/{B('b6',p)})", "0.00"),
        ("Prueba ácida", "(Activo corriente − Inventarios) / Pasivo corriente",
         lambda p: f"=IF({B('b6',p)}=0,\"\",({B('b1',p)}-{B('b4',p)})/{B('b6',p)})", "0.00"),
        ("Razón de caja", "Efectivo y equivalentes / Pasivo corriente",
         lambda p: f"=IF({B('b6',p)}=0,\"\",{B('b3',p)}/{B('b6',p)})", "0.00"),
    ]),
    ("2. INDICADORES DE ENDEUDAMIENTO", [
        ("Nivel de endeudamiento", "Pasivo total / Activo total",
         lambda p: f"=IF({B('b2',p)}=0,\"\",{B('b7',p)}/{B('b2',p)})", FMT_PCT),
        ("Endeudamiento financiero", "Obligaciones financieras / Ingresos netos anualizados",
         lambda p: f"=IF({B('b10',p)}=0,\"\",{B('b9',p)}/({B('b10',p)}*{A(p)}))", FMT_PCT),
        ("Índice de apalancamiento", "Activo total / Patrimonio  (patrimonio = activo − pasivo)",
         lambda p: f"=IF(({B('b2',p)}-{B('b7',p)})=0,\"\",{B('b2',p)}/({B('b2',p)}-{B('b7',p)}))", "0.00"),
        ("Impacto de la carga financiera", "Gastos financieros anualizados / Ingresos netos anualizados",
         lambda p: f"=IF({B('b10',p)}=0,\"\",{B('b12',p)}/{B('b10',p)})", FMT_PCT),
    ]),
    ("3. INDICADORES DE ACTIVIDAD O EFICIENCIA", [
        ("Índice de cobros (días)", "(Cuentas por cobrar / Ingresos netos anualizados) × 360",
         lambda p: f"=IF({B('b10',p)}=0,\"\",{B('b5',p)}/({B('b10',p)}*{A(p)})*360)", "0.0"),
        ("Rotación de cuentas por cobrar (veces)", "360 / Índice de cobros",
         lambda p: f"=IF({B('b5',p)}=0,\"\",({B('b10',p)}*{A(p)})/{B('b5',p)})", "0.00"),
        ("Rotación de inventarios (veces)", "Costo de ventas anualizado / Inventarios",
         lambda p: f"=IF({B('b4',p)}=0,\"\",({B('b11',p)}*{A(p)})/{B('b4',p)})", "0.00"),
        ("Rotación de inventarios (días)", "360 / Rotación de inventarios",
         lambda p: f"=IF(OR({B('b11',p)}=0,{B('b4',p)}=0),\"\",{B('b4',p)}/({B('b11',p)}*{A(p)})*360)", "0.0"),
        ("Rotación de cuentas por pagar (días)", "(Cuentas por pagar / Costo de ventas anualizado) × 360",
         lambda p: f"=IF({B('b11',p)}=0,\"\",{B('b8',p)}/({B('b11',p)}*{A(p)})*360)", "0.0"),
        ("Rotación de activos (veces)", "Ingresos netos anualizados / Activo total",
         lambda p: f"=IF({B('b2',p)}=0,\"\",({B('b10',p)}*{A(p)})/{B('b2',p)})", "0.00"),
    ]),
    ("4. INDICADORES DE RENTABILIDAD", [
        ("Margen de utilidad sobre ventas", "Resultado después de impuestos / Ingresos netos",
         lambda p: f"=IF({B('b10',p)}=0,\"\",{B('b15',p)}/{B('b10',p)})", FMT_PCT),
        ("ROE — rendimiento del patrimonio", "Resultado anualizado / Patrimonio",
         lambda p: f"=IF(({B('b2',p)}-{B('b7',p)})=0,\"\",({B('b15',p)}*{A(p)})/({B('b2',p)}-{B('b7',p)}))", FMT_PCT),
        ("ROA — rentabilidad sobre activos", "Resultado anualizado / Activo total",
         lambda p: f"=IF({B('b2',p)}=0,\"\",({B('b15',p)}*{A(p)})/{B('b2',p)})", FMT_PCT),
        ("EBITDA", "Resultado antes de impuestos + gastos financieros + depreciación y amortización",
         lambda p: f"={B('b14',p)}+{B('b12',p)}+{B('b13',p)}", FMT_USD),
    ]),
]

for titulo, lista in IND:
    ws2.merge_cells(start_row=r, start_column=1, end_row=r, end_column=NC2)
    c = ws2.cell(r, 1, titulo); c.font = F(9, True, MARCA_AMBAR)
    for k in range(1, NC2 + 1):
        ws2.cell(r, k).fill = FILL_TITULO; ws2.cell(r, k).border = BOT
    r += 1
    r = cabecera(ws2, r, C2, alto=30)
    for n, (nom, form, fx, fmt) in enumerate(lista, start=1):
        ws2.cell(r, 1, n).font = F(8, True)
        ws2.cell(r, 1).alignment = Alignment(horizontal="center")
        ws2.cell(r, 2, nom).font = F(8, True)
        c = ws2.cell(r, 3, form); c.font = F(7)
        c.alignment = Alignment(wrap_text=True, vertical="top")
        for per in (4, 5):
            cc = ws2.cell(r, per, fx(per)); cc.font = F(8); cc.number_format = fmt
        L = get_column_letter(4)
        ws2.cell(r, 6, f'=IF(OR(D{r}="",E{r}=""),"",D{r}-E{r})').number_format = fmt
        ws2.cell(r, 6).font = F(8)
        ws2.cell(r, 7, f'=IF(OR(D{r}="",E{r}="",E{r}=0),"",(D{r}-E{r})/ABS(E{r}))')
        ws2.cell(r, 7).number_format = FMT_PCT; ws2.cell(r, 7).font = F(8)
        for k in (8, 9):
            cc = ws2.cell(r, k); cc.fill = FILL_AMARILLO
            cc.alignment = Alignment(horizontal="center"); cc.font = F(8, True)
            dvr2.add(cc)
        cc = ws2.cell(r, 10, formula_nivel_riesgo("H", "I", r))
        cc.font = F(8, True); cc.alignment = Alignment(horizontal="center")
        for k in (11, 12):
            ws2.cell(r, k).fill = FILL_AMARILLO
        for k in range(1, NC2 + 1):
            ws2.cell(r, k).border = BOX
        ws2.row_dimensions[r].height = 22
        formato_riesgo(ws2, f"H{r}:J{r}")
        r += 1
    r += 1

r = seccion(ws2, r, "Matriz de calificación del riesgo", [
    "Probabilidad e impacto se seleccionan de la lista desplegable ALTO / MEDIO / BAJO. El nivel de riesgo NO se "
    "escribe: es una fórmula que aplica la matriz 3x3 asignando ALTO=3, MEDIO=2 y BAJO=1 y multiplicando ambos "
    "factores. Un producto igual o mayor a 6 resulta ALTO; entre 3 y 4, MEDIO; entre 1 y 2, BAJO. "
    "Equivale a: Alto/Alto y Alto/Medio = ALTO; Alto/Bajo y Medio/Medio = MEDIO; Medio/Bajo y Bajo/Bajo = BAJO.",
], NC2)

r = nota_alerta(ws2, r, NC2,
    "NOTA METODOLÓGICA — La columna 31-jul-2026 corresponde a siete meses de operación. Todos los indicadores que "
    "combinan flujos con saldos utilizan el flujo anualizado mediante el factor 12/7, de modo que sean comparables "
    "con los doce meses del ejercicio 2025. El margen de utilidad sobre ventas no se anualiza porque relaciona dos "
    "flujos del mismo período. El patrimonio se calcula como activo total menos pasivo total, lo que incorpora el "
    "resultado del período que no se encuentra trasladado a la cuenta 3.1.9 en el balance de comprobación.")

r = cierre(ws2, r, NC2,
    marcas=[("©", "Base tomada del balance de comprobación del período indicado."),
            ("b1..b15", "Referencia a la base de cálculo del bloque superior.")],
    referencias=["Bases de cálculo del bloque superior de este mismo papel, con el detalle de las cuentas que "
                 "integran cada una.",
                 "Papel BB-01 Revisión Analítica y papeles A-1 y B-1 del libro de comparativos."])
ws2.freeze_panes = "D1"
print("BB-02 listo")

for h in wb.sheetnames:
    w = wb[h]
    w.sheet_view.showGridLines = False
    w.page_setup.orientation = "landscape"
    w.page_setup.paperSize = 9
    w.sheet_properties.pageSetUpPr.fitToPage = True
    w.page_setup.fitToWidth = 1
    w.page_setup.fitToHeight = 0
    w.oddFooter.left.text = f"{CLIENTE} — {CORTE}"
    w.oddFooter.left.size = 7
    w.oddFooter.right.text = "&P / &N"
    w.oddFooter.right.size = 7

wb.save(f"{PREFIJO}_RA-01_Revision_Analitica.xlsx")
print("OK RA-01")
