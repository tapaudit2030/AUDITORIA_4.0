# -*- coding: utf-8 -*-
"""Formato estándar de papeles de trabajo de la firma.

Encabezado: referencia (arriba derecha) · cliente · nombre del papel · fecha de corte ·
moneda.  Secciones en el orden de la firma: Objetivo → Procedimiento → Análisis →
Marcas → Referencia → Observaciones → Conclusión, con el bloque
Preparado / Revisado / Aprobado por (con fecha).
"""
import pandas as pd
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.comments import Comment
from openpyxl.drawing.image import Image as XLImage
import os

# ---------------------------------------------------------------------------
# Parámetros del encargo.
#
# NO se codifican aquí. Se leen de `encargo.json`, que se escribe al inicio de
# cada encargo con las respuestas del auditor (cliente, RUC, corte, marco
# contable, materialidad). El orden de búsqueda es:
#
#   1. la ruta del entorno  ENCARGO_JSON
#   2. ./encargo.json en el directorio de trabajo
#
# Si no existe, los campos quedan marcados PENDIENTE y los papeles salen con
# esa marca visible en el encabezado: es preferible a heredar los datos de otro
# cliente. Nunca rellenes estos valores a mano en este archivo.
# ---------------------------------------------------------------------------
import json as _json

_PEND = "PENDIENTE DE CONFIRMACIÓN"

_DEFAULTS = {
    "firma": _PEND,
    "cliente": _PEND,
    "ruc": _PEND,
    "moneda": "( Expresado en U.S. dólares )",
    "corte": _PEND,
    "corte_largo": _PEND,
    "marco": _PEND,
    "logo": "",
}


def _cargar_encargo():
    ruta = os.environ.get("ENCARGO_JSON") or "encargo.json"
    datos = dict(_DEFAULTS)
    if os.path.exists(ruta):
        with open(ruta, encoding="utf-8") as fh:
            datos.update(_json.load(fh))
    return datos


ENCARGO = _cargar_encargo()


# ---------------------------------------------------------------------------
# AUDITOR_4.0 — identidad de firma por encargo.
# encargo.json declara "firma_id" (p. ej. "thepoweraudit" o "globalauditors").
# Se busca firmas/<firma_id>/firma.json subiendo desde el directorio de trabajo,
# desde este script y desde $AUDITOR_HOME / $CLAUDE_PROJECT_DIR. De ahí salen el
# nombre, el RUC, el logotipo y la paleta. Si no se encuentra, se usa el
# formato por defecto y el nombre que traiga encargo.json.
# ---------------------------------------------------------------------------
def _buscar_firma(firma_id):
    if not firma_id:
        return None, None
    raices = [os.environ.get("AUDITOR_HOME"), os.environ.get("CLAUDE_PROJECT_DIR"),
              os.getcwd(), os.path.dirname(os.path.abspath(__file__))]
    vistos = set()
    for raiz in raices:
        d = raiz and os.path.abspath(raiz)
        while d and d not in vistos:
            vistos.add(d)
            cand = os.path.join(d, "firmas", firma_id, "firma.json")
            if os.path.exists(cand):
                with open(cand, encoding="utf-8") as fh:
                    return _json.load(fh), os.path.dirname(cand)
            padre = os.path.dirname(d)
            d = padre if padre != d else None
    return None, None


FIRMA_CFG, _FIRMA_DIR = _buscar_firma(ENCARGO.get("firma_id"))
if FIRMA_CFG:
    if ENCARGO.get("firma") in (None, "", _PEND, "Nombre de la firma auditora"):
        ENCARGO["firma"] = FIRMA_CFG.get("nombre", _PEND)
    if not ENCARGO.get("logo") and FIRMA_CFG.get("logo"):
        _lg = os.path.join(_FIRMA_DIR, FIRMA_CFG["logo"])
        if os.path.exists(_lg):
            ENCARGO["logo"] = _lg

FIRMA = ENCARGO["firma"]
CLIENTE = ENCARGO["cliente"]
RUC = ENCARGO["ruc"]
MONEDA = ENCARGO["moneda"]
CORTE = ENCARGO["corte"]
CORTE_LARGO = ENCARGO["corte_largo"]
MARCO = ENCARGO["marco"]           # "NIIF para las PYMES" o "NIIF completas"

# Tipografía y tamaños de la firma (firmas/<id>/firma.json): títulos 12, resto 10.
FUENTE = (FIRMA_CFG or {}).get("fuente", "Arial")
TAM_TITULO = (FIRMA_CFG or {}).get("tam_titulo", 12)
TAM_TEXTO = (FIRMA_CFG or {}).get("tam_texto", 10)

# ---- paleta corporativa ThePowerAudit S.A. (muestreada del logo) -------------
MARCA_NEGRO = "FF020609"   # negro del logotipo
MARCA_AMBAR = "FFFABD15"   # ámbar del logotipo
# Paleta de la firma del encargo (firmas/<id>/firma.json → "paleta").
if FIRMA_CFG and FIRMA_CFG.get("paleta"):
    MARCA_NEGRO = "FF" + FIRMA_CFG["paleta"].get("oscuro", "020609").lstrip("#").upper()
    MARCA_AMBAR = "FF" + FIRMA_CFG["paleta"].get("acento", "FABD15").lstrip("#").upper()
BLANCO      = "FFFFFFFF"

# El ámbar de marca se usa en acentos y tramas claras; el AMARILLO PURO queda
# reservado, sin excepción, para las celdas que debe completar el auditor.
AZUL, VERDE, ROJO, NEGRO = "FF0000FF", "FF008000", "FFC00000", "FF000000"
FILL_AMARILLO = PatternFill("solid", fgColor="FFFFFF00")   # celda a completar
FILL_TITULO   = PatternFill("solid", fgColor=MARCA_NEGRO)
FILL_CAB      = PatternFill("solid", fgColor=MARCA_AMBAR)   # encabezado de tabla: acento
_PAL = (FIRMA_CFG or {}).get("paleta", {})
FILL_SUB      = PatternFill("solid", fgColor="FF" + _PAL.get("claro", "FEF7E0").lstrip("#").upper())   # trama muy clara
FILL_TOT      = PatternFill("solid", fgColor="FF" + _PAL.get("claro2", "FCE7A8").lstrip("#").upper())  # trama de totales
FILL_GRIS     = PatternFill("solid", fgColor="FFF7F7F7")
FILL_ALERTA   = PatternFill("solid", fgColor="FFFCE4D6")

_thin = Side(style="thin", color="FFBFBFBF")
BOX = Border(left=_thin, right=_thin, top=_thin, bottom=_thin)
BOT = Border(bottom=Side(style="medium", color=MARCA_AMBAR))
CAB_BORDE = Border(left=_thin, right=_thin, top=_thin,
                   bottom=Side(style="medium", color=MARCA_AMBAR))

FMT_USD = '#,##0.00;(#,##0.00);"-"'
FMT_PCT = '0.0%;(0.0%);"-"'
FMT_X   = '0.00"x"'

_ASSETS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "assets")

LOGO = None
# Con firma_id declarado solo vale el logo de esa firma: nunca se cae al logo
# por defecto (ThePowerAudit) en un encargo de otra firma.
_CANDIDATOS = ((ENCARGO.get("logo") or "",) if FIRMA_CFG else
               (ENCARGO.get("logo") or "",
                "logo_firma.png", "logo_firma.jpeg", "logo_firma.jpg",
                os.path.join(_ASSETS, "logo_firma.png")))
for cand in _CANDIDATOS:
    if cand and os.path.exists(cand):
        LOGO = cand
        break


def F(size=9, bold=False, color=NEGRO, italic=False, underline=None):
    """Fuente de la firma. Los generadores piden tamaños entre 7 y 13; el formato
    de la firma solo admite dos: título (>= 11) y texto (el resto)."""
    size = TAM_TITULO if size >= 11 else TAM_TEXTO
    return Font(name=FUENTE, size=size, bold=bold, color=color,
                italic=italic, underline=underline)


def anchos(ws, ws_widths):
    for i, w in enumerate(ws_widths, start=1):
        ws.column_dimensions[get_column_letter(i)].width = w


def encabezado(ws, ref, titulo, ncols, corte=CORTE):
    """Encabezado del formato de la firma (modelo A-1 / P-01.1):
    logotipo arriba a la izquierda, sello de elaboración y revisión arriba a la
    derecha, y debajo cliente · nombre del papel · corte · moneda · marco, con
    filete inferior. Devuelve la primera fila libre."""
    ws.sheet_view.showGridLines = False
    ws.page_setup.orientation = "landscape"
    ws.page_setup.paperSize = ws.PAPERSIZE_A4
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.print_options.horizontalCentered = True
    for k in range(1, 8):
        ws.row_dimensions[k].height = 15
    if LOGO:
        try:
            img = XLImage(LOGO)
            base_w, base_h = img.width, img.height
            img.height = 72
            img.width = int(72 * base_w / base_h)
            ws.add_image(img, "A1")
        except Exception:
            pass

    # sello: Ref. · Elaborado · Fecha · Actualizado · Revisado · Aprobado
    # etiqueta en dos columnas y valor en el resto, a la derecha del papel
    c0 = max(2, ncols - 3)
    c_val = min(c0 + 2, ncols)
    gris = Side(style="medium", color="FF7F7F7F")
    filas = [("Ref.:", ref), ("Elaborado por:", ""), ("Fecha de elaboración:", ""),
             ("Actualizado por:", ""), ("Revisado por:", ""), ("Aprobado por:", "")]
    for i, (etq, val) in enumerate(filas):
        rr = 1 + i
        if c_val - 1 > c0:
            ws.merge_cells(start_row=rr, start_column=c0, end_row=rr, end_column=c_val - 1)
        a = ws.cell(rr, c0, etq)
        a.font = F(10, True, MARCA_NEGRO)
        a.alignment = Alignment(horizontal="left", vertical="center")
        if ncols > c_val:
            ws.merge_cells(start_row=rr, start_column=c_val, end_row=rr, end_column=ncols)
        b = ws.cell(rr, c_val, val)
        b.font = F(12 if i == 0 else 10, i == 0, MARCA_NEGRO)
        b.alignment = Alignment(horizontal="left", vertical="center")
        if i:
            b.fill = FILL_AMARILLO
        for k in range(c0, ncols + 1):
            ws.cell(rr, k).border = Border(
                left=gris if k == c0 else None, right=gris if k == ncols else None,
                top=gris if i == 0 else None, bottom=gris if i == len(filas) - 1 else None)

    r = 8
    for txt, fnt in [
        (CLIENTE, F(12, True, MARCA_NEGRO)),
        (titulo, F(12, True, MARCA_NEGRO)),
        (corte, F(10, True, MARCA_NEGRO)),
        (MONEDA, F(10, italic=True, color=MARCA_NEGRO)),
        (f"Marco de información financiera aplicable: {MARCO}", F(10, italic=True)),
    ]:
        c = ws.cell(r, 1, txt); c.font = fnt
        c.alignment = Alignment(horizontal="left", vertical="center")
        ws.row_dimensions[r].height = 17 if fnt.sz >= TAM_TITULO else 14
        r += 1
    for k in range(1, ncols + 1):
        ws.cell(r - 1, k).border = Border(bottom=Side(style="thin", color=MARCA_NEGRO))
    return r + 1


RIESGO_NIVELES = '"ALTO,MEDIO,BAJO"'
MARCAS_LISTA = '"√,∑,©,®,©E,Φ,a,r,≠,N/A,P/I"'
SINO_LISTA = '"SÍ,NO,N/A"'
ENFOQUE_LISTA = '"Sustantivo,Sustantivo ampliado,Confianza en controles,No aplica"'

# ------------------------------------------------------------ catálogo de NIA
NIA = {
    200: "Objetivos globales del auditor independiente y realización de la auditoría de conformidad con las NIA",
    210: "Acuerdo de los términos del encargo de auditoría",
    220: "Gestión de la calidad de una auditoría de estados financieros",
    230: "Documentación de auditoría",
    240: "Responsabilidades del auditor en la auditoría de estados financieros con respecto al fraude",
    250: "Consideración de las disposiciones legales y reglamentarias en la auditoría de estados financieros",
    260: "Comunicación con los responsables del gobierno de la entidad",
    265: "Comunicación de las deficiencias en el control interno a los responsables del gobierno y a la dirección",
    300: "Planificación de la auditoría de estados financieros",
    315: "Identificación y valoración de los riesgos de incorrección material",
    320: "Importancia relativa o materialidad en la planificación y ejecución de la auditoría",
    330: "Respuestas del auditor a los riesgos valorados",
    402: "Consideraciones de auditoría relativas a una entidad que utiliza una organización de servicios",
    450: "Evaluación de las incorrecciones identificadas durante la realización de la auditoría",
    500: "Evidencia de auditoría",
    501: "Evidencia de auditoría — consideraciones específicas para determinadas áreas",
    505: "Confirmaciones externas",
    510: "Encargos iniciales de auditoría — saldos de apertura",
    520: "Procedimientos analíticos",
    530: "Muestreo de auditoría",
    540: "Auditoría de estimaciones contables y de la información relacionada a revelar",
    550: "Partes vinculadas",
    560: "Hechos posteriores al cierre",
    570: "Empresa en funcionamiento",
    580: "Manifestaciones escritas",
    700: "Formación de la opinión y emisión del informe de auditoría sobre los estados financieros",
}


def dv_lista(ws, formula, titulo="Seleccione una opción", mensaje=""):
    from openpyxl.worksheet.datavalidation import DataValidation
    dv = DataValidation(type="list", formula1=formula, allow_blank=True,
                        showErrorMessage=True, errorTitle="Valor no permitido",
                        error="Seleccione un valor de la lista.",
                        promptTitle=titulo, prompt=mensaje or titulo)
    ws.add_data_validation(dv)
    return dv


def bloque_normativa(ws, r, ncols, nias, marco_niif=None, otras=None):
    """Sección «Normativa de auditoría aplicada» con las NIA que sustentan el papel."""
    c = ws.cell(r, 1, "Normativa de auditoría aplicada")
    c.font = F(9, True, MARCA_NEGRO, underline="single")
    ws.cell(r, 2).border = Border(bottom=Side(style="thin", color=MARCA_AMBAR))
    r += 1
    for n in nias:
        cc = ws.cell(r, 1, f"NIA {n}")
        cc.font = F(8, True, MARCA_AMBAR); cc.fill = FILL_TITULO
        cc.alignment = Alignment(horizontal="left", vertical="top")
        cc.border = BOX
        ws.merge_cells(start_row=r, start_column=2, end_row=r, end_column=ncols)
        c2 = ws.cell(r, 2, NIA[n]); c2.font = F(8)
        c2.alignment = Alignment(wrap_text=True, vertical="top")
        c2.border = BOX
        ws.row_dimensions[r].height = max(14, 14 * (len(NIA[n]) // (ncols * 9) + 1))
        r += 1
    if marco_niif:
        cc = ws.cell(r, 1, "Marco contable" if MARCO == _PEND else MARCO); cc.font = F(8, True, MARCA_AMBAR); cc.fill = FILL_TITULO; cc.border = BOX
        ws.merge_cells(start_row=r, start_column=2, end_row=r, end_column=ncols)
        c2 = ws.cell(r, 2, marco_niif); c2.font = F(8)
        c2.alignment = Alignment(wrap_text=True, vertical="top"); c2.border = BOX
        ws.row_dimensions[r].height = max(14, 14 * (len(marco_niif) // (ncols * 9) + 1))
        r += 1
    for etiqueta, txt in (otras or []):
        cc = ws.cell(r, 1, etiqueta); cc.font = F(8, True, MARCA_AMBAR); cc.fill = FILL_TITULO; cc.border = BOX
        ws.merge_cells(start_row=r, start_column=2, end_row=r, end_column=ncols)
        c2 = ws.cell(r, 2, txt); c2.font = F(8)
        c2.alignment = Alignment(wrap_text=True, vertical="top"); c2.border = BOX
        ws.row_dimensions[r].height = max(14, 14 * (len(txt) // (ncols * 9) + 1))
        r += 1
    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=ncols)
    c = ws.cell(r, 1, "Las disposiciones tributarias del Ecuador (LRTI, su Reglamento y las resoluciones del SRI) "
                      "deben verificarse en su versión vigente para el ejercicio auditado antes de ser citadas "
                      "como criterio en un hallazgo.")
    c.font = F(7, italic=True); c.alignment = Alignment(wrap_text=True, vertical="top")
    return r + 2


def dv_riesgo(ws):
    """Lista desplegable ALTO / MEDIO / BAJO registrada en la hoja."""
    from openpyxl.worksheet.datavalidation import DataValidation
    dv = DataValidation(type="list", formula1=RIESGO_NIVELES, allow_blank=True,
                        showDropDown=False, showErrorMessage=True,
                        errorTitle="Valor no permitido",
                        error="Seleccione ALTO, MEDIO o BAJO de la lista.",
                        promptTitle="Calificación de riesgo",
                        prompt="Seleccione ALTO, MEDIO o BAJO.")
    ws.add_data_validation(dv)
    return dv


def formula_nivel_riesgo(col_prob, col_imp, fila):
    """Nivel de riesgo calculado con la matriz 3x3 (ALTO=3, MEDIO=2, BAJO=1).

    Producto >= 6 -> ALTO ;  3 a 4 -> MEDIO ;  1 a 2 -> BAJO.
    Equivale a la matriz estándar: A/A y A/M = ALTO; A/B y M/M = MEDIO; M/B y B/B = BAJO.
    """
    p = f'IF({col_prob}{fila}="ALTO",3,IF({col_prob}{fila}="MEDIO",2,1))'
    i = f'IF({col_imp}{fila}="ALTO",3,IF({col_imp}{fila}="MEDIO",2,1))'
    prod = f"({p}*{i})"
    return (f'=IF(OR({col_prob}{fila}="",{col_imp}{fila}=""),"",'
            f'IF({prod}>=6,"ALTO",IF({prod}>=3,"MEDIO","BAJO")))')


def formato_riesgo(ws, rango):
    """Semáforo sobre las celdas de calificación de riesgo."""
    from openpyxl.formatting.rule import CellIsRule
    ws.conditional_formatting.add(rango, CellIsRule(
        operator="equal", formula=['"ALTO"'],
        fill=PatternFill("solid", fgColor="FFF8CBAD"),
        font=Font(name=FUENTE, size=8, bold=True, color="FF9C0006")))
    ws.conditional_formatting.add(rango, CellIsRule(
        operator="equal", formula=['"MEDIO"'],
        fill=PatternFill("solid", fgColor="FFFCE7A8"),
        font=Font(name=FUENTE, size=8, bold=True, color="FF7F6000")))
    ws.conditional_formatting.add(rango, CellIsRule(
        operator="equal", formula=['"BAJO"'],
        fill=PatternFill("solid", fgColor="FFD8EAD3"),
        font=Font(name=FUENTE, size=8, bold=True, color="FF375623")))


def cabecera(ws, r, cols, alto=32):
    """Fila de encabezados de columna: banda negra, texto blanco, filete ámbar."""
    for i, h in enumerate(cols, start=1):
        c = ws.cell(r, i, h)
        c.font = F(10, True, MARCA_NEGRO)
        c.fill = FILL_CAB
        c.alignment = Alignment(horizontal="center", wrap_text=True, vertical="center")
        c.border = CAB_BORDE
    ws.row_dimensions[r].height = alto
    return r + 1


def seccion(ws, r, titulo, lineas=None, ncols=12):
    """Etiqueta de sección (Objetivo / Procedimiento / Análisis...) con líneas."""
    c = ws.cell(r, 1, titulo)
    c.font = F(10, True, MARCA_NEGRO, italic=True)
    r += 1
    for ln in (lineas or []):
        ws.merge_cells(start_row=r, start_column=2, end_row=r, end_column=ncols)
        c = ws.cell(r, 2, ln); c.font = F(8)
        c.alignment = Alignment(wrap_text=True, vertical="top")
        ws.row_dimensions[r].height = max(12, 14 * (len(ln) // 115 + 1))
        r += 1
    return r + 1


def cierre(ws, r, ncols, marcas=None, referencias=None, alto_obs=40):
    """Bloques finales: Marcas · Referencia · Observaciones · Conclusión."""
    r += 1
    c = ws.cell(r, 1, "Marcas"); c.font = F(9, True, underline="single")
    r += 1
    for m, sig in (marcas or []):
        a = ws.cell(r, 1, m); a.font = F(9, True)
        a.alignment = Alignment(horizontal="center"); a.border = BOX
        ws.merge_cells(start_row=r, start_column=2, end_row=r, end_column=ncols)
        b = ws.cell(r, 2, sig); b.font = F(8)
        b.alignment = Alignment(wrap_text=True, vertical="top")
        r += 1

    r += 1
    c = ws.cell(r, 1, "Referencia"); c.font = F(9, True, underline="single")
    r += 1
    for ref in (referencias or []):
        ws.merge_cells(start_row=r, start_column=2, end_row=r, end_column=ncols)
        c = ws.cell(r, 2, ref); c.font = F(8)
        c.alignment = Alignment(wrap_text=True, vertical="top")
        ws.row_dimensions[r].height = max(12, 14 * (len(ref) // 115 + 1))
        r += 1

    r += 1
    c = ws.cell(r, 1, "Observaciones"); c.font = F(9, True, underline="single")
    r += 1
    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=ncols)
    for k in range(1, ncols + 1):
        ws.cell(r, k).fill = FILL_AMARILLO; ws.cell(r, k).border = BOX
    ws.cell(r, 1).alignment = Alignment(wrap_text=True, vertical="top")
    ws.row_dimensions[r].height = alto_obs
    r += 2

    c = ws.cell(r, 1, "Conclusión"); c.font = F(9, True, underline="single")
    r += 1
    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=ncols)
    for k in range(1, ncols + 1):
        ws.cell(r, k).fill = FILL_AMARILLO; ws.cell(r, k).border = BOX
    ws.cell(r, 1).alignment = Alignment(wrap_text=True, vertical="top")
    ws.row_dimensions[r].height = alto_obs
    r += 1
    c = ws.cell(r, 1, "SATISFACTORIA  /  SATISFACTORIA CON EXCEPCIONES  /  NO SATISFACTORIA  /  "
                      "LIMITACIÓN AL ALCANCE   —   marcar la que corresponda")
    c.font = F(7, italic=True)
    r += 2

    c = ws.cell(r, 1, "Código de colores:  azul = dato del cliente   ·   amarillo = supuesto de juicio "
                      "profesional o celda a completar   ·   negro = fórmula automática   ·   "
                      "verde = enlace a otra hoja del mismo libro.")
    c.font = F(7, italic=True)
    return r + 1


def nota_alerta(ws, r, ncols, texto, alto=None):
    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=ncols)
    c = ws.cell(r, 1, texto)
    c.font = F(8, True, ROJO); c.fill = FILL_ALERTA
    c.alignment = Alignment(wrap_text=True, vertical="top")
    for k in range(1, ncols + 1):
        ws.cell(r, k).fill = FILL_ALERTA; ws.cell(r, k).border = BOX
    ws.row_dimensions[r].height = alto or max(24, 11 * (len(texto) // 150 + 1))
    return r + 2


# ------------------------------------------------------------------ datos
# Meses del ejercicio efectivamente entregados por el cliente, en orden.
# Se leen de encargo.json ("meses"); no los supongas ni completes los que falten.
_ABREV_ES = {"ENERO": "ENE", "FEBRERO": "FEB", "MARZO": "MAR", "ABRIL": "ABR",
             "MAYO": "MAY", "JUNIO": "JUN", "JULIO": "JUL", "AGOSTO": "AGO",
             "SEPTIEMBRE": "SEP", "OCTUBRE": "OCT", "NOVIEMBRE": "NOV",
             "DICIEMBRE": "DIC"}

MESES = [m.upper() for m in ENCARGO.get("meses", [])]
ABREV = {m: _ABREV_ES[m] for m in MESES}

# Archivo con el balance de diciembre del ejercicio anterior (NIA 510).
TB_ANTERIOR = ENCARGO.get("tb_anterior", "tb_dic_anterior.csv")

# Prefijo de los archivos entregables, p. ej. "ACME_2026".
PREFIJO = ENCARGO.get("prefijo", "PAPELES")


def cargar_todo(base="."):
    """Devuelve (tb del cierre anterior, {mes: df}) con lvl calculado."""
    def prep(df):
        df = df.copy()
        df["lvl"] = df.cuenta.str.rstrip(".").str.count(r"\.") + 1
        return df
    if not MESES:
        raise SystemExit(
            "encargo.json no declara la lista 'meses'. Pregunta al auditor qué "
            "meses entregó el cliente; no los asumas.")
    dic = prep(pd.read_csv(f"{base}/{TB_ANTERIOR}", dtype={"cuenta": str}))
    mes = {m: prep(pd.read_csv(f"{base}/tb_{m.lower()}.csv", dtype={"cuenta": str}))
           for m in MESES}
    return dic, mes


def catalogo(dic, mes, grupos, niveles=(1, 2, 3, 4)):
    """Catálogo unificado: unión del cierre anterior y de TODOS los meses entregados.

    La unión es obligatoria — el catálogo cambia entre meses y una cuenta
    presente en un solo período debe aparecer igual en el papel."""
    frames = [dic] + [mes[m] for m in MESES]
    cat = {}
    for f in frames:
        sub = f[(f.lvl.isin(niveles)) & (f.cuenta.str[0].isin(grupos))]
        for _, r in sub.iterrows():
            cat.setdefault(r.cuenta, r.nombre)
    return sorted(cat.items(), key=lambda kv: [int(x) for x in kv[0].rstrip(".").split(".")])


# ---------------------------------------------------------------------------
# AUDITOR_4.0 — adaptación de las citas al marco contable confirmado.
# Los textos de los generadores están redactados con la NIIF para las PYMES.
# Al guardar cualquier libro:
#   · marco "NIIF completas"  → cada "Sección N" se cambia por la NIC/NIIF
#     equivalente (tabla de references/marco-contable.md);
#   · marco pendiente         → cita dual "Sección N de la NIIF para las PYMES
#     o NIC X", como exige el motor;
#   · marco "NIIF para las PYMES" → sin cambios.
# ---------------------------------------------------------------------------
import re as _re
from openpyxl import Workbook as _WB

EQUIV_NIIF = {2: "Marco Conceptual", 3: "NIC 1", 4: "NIC 1", 5: "NIC 1", 6: "NIC 1", 7: "NIC 7",
              8: "NIC 1", 10: "NIC 8", 11: "NIIF 9", 12: "NIIF 9", 13: "NIC 2", 16: "NIC 40",
              17: "NIC 16", 18: "NIC 38", 20: "NIIF 16", 21: "NIC 37", 22: "NIC 32",
              23: "NIIF 15", 27: "NIC 36", 28: "NIC 19", 29: "NIC 12", 30: "NIC 21",
              32: "NIC 10", 33: "NIC 24"}

_RX_SEC = _re.compile(r"(?i)\bsecci(?:ón|on|ones)\s+((?:\d+)(?:\s*(?:,|y)\s*\d+)*)"
                      r"(\s+de\s+la\s+NIIF\s+para\s+las\s+PYMES)?")


def _equivalentes(nums):
    out = []
    for n in nums:
        e = EQUIV_NIIF.get(n, f"norma NIIF equivalente a la Sección {n} (PENDIENTE DE VERIFICACIÓN NORMATIVA)")
        if e not in out:
            out.append(e)
    return out[0] if len(out) == 1 else ", ".join(out[:-1]) + " y " + out[-1]


def adaptar_marco(texto, marco=None):
    marco = marco or MARCO
    if not isinstance(texto, str) or "ecci" not in texto and "PYMES" not in texto:
        return texto
    if marco == "NIIF para las PYMES" or texto.startswith("ADVERTENCIA DE MARCO"):
        return texto
    completas = marco == "NIIF completas"

    def rep(m):
        nums = [int(x) for x in _re.findall(r"\d+", m.group(1))]
        if completas:
            return _equivalentes(nums)
        return f"{m.group(0).rstrip()}{'' if m.group(2) else ' de la NIIF para las PYMES'} o {_equivalentes(nums)}"

    t = _RX_SEC.sub(rep, texto)
    if completas:
        t = t.replace("NIIF para las PYMES", "Normas NIIF completas").replace("NIIF PYMES", "Normas NIIF completas")
    return t


def _adaptar_libro(wb):
    if MARCO == "NIIF para las PYMES":
        return
    for ws in wb.worksheets:
        for fila in ws.iter_rows():
            for c in fila:
                if isinstance(c.value, str) and not c.value.startswith("="):
                    c.value = adaptar_marco(c.value)


_save_original = _WB.save


def _save_con_marco(self, filename):
    _adaptar_libro(self)
    return _save_original(self, filename)


_WB.save = _save_con_marco
