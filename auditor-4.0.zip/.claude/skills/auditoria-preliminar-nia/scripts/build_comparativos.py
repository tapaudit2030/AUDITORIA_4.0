# -*- coding: utf-8 -*-
"""Libro: A-1 Estado de Situación Financiera · B-1 ERI acumulado · B-2 ERI mensual."""
from openpyxl import Workbook
from openpyxl.styles import Alignment
from openpyxl.utils import get_column_letter
from firma import *

dic, mes = cargar_todo()
wb = Workbook()

MARCAS_STD = [
    ("√", "Cotejado contra el balance de comprobación del cliente y verificado aritméticamente."),
    ("∑", "Sumado y verificado; el total corresponde a la suma de las cuentas de detalle."),
    ("©", "Cifra tomada directamente del balance de comprobación del período indicado."),
    ("≠", "Diferencia detectada — documentar y escalar como excepción de auditoría."),
    ("P/I", "Pendiente de información del cliente; el procedimiento no pudo ejecutarse."),
]

FUENTES = [
    "Balance de comprobación al 31 de diciembre de 2025 — archivo AUD_2025_BAL_COMP_DIC2025_Final.xls "
    "(2.311 cuentas; cuadre aritmético verificado).",
    "Balances de comprobación mensuales de enero a julio de 2026 — archivos "
    "AUD_2026_<MES>_Balance de comprobacion.xls (encadenamiento mensual verificado: el saldo actual de "
    "cada mes coincide exactamente con el saldo anterior del mes siguiente).",
]


def val(df, cta, col="act"):
    r = df[df.cuenta == cta]
    return float(r.iloc[0][col]) if len(r) else 0.0


def existe(df, cta):
    return len(df[df.cuenta == cta]) > 0


def hijos_directos(catalogo_items, padre):
    """Códigos del catálogo que son hijos inmediatos de `padre`."""
    n = padre.rstrip(".").count(".") + 2
    return [c for c, _ in catalogo_items
            if c.startswith(padre) and c != padre and c.rstrip(".").count(".") + 1 == n]


# ============================================================ A-1  ESF
ws = wb.active
ws.title = "A-1 ESF"
COLS = ["x", "CÓDIGO", "NOMBRE DE LA CUENTA", "Ref.",
        "31-dic-2025", "ENE 2026", "FEB 2026", "MAR 2026", "ABR 2026", "MAY 2026",
        "JUN 2026", "JUL 2026",
        "Variación jul-2026 vs dic-2025", "Variación %",
        "SELECCIÓN", "SIGNIFICATIVO", "RESUMEN", "REFERENCIA"]
W = [4, 14, 40, 7, 14, 13, 13, 13, 13, 13, 13, 14, 15, 10, 12, 13, 11, 12]
NC = len(COLS)
anchos(ws, W)

r = encabezado(ws, "A-1", "Estado de Situación Financiera comparativo — anual y mensual", NC)
r = seccion(ws, r, "Objetivo", [
    "Conciliar el estado de situación financiera con el balance de comprobación, verificar el cuadre aritmético de "
    "cada cuenta y de cada grupo, analizar el comportamiento mensual de los saldos y seleccionar las cuentas "
    "contables que serán objeto de revisión de acuerdo con la materialidad calculada.",
    "Aseveraciones cubiertas: existencia, integridad, derechos y obligaciones, valuación y asignación, exactitud, "
    "clasificación y presentación.",
], NC)
r = seccion(ws, r, "Procedimiento", [
    "Se transcriben los saldos de las cuentas de los grupos 1. ACTIVO, 2. PASIVO y 3. PATRIMONIO NETO, hasta el "
    "cuarto nivel del catálogo, tomados del balance de comprobación de cada período (columnas en azul).",
    "El saldo al 31 de diciembre de 2025 corresponde al saldo actual del balance de comprobación de diciembre de "
    "2025 y constituye la base del comparativo anual; los saldos de enero a julio de 2026 corresponden al saldo "
    "actual de cada balance mensual y constituyen el comparativo mensual.",
    "Los subtotales y totales son fórmulas que suman las cuentas de detalle; al pie se verifica el cuadre "
    "Activo + Pasivo + Patrimonio + Resultado del período = 0 en cada período.",
    "Se seleccionan las cuentas a ser revisadas comparando su saldo al 31 de julio de 2026 contra la materialidad "
    "y el error tolerable determinados en el papel de materialidad. Los umbrales de comparación son celdas "
    "amarillas y deben ser confirmados por el auditor responsable.",
    "Conforme a la planificación, no se confía en los controles internos, por lo que el enfoque es de pruebas "
    "sustantivas o de detalle.",
], NC)

r = bloque_normativa(ws, r, NC, [230, 300, 315, 320, 500, 510, 520],
    marco_niif="Estado de situación financiera conforme a la Sección 4 de la NIIF para las PYMES.",
    otras=[("Fuente", "Balance de comprobación al 31-dic-2025 y balances mensuales de enero a julio de 2026.")])

r = seccion(ws, r, "Análisis", [], NC)

# --- bloque de materialidad
f_mat_ini = r
for i, h in enumerate(["", "", "Base de selección", "", "Total Activos 31-jul-2026", "Materialidad",
                       "Error tolerable", "RDA"], start=1):
    c = ws.cell(r, i, h)
    c.font = F(8, True, MARCA_NEGRO)
    if h: c.fill = FILL_CAB
    c.alignment = Alignment(horizontal="center", wrap_text=True); c.border = BOX
r += 1
f_base = r
ws.cell(r, 3, "Activos").font = F(8, True)
c = ws.cell(r, 5, "=L_TOTACT"); c.font = F(9, True, VERDE); c.number_format = FMT_USD
c.comment = Comment("Enlace al total del grupo 1. ACTIVO de este mismo papel, columna JUL 2026.", "Auditoría")
c = ws.cell(r, 6, "=E{}*F{}".format(r, r + 1)); c.font = F(9, True); c.number_format = FMT_USD
c = ws.cell(r, 7, "=F{}*G{}".format(r, r + 1)); c.font = F(9, True); c.number_format = FMT_USD
c = ws.cell(r, 8, "=F{}*H{}".format(r, r + 1)); c.font = F(9, True); c.number_format = FMT_USD
for k in range(1, 9): ws.cell(r, k).border = BOX
r += 1
f_pct = r
ws.cell(r, 3, "Porcentajes aplicados (juicio profesional)").font = F(8, italic=True)
for col, pct, nota in (
    (6, 0.03, "Porcentaje instruido por el auditor responsable: 3% sobre el total de activos."),
    (7, 0.50, "Error tolerable: 50% de la materialidad, conforme a la instrucción del auditor responsable. "
              "En el modelo de la firma equivale a deducir de la materialidad los errores no corregidos anticipados."),
    (8, None, "NO DEFINIDO. En el papel A-1 del ejercicio 2024 la firma aplicó el 1% de la materialidad y en el "
              "papel T-3 el límite de errores triviales fue del 3%. Debe definirlo el auditor responsable antes de "
              "acumular diferencias. REQUIERE REVISIÓN DEL AUDITOR RESPONSABLE."),
):
    c = ws.cell(r, col, pct); c.fill = FILL_AMARILLO; c.number_format = FMT_PCT
    c.font = F(8, True); c.border = BOX
    c.comment = Comment(nota, "Auditoría")
for k in range(1, 9): ws.cell(r, k).border = BOX
r += 2

# --- cabecera de la tabla
f_cab = r
r = cabecera(ws, r, COLS)
f_ini = r

cat_esf = catalogo(dic, mes, grupos=("1", "2", "3"))
filas = {}          # codigo -> fila
MESCOL = {m: 6 + i for i, m in enumerate(MESES)}   # F..L


def escribe_fila(ws, r, cta, nombre, es_grupo, hijos):
    lvl = cta.rstrip(".").count(".") + 1
    ws.cell(r, 2, cta).font = F(8, True if es_grupo else False, NEGRO if es_grupo else AZUL)
    c = ws.cell(r, 3, ("   " * (lvl - 1)) + nombre)
    c.font = F(9 if lvl == 1 else 8, es_grupo)
    d = ws.cell(r, 4, ""); d.fill = FILL_AMARILLO; d.border = BOX   # Ref. cruzada
    # dic-2025
    if es_grupo and hijos:
        rng = ",".join(f"E{filas[h]}" for h in hijos)
        c = ws.cell(r, 5, f"=SUM({rng})"); c.font = F(8, True)
    else:
        c = ws.cell(r, 5, val(dic, cta)); c.font = F(8, color=AZUL)
    c.number_format = FMT_USD
    # meses 2026
    for m in MESES:
        col = MESCOL[m]
        L = get_column_letter(col)
        if es_grupo and hijos:
            rng = ",".join(f"{L}{filas[h]}" for h in hijos)
            c = ws.cell(r, col, f"=SUM({rng})"); c.font = F(8, True)
        else:
            c = ws.cell(r, col, val(mes[m], cta)); c.font = F(8, color=AZUL)
        c.number_format = FMT_USD
    # variacion anual jul-2026 vs dic-2025
    c = ws.cell(r, 13, f"=L{r}-E{r}"); c.font = F(8, es_grupo); c.number_format = FMT_USD
    c = ws.cell(r, 14, f'=IF(E{r}=0,"",M{r}/ABS(E{r}))'); c.font = F(8, es_grupo)
    c.number_format = FMT_PCT
    # seleccion / significativo
    c = ws.cell(r, 15, f'=IF(ABS(L{r})>=$G${f_base},"SÍ","")')
    c.font = F(8, True); c.alignment = Alignment(horizontal="center")
    c = ws.cell(r, 16, f'=IF(ABS(L{r})>=$F${f_base},"SÍ","")')
    c.font = F(8, True, ROJO); c.alignment = Alignment(horizontal="center")
    for k in (17, 18):
        ws.cell(r, k).fill = FILL_AMARILLO
    for k in range(1, NC + 1):
        ws.cell(r, k).border = BOX
        if es_grupo:
            ws.cell(r, k).fill = FILL_TOT if lvl == 1 else FILL_SUB
    return r + 1


# se escribe de mayor a menor nivel para que los subtotales referencien filas ya creadas
orden = sorted(cat_esf, key=lambda kv: (-(kv[0].rstrip(".").count(".") + 1)))
# primero calculamos qué códigos son grupo (tienen hijos en el catálogo)
codigos = [c for c, _ in cat_esf]
hijos_de = {c: hijos_directos(cat_esf, c) for c in codigos}

# escribimos en orden natural del catálogo, pero los subtotales se resuelven al final
for cta, nombre in cat_esf:
    filas[cta] = r
    r += 1
# ahora rellenamos realmente
r = f_ini
for cta, nombre in cat_esf:
    h = hijos_de[cta]
    r = escribe_fila(ws, r, cta, nombre, es_grupo=bool(h), hijos=h)
f_fin = r - 1

# --- bloque de comprobación del balance
r += 1
c = ws.cell(r, 3, "COMPROBACIÓN DEL BALANCE"); c.font = F(9, True, MARCA_NEGRO)
for k in range(1, NC + 1):
    ws.cell(r, k).fill = FILL_CAB; ws.cell(r, k).border = CAB_BORDE
ws.cell(r, 3).font = F(9, True, MARCA_NEGRO)
r += 1
f_res = {}
for cod, nom in (("4.", "Ingresos"), ("5.", "Costo de ventas y producción"),
                 ("6.", "Gastos"), ("7.", "No operacionales (impuesto renta y participación trabajadores)")):
    ws.cell(r, 2, cod).font = F(8, True)
    ws.cell(r, 3, "   " + nom).font = F(8)
    c = ws.cell(r, 5, val(dic, cod)); c.font = F(8, color=AZUL); c.number_format = FMT_USD
    for m in MESES:
        c = ws.cell(r, MESCOL[m], val(mes[m], cod)); c.font = F(8, color=AZUL)
        c.number_format = FMT_USD
    for k in range(1, NC + 1): ws.cell(r, k).border = BOX
    f_res[cod] = r
    r += 1
f_resultado = r
ws.cell(r, 3, "Resultado del período  (4. + 5. + 6. + 7.)").font = F(8, True)
for col in [5] + [MESCOL[m] for m in MESES]:
    L = get_column_letter(col)
    c = ws.cell(r, col, "={0}{1}+{0}{2}+{0}{3}+{0}{4}".format(
        L, f_res["4."], f_res["5."], f_res["6."], f_res["7."]))
    c.font = F(8, True); c.number_format = FMT_USD
for k in range(1, NC + 1):
    ws.cell(r, k).border = BOX; ws.cell(r, k).fill = FILL_SUB
r += 1
f_cuadre = r
ws.cell(r, 3, "CUADRE:  Activo + Pasivo + Patrimonio + Resultado del período  (debe ser cero)").font = F(9, True)
for col in [5] + [MESCOL[m] for m in MESES]:
    L = get_column_letter(col)
    c = ws.cell(r, col, "={0}{1}+{0}{2}+{0}{3}+{0}{4}".format(
        L, filas["1."], filas["2."], filas["3."], f_resultado))
    c.font = F(9, True); c.number_format = FMT_USD
c = ws.cell(r, 15, f'=IF(MAX(ABS(E{r}),ABS(F{r}),ABS(G{r}),ABS(H{r}),ABS(I{r}),ABS(J{r}),ABS(K{r}),ABS(L{r}))<0.01,'
                   f'"CUADRA","≠ REVISAR")')
c.font = F(8, True); c.alignment = Alignment(horizontal="center")
for k in range(1, NC + 1):
    ws.cell(r, k).border = BOX; ws.cell(r, k).fill = FILL_TOT
r += 2

r = nota_alerta(ws, r, NC,
    "OBSERVACIÓN SOBRE EL GRUPO 7. NO OPERACIONALES — Al 31 de diciembre de 2025 la cuenta 7.3 «Impuesto renta y "
    "participación trabajadores» presenta un saldo de USD 314.595,51. En los balances de comprobación de enero a "
    "julio de 2026 este grupo no registra saldo alguno, es decir no se ha reconocido provisión de impuesto a la "
    "renta ni de participación de trabajadores en el período interino. Debe evaluarse su razonabilidad "
    "considerando que el resultado acumulado a julio de 2026 es una pérdida, así como el efecto en el impuesto "
    "diferido (Sección 29 de la NIIF para las PYMES). REQUIERE REVISIÓN DEL AUDITOR RESPONSABLE.")

r = nota_alerta(ws, r, NC,
    "OBSERVACIÓN SOBRE LA CUENTA 3.1.9 RESULTADOS DEL EJERCICIO — Tanto al 31 de diciembre de 2025 como en todos "
    "los meses de 2026 esta cuenta presenta saldo cero: el resultado del período no se traslada al patrimonio en "
    "el balance de comprobación. El estado de situación financiera cuadra únicamente al incorporar el resultado de "
    "las cuentas de resultado, tal como se presenta en el bloque de comprobación anterior. Debe verificarse el "
    "procedimiento de cierre contable y la presentación del patrimonio en los estados financieros definitivos.")

r = cierre(ws, r, NC, marcas=MARCAS_STD, referencias=FUENTES)
ws.freeze_panes = ws.cell(f_ini, 5)

# resolver el enlace del total de activos del bloque de materialidad
ws.cell(f_base, 5).value = f"=L{filas['1.']}"

print(f"A-1 ESF: {len(cat_esf)} cuentas, filas {f_ini}-{f_fin}, cuadre en fila {f_cuadre}")
wb.save("wb_comp1.xlsx")
