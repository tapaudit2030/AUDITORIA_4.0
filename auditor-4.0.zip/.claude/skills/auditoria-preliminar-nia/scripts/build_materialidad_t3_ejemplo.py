# -*- coding: utf-8 -*-
"""EJEMPLO HISTÓRICO (no usar en encargos nuevos): P-00 del modelo T-3 con los parámetros de un encargo anterior.
AUDITOR_4.0 usa build_materialidad.py, que lee base y porcentajes de encargo.json y sirve para P-00, P-01 y P-02."""
from openpyxl import Workbook
from openpyxl.styles import Alignment
from openpyxl.worksheet.datavalidation import DataValidation
from firma import *

dic, mes = cargar_todo()
jul = mes["JULIO"]


def v(df, cta):
    r = df[df.cuenta == cta]
    return float(r.iloc[0]["act"]) if len(r) else 0.0


# ---- componentes reales tomados del balance de comprobación
def componentes(df):
    act = v(df, "1.")
    act_cte = v(df, "1.1.")
    pat_cont = v(df, "3.")
    ing = v(df, "4.")
    cos = v(df, "5.")
    gas = v(df, "6.")
    imp = v(df, "7.")                      # impuesto renta y participación trabajadores
    res_antes = ing + cos + gas            # resultado antes de impuestos (negativo = utilidad)
    res_desp = res_antes + imp
    return dict(activos=act, act_cte=act_cte, pat_contable=pat_cont,
                pat_total=pat_cont + res_desp, res_antes=res_antes,
                res_desp=res_desp, ingresos=ing, impuesto=imp)


C26 = componentes(jul)
C25 = componentes(dic)

wb = Workbook()

# ==================================================== P-00  DETERMINACIÓN
ws = wb.active
ws.title = "P-00 Materialidad"
NC = 9
anchos(ws, [46, 10, 17, 17, 17, 17, 17, 12, 34])

r = encabezado(ws, "P-00", "Cálculo de la Materialidad Normativa", NC)

r = seccion(ws, r, "Objetivo", [
    "Determinar la materialidad para los estados financieros en su conjunto, la materialidad de ejecución (error "
    "tolerable) y el umbral de las incorrecciones claramente triviales que se aplicarán en la auditoría parcial al "
    "31 de julio de 2026 y por el año que terminará el 31 de diciembre de 2026 (NIA 320 y NIA 450).",
], NC)

r = seccion(ws, r, "Procedimiento", [
    "Seleccionamos la materialidad basándonos en los parámetros de la firma que se detallan a continuación.",
    "Según el giro del negocio se selecciona el ACTIVO como componente crítico o base de selección, por cuanto los "
    "inventarios constituyen el rubro principal para el desarrollo del objeto social de la Compañía: fabricación y "
    "comercialización de prendas de vestir. Al 31 de julio de 2026 los inventarios representan el 61,0% del total "
    "de activos.",
    "El porcentaje de selección aplicado sobre el total de activos es del 3%, y la materialidad de ejecución se "
    "determina en el 50% de la materialidad, conforme a la instrucción del auditor responsable del encargo.",
    "De acuerdo con la planificación no se deposita confianza en los controles internos —la Compañía no cuenta con "
    "narrativas ni con documentación de controles previamente levantada—, por lo que el enfoque de auditoría se "
    "concentra en pruebas de detalle o sustantivas.",
    "Los saldos de los componentes se toman del balance de comprobación de cada período (celdas azules); los "
    "porcentajes son supuestos de juicio profesional (celdas amarillas) y deben ser revisados conjuntamente con el "
    "socio y el gerente del encargo.",
], NC)

r = bloque_normativa(ws, r, NC, [200, 230, 300, 320, 450, 530],
    marco_niif="NIIF para las PYMES — marco de información financiera aplicable a la entidad.",
    otras=[("Fuente", f"Balance de comprobación del cierre anterior y al corte de {CLIENTE}")])

# ---- tabla de parámetros de la firma
r = seccion(ws, r, "Parámetros de la firma", [], NC)
r = cabecera(ws, r, ["CÁLCULO MATERIALIDAD", "", "PARÁMETROS", "SELECCIÓN", "", "", "", "", ""], alto=18)
PARAMS = [("ACTIVOS - RELACIONADAS", "10% al 15%", ""),
          ("PATRIMONIO", "1% al 5%", ""),
          ("TOTAL INGRESOS NETOS (VENTAS)", "3%", ""),
          ("ACTIVOS", "3%", "a")]
for nom, par, sel in PARAMS:
    ws.cell(r, 1, nom).font = F(8, True if sel else False)
    ws.cell(r, 3, par).font = F(8)
    ws.cell(r, 3).alignment = Alignment(horizontal="center")
    c = ws.cell(r, 4, sel); c.font = F(11, True, MARCA_AMBAR)
    c.alignment = Alignment(horizontal="center")
    for k in range(1, 5):
        ws.cell(r, k).border = BOX
        if sel: ws.cell(r, k).fill = FILL_TOT
    r += 1
r += 1

# ---- análisis: saldos de los componentes
r = seccion(ws, r, "Análisis", [], NC)
COMPS = ["Total Activos", "Activos Corrientes", "Total Patrimonio",
         "Utilidad / (pérdida) antes de impuestos", "Total Ingresos"]
r = cabecera(ws, r, ["Componente", "Nota", "31-dic-2025 (12 meses)", "31-jul-2026 (7 meses)",
                     "", "", "", "", "Fuente / observación"], alto=30)
f_comp_ini = r
FILAS_COMP = {}
DATOS = [
    ("Total Activos", "[1]", C25["activos"], C26["activos"],
     "Cuenta 1. ACTIVO del balance de comprobación."),
    ("Activos Corrientes", "[1]", C25["act_cte"], C26["act_cte"],
     "Cuenta 1.1. ACTIVO CORRIENTE del balance de comprobación."),
    ("Total Patrimonio", "[1]", C25["pat_total"], C26["pat_total"],
     "Cuenta 3. PATRIMONIO NETO más el resultado del período, que no se encuentra trasladado al patrimonio en el "
     "balance de comprobación (cuenta 3.1.9 en cero)."),
    ("Utilidad / (pérdida) antes de impuestos", "[1]", C25["res_antes"], C26["res_antes"],
     "Suma de las cuentas 4. INGRESOS, 5. COSTO DE VENTAS Y PRODUCCIÓN y 6. GASTOS. Saldo negativo = utilidad; "
     "saldo positivo = pérdida."),
    ("Total Ingresos", "[1]", C25["ingresos"], C26["ingresos"],
     "Cuenta 4. INGRESOS del balance de comprobación (neto de descuentos y devoluciones)."),
]
for nom, nota, d25, d26, fuente in DATOS:
    ws.cell(r, 1, nom).font = F(8, True)
    ws.cell(r, 2, nota).font = F(8, color=VERDE)
    ws.cell(r, 2).alignment = Alignment(horizontal="center")
    c = ws.cell(r, 3, d25); c.font = F(8, color=AZUL); c.number_format = FMT_USD
    c = ws.cell(r, 4, d26); c.font = F(9, True, AZUL); c.number_format = FMT_USD
    ws.merge_cells(start_row=r, start_column=9, end_row=r, end_column=9)
    c = ws.cell(r, 9, fuente); c.font = F(7)
    c.alignment = Alignment(wrap_text=True, vertical="top")
    ws.row_dimensions[r].height = max(20, 10 * (len(fuente) // 46 + 1))
    for k in range(1, NC + 1): ws.cell(r, k).border = BOX
    FILAS_COMP[nom] = r
    r += 1
r += 1

# ---- matriz de determinación por componente (columnas C..G = los 5 componentes)
r = cabecera(ws, r, ["Determinación de la materialidad — 31 de julio de 2026", "Nota",
                     "Total Activos", "Activos Corrientes", "Total Patrimonio",
                     "Utilidad / (pérdida) antes de imp.", "Total Ingresos", "", ""], alto=32)
COLC = {"Total Activos": 3, "Activos Corrientes": 4, "Total Patrimonio": 5,
        "Utilidad / (pérdida) antes de impuestos": 6, "Total Ingresos": 7}

f_saldo = r
ws.cell(r, 1, "Saldo del componente").font = F(8, True)
ws.cell(r, 2, "[1]").font = F(8, color=VERDE)
for nom, col in COLC.items():
    c = ws.cell(r, col, f"=$D${FILAS_COMP[nom]}"); c.font = F(8, True, VERDE)
    c.number_format = FMT_USD
for k in range(1, 8): ws.cell(r, k).border = BOX
r += 1

f_factor = r
ws.cell(r, 1, "Factor seleccionado").font = F(8, True)
ws.cell(r, 2, "[2]").font = F(8, color=VERDE)
FACTORES = {"Total Activos": 0.03, "Activos Corrientes": None, "Total Patrimonio": None,
            "Utilidad / (pérdida) antes de impuestos": None, "Total Ingresos": None}
dv = DataValidation(type="list", formula1='"1%,2%,3%,4%,5%,6%,7%,8%,9%,10%"', allow_blank=True)
ws.add_data_validation(dv)
for nom, col in COLC.items():
    c = ws.cell(r, col, FACTORES[nom]); c.fill = FILL_AMARILLO
    c.number_format = FMT_PCT; c.font = F(8, True); c.border = BOX
    dv.add(c)
ws.cell(f_factor, 8, "← solo el componente seleccionado lleva factor").font = F(7, italic=True)
for k in range(1, 8): ws.cell(r, k).border = BOX
r += 1

f_ir = r
ws.cell(r, 1, "Importancia relativa  (materialidad)").font = F(9, True)
for nom, col in COLC.items():
    L = get_column_letter(col)
    c = ws.cell(r, col, f"=IF({L}{f_factor}=\"\",\"\",ABS({L}{f_saldo})*{L}{f_factor})")
    c.font = F(9, True); c.number_format = FMT_USD
for k in range(1, 8):
    ws.cell(r, k).border = BOX; ws.cell(r, k).fill = FILL_TOT
r += 1

f_err = r
ws.cell(r, 1, "Total de errores sin corregir anticipados (estimado o real)").font = F(8, True)
ws.cell(r, 2, "[3]").font = F(8, color=VERDE)
for nom, col in COLC.items():
    L = get_column_letter(col)
    c = ws.cell(r, col, f"=IF({L}{f_ir}=\"\",\"\",{L}{f_ir}*$C${f_err+1})")
    c.font = F(8); c.number_format = FMT_USD
for k in range(1, 8): ws.cell(r, k).border = BOX
r += 1
f_pct_err = r
ws.cell(r, 1, "Porcentaje de errores anticipados sobre la materialidad").font = F(8, italic=True)
c = ws.cell(r, 3, 0.50); c.fill = FILL_AMARILLO; c.number_format = FMT_PCT
c.font = F(8, True); c.border = BOX
c.comment = Comment("Instrucción del auditor responsable: la materialidad de ejecución se fija en el 50% de la "
                    "materialidad. En el modelo de la firma ese 50% se expresa como el monto de errores no "
                    "corregidos que se anticipa identificar y que se deduce de la materialidad.", "Auditoría")
for k in range(1, 8): ws.cell(r, k).border = BOX
r += 1

f_ird = r
ws.cell(r, 1, "Importancia relativa de desempeño  (error tolerable)").font = F(9, True)
for nom, col in COLC.items():
    L = get_column_letter(col)
    c = ws.cell(r, col, f"=IF({L}{f_ir}=\"\",\"\",{L}{f_ir}-{L}{f_err})")
    c.font = F(9, True); c.number_format = FMT_USD
for k in range(1, 8):
    ws.cell(r, k).border = BOX; ws.cell(r, k).fill = FILL_TOT
r += 1

f_ptriv = r
ws.cell(r, 1, "Porcentaje de errores claramente triviales").font = F(8, True)
ws.cell(r, 2, "[4]").font = F(8, color=VERDE)
for nom, col in COLC.items():
    c = ws.cell(r, col, None); c.fill = FILL_AMARILLO; c.number_format = FMT_PCT
    c.font = F(8, True); c.border = BOX
ws.cell(r, 3).comment = Comment(
    "NO DEFINIDO por el auditor responsable. Antecedentes en los papeles de la firma: en el T-3 del ejercicio 2024 "
    "se aplicó el 3% de la importancia relativa, mientras que en el A-1 del mismo ejercicio el RDA se calculó al 1%. "
    "La NIA 450 y la guía interna refieren hasta el 5% de la importancia relativa. "
    "REQUIERE REVISIÓN DEL AUDITOR RESPONSABLE antes de acumular diferencias no corregidas.", "Auditoría")
for k in range(1, 8): ws.cell(r, k).border = BOX
r += 1

f_triv = r
ws.cell(r, 1, "Límite de errores claramente triviales").font = F(9, True)
for nom, col in COLC.items():
    L = get_column_letter(col)
    c = ws.cell(r, col, f"=IF(OR({L}{f_ir}=\"\",{L}{f_ptriv}=\"\"),\"\",{L}{f_ir}*{L}{f_ptriv})")
    c.font = F(9, True); c.number_format = FMT_USD
for k in range(1, 8):
    ws.cell(r, k).border = BOX; ws.cell(r, k).fill = FILL_TOT
r += 2

# ---- componente seleccionado y resumen
f_sel = r
ws.cell(r, 1, "Componente seleccionado").font = F(9, True)
c = ws.cell(r, 3, "Total Activos"); c.font = F(9, True); c.fill = FILL_AMARILLO; c.border = BOX
r += 1
ws.cell(r, 1, "MATERIALIDAD APLICABLE AL ENCARGO").font = F(10, True)
c = ws.cell(r, 3, f"=C{f_ir}"); c.font = F(11, True); c.number_format = FMT_USD
for k in range(1, 8):
    ws.cell(r, k).border = BOX; ws.cell(r, k).fill = FILL_TOT
r += 1
ws.cell(r, 1, "MATERIALIDAD DE EJECUCIÓN / ERROR TOLERABLE").font = F(10, True)
c = ws.cell(r, 3, f"=C{f_ird}"); c.font = F(11, True); c.number_format = FMT_USD
for k in range(1, 8):
    ws.cell(r, k).border = BOX; ws.cell(r, k).fill = FILL_TOT
r += 1
ws.cell(r, 1, "LÍMITE DE ERRORES CLARAMENTE TRIVIALES").font = F(10, True)
c = ws.cell(r, 3, f"=C{f_triv}"); c.font = F(11, True); c.number_format = FMT_USD
for k in range(1, 8):
    ws.cell(r, k).border = BOX; ws.cell(r, k).fill = FILL_TOT
r += 2

r = seccion(ws, r, "Consideraciones para la selección del componente crítico", [
    "Se seleccionó el total de activos por cuanto los inventarios constituyen el componente principal para el "
    "desarrollo del objeto social de la Compañía —fabricación y comercialización de prendas de vestir— y "
    "representan el 61,0% del total de activos al 31 de julio de 2026 (USD 4.651.560,02 sobre USD 7.625.280,58).",
    "No se utilizó la utilidad antes de impuestos como componente porque al 31 de julio de 2026 el resultado "
    "acumulado es una pérdida de USD 299.663,43, mientras que el ejercicio 2025 cerró con una utilidad antes de "
    "impuestos de USD 898.901,50. Un componente que cambia de signo entre períodos no constituye una base estable "
    "de medición (NIA 320.A4 y A6).",
    "Tampoco se utilizaron los ingresos totales como base porque el período auditado comprende siete meses y el "
    "comparativo disponible comprende doce, lo que distorsionaría la magnitud del componente.",
], NC)

r = seccion(ws, r, "Documentación de los errores anticipados", [
    "El monto de errores no corregidos anticipados se determinó aplicando el 50% de la importancia relativa, "
    "conforme a la instrucción del auditor responsable. Se trata de un monto ESTIMADO, no de errores reales: a la "
    "fecha de este papel no se han ejecutado pruebas sustantivas y por tanto no existen diferencias identificadas.",
    "Al no existir controles internos documentados en la entidad y al ser esta la primera auditoría con este "
    "alcance interino, no se dispone de un historial de errores no corregidos de períodos anteriores que permita "
    "una estimación basada en la experiencia previa con el cliente.",
], NC)

r = nota_alerta(ws, r, NC,
    "REQUIERE REVISIÓN DEL AUDITOR RESPONSABLE — El porcentaje de errores claramente triviales no ha sido definido "
    "y la celda correspondiente está vacía. Sin ese umbral no puede determinarse cuáles diferencias se acumulan en "
    "el resumen de diferencias no corregidas (NIA 450). Los antecedentes internos no son uniformes: el T-3 de 2024 "
    "aplicó el 3% de la importancia relativa y el A-1 del mismo ejercicio calculó el RDA al 1%.")

r = cierre(ws, r, NC,
    marcas=[("a", "Componente seleccionado como base de la materialidad."),
            ("[1]", "Saldo tomado del balance de comprobación del período indicado."),
            ("[2]", "Factor de juicio profesional; revisar con el socio y el gerente del encargo."),
            ("[3]", "Errores no corregidos anticipados deducidos de la materialidad."),
            ("[4]", "Umbral de incorrecciones claramente triviales (NIA 450).")],
    referencias=[
        "Balance de comprobación al 31 de diciembre de 2025 — AUD_2025_BAL_COMP_DIC2025_Final.xls.",
        "Balance de comprobación al 31 de julio de 2026 — AUD_2026_JULIO_Balance de comprobacion.xls.",
        "Los saldos de los componentes se enlazan al papel A-1 Estado de Situación Financiera y al papel B-1 "
        "Estado de Resultados del libro de comparativos.",
    ])

# ==================================================== NORMATIVA
ws2 = wb.create_sheet("Normativa")
anchos(ws2, [8, 110])
r = encabezado(ws2, "P-00.1", "Marco normativo aplicado a la determinación de la materialidad", 2)
r = seccion(ws2, r, "Importancia relativa en la planificación y ejecución de la auditoría", [], 2)
NOTAS = [
    ("N1", "Al establecer la estrategia global de auditoría debe determinarse la importancia relativa para los "
           "estados financieros en su conjunto. Su determinación implica el ejercicio del juicio profesional y "
           "habitualmente se aplica un porcentaje sobre un componente elegido como punto de partida. La elección "
           "del componente depende de los elementos de los estados financieros en los que se centra la atención de "
           "los usuarios, de la estructura de la entidad y del sector en que opera. (NIA 320, párrafos 10 y A4.)"),
    ("N2", "Al elegir el componente deben considerarse los resultados y la situación financiera de períodos "
           "anteriores, los del período corriente y los presupuestos, ajustados por cambios significativos en las "
           "circunstancias de la entidad. Cuando el componente habitual resulta excepcionalmente reducido, "
           "volátil o cambia de signo, puede ser más apropiado utilizar otro. (NIA 320, párrafo A6.)"),
    ("N3", "La importancia relativa de ejecución se determina deduciendo de la importancia relativa el monto total "
           "de errores que se anticipa identificar y que se considera que la administración no corregirá. Su "
           "finalidad es reducir a un nivel apropiadamente bajo la probabilidad de que la acumulación de errores "
           "no corregidos y no detectados exceda la importancia relativa para los estados financieros en su "
           "conjunto. Debe ser siempre inferior a la importancia relativa, para proporcionar un margen de "
           "seguridad. (NIA 320, párrafo 11.)"),
    ("N4", "El auditor puede determinar un importe por debajo del cual las incorrecciones son claramente "
           "insignificantes y no requieren acumularse. «Claramente insignificante» no es sinónimo de «no "
           "material»: se trata de cuestiones de una magnitud claramente inferior, que no tendrán consecuencias ni "
           "individual ni agregadamente. Si existe cualquier incertidumbre sobre si una partida es claramente "
           "insignificante, se considera que no lo es. (NIA 450, párrafo A2.)"),
    ("N5", "La materialidad no se aplica de forma mecánica. Una diferencia inferior al umbral no se declara "
           "irrelevante sin considerar factores cualitativos: incidencia en el cumplimiento de cláusulas "
           "contractuales o tributarias, transacciones con partes relacionadas, indicios de fraude, efecto en "
           "tendencias o en el cumplimiento de metas, y errores que evidencian una deficiencia de control interno."),
]
for cod, txt in NOTAS:
    c = ws2.cell(r, 1, cod); c.font = F(9, True, MARCA_AMBAR)
    c.alignment = Alignment(horizontal="center", vertical="top"); c.border = BOX
    c = ws2.cell(r, 2, txt); c.font = F(8)
    c.alignment = Alignment(wrap_text=True, vertical="top"); c.border = BOX
    ws2.row_dimensions[r].height = 12 * (len(txt) // 118 + 2)
    r += 1
r += 1
c = ws2.cell(r, 2, "Marco de información financiera aplicable a la entidad: NIIF para las PYMES. "
                   "Normativa societaria: Superintendencia de Compañías, Valores y Seguros. "
                   "Normativa tributaria: Ley de Régimen Tributario Interno, su Reglamento y las resoluciones "
                   "vigentes del Servicio de Rentas Internas para el ejercicio auditado. Las disposiciones "
                   "tributarias específicas deben verificarse en su versión vigente para 2026 antes de ser citadas "
                   "en los papeles de trabajo.")
c.font = F(8, italic=True); c.alignment = Alignment(wrap_text=True, vertical="top")
ws2.row_dimensions[r].height = 60

# ==================================================== AYUDA
ws3 = wb.create_sheet("AYUDA")
anchos(ws3, [10, 108])
r = encabezado(ws3, "P-00.2", "Guía de uso del papel de materialidad", 2)
AY = [
    ("[1]", "Saldos de los componentes. Se toman del balance de comprobación del período. Están en azul porque son "
            "datos del cliente; el saldo del 31 de julio de 2026 alimenta la matriz de determinación."),
    ("[2]", "Factor de materialidad. Escoger el porcentaje conjuntamente con el socio y el gerente del encargo. "
            "Rangos de referencia de la firma: total activos 2% al 5%; activos corrientes 2% al 5%; patrimonio 5%; "
            "utilidad antes de impuestos hasta 10%; ingresos 5% al 10%. En este encargo el auditor responsable "
            "instruyó el 3% sobre el total de activos."),
    ("[3]", "Errores no corregidos anticipados. Ingresar los errores no corregidos por la administración o un monto "
            "estimado de los que se espera que la Compañía no corrija al cierre; puede expresarse como un "
            "porcentaje de la importancia relativa. En este encargo se aplicó el 50%."),
    ("[4]", "Errores claramente triviales. Definir el porcentaje sobre la importancia relativa. El socio del "
            "encargo puede fijar un nivel más bajo en función de la naturaleza de la entidad, del historial de "
            "errores y del número de ubicaciones."),
]
for cod, txt in AY:
    c = ws3.cell(r, 1, cod); c.font = F(9, True, MARCA_AMBAR)
    c.alignment = Alignment(horizontal="center", vertical="top"); c.border = BOX
    c = ws3.cell(r, 2, txt); c.font = F(8)
    c.alignment = Alignment(wrap_text=True, vertical="top"); c.border = BOX
    ws3.row_dimensions[r].height = 12 * (len(txt) // 116 + 2)
    r += 1

for h in wb.sheetnames:
    w = wb[h]
    w.sheet_view.showGridLines = False
    w.page_setup.orientation = "landscape"
    w.page_setup.paperSize = 9
    w.sheet_properties.pageSetUpPr.fitToPage = True
    w.page_setup.fitToWidth = 1
    w.page_setup.fitToHeight = 0
    w.oddFooter.left.text = f"{CLIENTE} — {CORTE}"
    w.oddFooter.left.size = 7
    w.oddFooter.right.text = "&P / &N"
    w.oddFooter.right.size = 7

wb.save(f"{PREFIJO}_P-00_Materialidad.xlsx")
print("OK P-00 Materialidad")
print(f"  Total activos jul-26 = {C26['activos']:,.2f}   dic-25 = {C25['activos']:,.2f}")
print(f"  Resultado antes de impuestos jul-26 = {C26['res_antes']:,.2f}   dic-25 = {C25['res_antes']:,.2f}")
print(f"  Impuesto/particip. dic-25 = {C25['impuesto']:,.2f}   jul-26 = {C26['impuesto']:,.2f}")
print(f"  Patrimonio total jul-26 = {C26['pat_total']:,.2f}   dic-25 = {C25['pat_total']:,.2f}")
