# -*- coding: utf-8 -*-
"""Cédulas sumarias por ciclo — índice de letras de ThePowerAudit S.A."""
from openpyxl import Workbook
from openpyxl.styles import Alignment
from openpyxl.utils import get_column_letter
from firma import *

dic, mes = cargar_todo()
jul = mes["JULIO"]
# Materialidad vigente: se lee del resultado de build_materialidad.py (P-01, o P-01.1 en la
# fase preliminar). Nunca se escribe a mano ni se hereda de otro encargo.
import json as _j, os as _o
MG = ME = None
for _f in ("materialidad_P-01.1.json", "../02_Preliminar/materialidad_P-01.1.json",
           "materialidad_P-01.json", "../01_Planificacion/materialidad_P-01.json"):
    if _o.path.exists(_f):
        _m = _j.load(open(_f, encoding="utf-8")); MG, ME = _m.get("global"), _m.get("ejecucion")
        break
if not MG:
    raise SystemExit("No hay materialidad calculada: ejecuta antes build_materialidad.py --fase P-01.")


def v(df, cta):
    r = df[df.cuenta == cta]
    return float(r.iloc[0]["act"]) if len(r) else 0.0


CXC_G = ["1.1.2.01.", "1.1.2.02.", "1.1.2.03.", "1.1.2.04.", "1.1.2.05.",
         "1.1.2.06.", "1.1.2.07.", "1.1.2.08.", "1.1.2.10."]
NOM_COSTO = ["5.1.2.", "5.1.3."]
NOM_GASTO = ["6.1.1.01.", "6.1.1.02.", "6.1.1.03.", "6.1.1.04.", "6.1.1.05.", "6.1.1.06.",
             "6.1.2.01.", "6.1.2.02.", "6.1.2.03.", "6.1.2.04.", "6.1.2.05.", "6.1.2.06."]
NOM_PASIVO = ["2.1.4.", "2.1.5.", "2.3.1.", "2.3.2."]


def nivel3_excepto(grupo, excluir=()):
    """Cuentas de nivel 3 de un grupo (unión de ambos períodos), excluyendo las indicadas."""
    cod = set()
    for df in (dic, jul):
        cod |= set(df[(df.cuenta.str.startswith(grupo)) & (df.lvl == 3)].cuenta)
    cod -= set(excluir)
    return sorted(cod, key=lambda c: [int(x) for x in c.rstrip(".").split(".")])


def nivel2(grupo):
    """Cuentas de nivel 2 de un grupo, tomadas de la unión de ambos períodos."""
    cod = set()
    for df in (dic, jul):
        cod |= set(df[(df.cuenta.str.startswith(grupo)) & (df.lvl == 2)].cuenta)
    return sorted(cod, key=lambda c: [int(x) for x in c.rstrip(".").split(".")])

SUMARIAS = [
    dict(ref="C-1", nias=[230, 315, 320, 330, 500, 501, 505, 520, 530, 240, 570], hoja="C-1 Efectivo", nombre="EFECTIVO Y EQUIVALENTES AL EFECTIVO",
         marco="Sección 7 y Sección 11 de la NIIF para las PYMES · NIA 501 · NIA 505 · Sección 30",
         asev="Existencia · Integridad · Derechos y obligaciones · Exactitud · Corte · Presentación",
         bloques=[("Efectivo y equivalentes", ["1.1.1."])],
         control=("1.1.1.", []),
         notas=["Las cuentas por cobrar a administradoras de tarjetas de crédito registradas en 1.1.2.08 se "
                "analizan en la sumaria E-1 y no forman parte de este papel.",
                "El saldo de efectivo disminuyó un 87,0% respecto del 31 de diciembre de 2025 (de USD 2.476.757,36 "
                "a USD 321.786,95). La razón de caja pasó de 1,86 a 0,23. Debe indagarse el destino de los "
                "recursos y evaluarse el efecto en la evaluación del negocio en marcha (NIA 570)."]),
    dict(ref="E-1", nias=[230, 315, 320, 330, 500, 505, 520, 530, 540, 550, 240], hoja="E-1 Cuentas por cobrar", nombre="CUENTAS POR COBRAR",
         marco="Sección 11 y Sección 23 de la NIIF para las PYMES · Sección 33 · NIA 505 · NIA 530",
         asev="Existencia · Integridad · Derechos y obligaciones · Valuación · Corte · Clasificación",
         bloques=[("Cuentas por cobrar comerciales y otras", CXC_G)],
         control=("1.1.2.", ["1.1.2.11."]),
         notas=["No se incluye la cuenta 1.1.2.11 INVERSIONES (USD 1.122.413,30 al 31-jul-2026), que pertenece al "
                "mismo grupo de activos financieros pero corresponde al ciclo de inversiones (letra D del índice) "
                "y no está comprendida en el alcance autorizado.",
                "La provisión de cuentas incobrables y deterioro (1.1.2.10) presenta un saldo acreedor de "
                "USD 11.867,51, sin movimiento en el período de siete meses. Debe recalcularse el deterioro "
                "conforme a la Sección 11 sobre la base del reporte de antigüedad de cartera.",
                "Las cuentas 1.1.2.02.010 y 1.1.2.02.020 presentan saldos que se compensan entre sí; no deben "
                "netearse sin analizar su naturaleza y su contraparte."]),
    dict(ref="F-1", nias=[230, 315, 320, 330, 500, 501, 520, 530, 540, 240], hoja="F-1 Inventarios", nombre="INVENTARIOS",
         marco="Sección 13 de la NIIF para las PYMES · NIA 501 · NIA 530",
         asev="Existencia · Integridad · Valuación y asignación · Corte · Derechos y obligaciones",
         bloques=[("Inventarios por bodega", ["1.1.4."])],
         control=("1.1.4.", []),
         notas=["Los inventarios representan el 61,0% del total de activos al 31 de julio de 2026 y constituyen el "
                "componente crítico seleccionado para la determinación de la materialidad (papel P-01).",
                "El saldo aumentó un 25,1% respecto del 31 de diciembre de 2025 (de USD 3.717.675,59 a "
                "USD 4.651.560,02) mientras el resultado del período pasó de utilidad a pérdida. Los días de "
                "inventario aumentaron de 245 a 393 (BB-02). Esta combinación es un indicio de acumulación de "
                "inventario de lenta rotación y exige análisis específico de obsolescencia y de valor neto de "
                "realización.",
                "La provisión por valor neto de realización (1.1.4.00) presenta un saldo acreedor de "
                "USD 146.166,52. Debe recalcularse y contrastarse con el análisis de VNR y el aging de inventarios.",
                "Existen bodegas denominadas «TERCERAS» y de «LIQUIDACIÓN», y la cuenta 1.1.4.10 IMPORTACIONES EN "
                "TRÁNSITO (USD 54.007,50), que exigen análisis de derechos de propiedad, de valuación y del "
                "INCOTERM aplicable, respectivamente."]),
    dict(ref="F-2", nias=[230, 315, 320, 330, 500, 505, 520, 530, 550, 240, 250], hoja="F-2 Costo de ventas", nombre="COSTO DE VENTAS Y PRODUCCIÓN — CICLO DE COMPRAS",
         marco="Sección 13 de la NIIF para las PYMES · Sección 2 · Sección 33 · NIA 240",
         asev="Ocurrencia · Integridad · Exactitud · Corte · Clasificación · Valuación",
         bloques=[("Costo de fabricación (excluye mano de obra — ver K-4)",
                   nivel3_excepto("5.1.", excluir=("5.1.2.", "5.1.3."))),
                  ("Costo de ventas", nivel3_excepto("5.2.")),
                  ("Cuentas de traslado de costos",
                   nivel3_excepto("5.3.") + nivel3_excepto("5.4."))],
         control=("5.", ["5.1.2.", "5.1.3."]),
         notas=["ADVERTENCIA DE REFERENCIA: el índice de papeles de la firma (Check List) no asigna una letra "
                "específica al grupo 5. COSTO DE VENTAS Y PRODUCCIÓN. Este papel se referencia provisionalmente "
                "como F-2, por su vinculación directa con inventarios. REQUIERE CONFIRMACIÓN DE LA REFERENCIA por "
                "el auditor responsable.",
                "Este papel excluye la mano de obra directa (5.1.2.) e indirecta (5.1.3.), que se analizan en la "
                "sumaria K-4 Nómina. La suma de F-2 y de la porción de costo de K-4 reconcilia con el total del "
                "grupo 5. del estado de resultados; esa reconciliación consta al pie de este papel.",
                "La cuenta 5.1.7.02 PRODUCCIÓN SUB-CONTRATADA RUABLUCO (USD 358.790,80) corresponde a una entidad "
                "del mismo grupo económico. Debe evaluarse la condición de parte relacionada, las condiciones de "
                "la transacción, su revelación (Sección 33) y la aplicación del régimen de precios de "
                "transferencia si resulta aplicable.",
                "Las cuentas 5.3.1. y 5.4.1. son cuentas de traslado con saldo acreedor (USD 3.098.073,00 y "
                "USD 182.346,65). Debe verificarse su mecánica de liquidación contra el movimiento de producto en "
                "proceso y terminado.",
                "OBSERVACIÓN DE CLASIFICACIÓN: existe una cuenta 5.1.9 «COSTO DE VENTAS» dentro del grupo de costo "
                "de fabricación, con saldo de USD 14,79 al 31 de diciembre de 2025 y sin saldo al 31 de julio de "
                "2026, que duplica la denominación de la cuenta 5.2.1. Del mismo modo, el grupo de gastos "
                "operacionales contiene una cuenta 6.1.3 «GASTOS FINANCIEROS» (USD 33,00 al 31-dic-2025) que "
                "duplica la denominación de 6.2.1. Los importes no son materiales, pero evidencian una debilidad "
                "en la estructura del catálogo de cuentas que debe comunicarse en la carta de control interno "
                "(NIA 265)."]),
    dict(ref="J-1", nias=[230, 315, 320, 330, 500, 505, 520, 530, 560, 240, 250], hoja="J-1 Cuentas por pagar", nombre="CUENTAS POR PAGAR Y PROVEEDORES",
         marco="Sección 21, Sección 11 y Sección 22 de la NIIF para las PYMES · NIA 505 · LRTI y normativa SRI",
         asev="Integridad · Obligaciones · Exactitud · Corte · Valuación · Clasificación",
         bloques=[("Cuentas y documentos por pagar", ["2.1.1.", "2.1.2.", "2.1.7."])],
         control=None,
         notas=["La aseveración crítica de este ciclo es la INTEGRIDAD, no la existencia: un saldo bajo de "
                "proveedores no constituye evidencia de razonabilidad. El procedimiento central es la búsqueda de "
                "pasivos no registrados.",
                "Los días de cuentas por pagar aumentaron de 39 a 71 (BB-02), en un contexto de fuerte "
                "disminución del efectivo. Debe indagarse si existen obligaciones vencidas no registradas, "
                "acuerdos de refinanciamiento o intereses de mora no reconocidos.",
                "Las obligaciones tributarias (2.1.3.), con el IESS (2.1.4.) y laborales (2.1.5.) no se analizan "
                "en este papel: corresponden a K-3 Impuestos y K-4 Nómina respectivamente."]),
    dict(ref="K-4", nias=[230, 315, 320, 330, 500, 505, 520, 530, 540, 250, 240], hoja="K-4 Nómina", nombre="NÓMINA Y BENEFICIOS A EMPLEADOS",
         marco="Sección 28 de la NIIF para las PYMES · Código del Trabajo · Ley de Seguridad Social · LRTI",
         asev="Exactitud · Integridad · Valuación y asignación · Ocurrencia · Presentación",
         bloques=[("Costo de mano de obra directa e indirecta", NOM_COSTO),
                  ("Gastos de personal", NOM_GASTO),
                  ("Pasivos laborales", NOM_PASIVO)],
         control=None,
         notas=["Este papel agrupa dos naturalezas distintas con subtotales separados: costos y gastos de personal "
                "del estado de resultados, y pasivos laborales del estado de situación financiera. El total "
                "combinado no tiene significado económico.",
                "Las provisiones laborales de largo plazo (2.3.1. jubilación patronal USD 1.266.156,14 y 2.3.2. "
                "indemnización laboral USD 119.277,20) suman USD 1.385.433,34, equivalentes a 6,06 veces la "
                "materialidad global. Requieren informe actuarial vigente y evaluación de la competencia, "
                "capacidad y objetividad del actuario, así como de la razonabilidad de sus hipótesis (Sección 28).",
                "El activo por impuestos diferidos de la cuenta 1.5.1 (USD 160.341,95, sin movimiento en el "
                "período) se origina en estas provisiones. Su recuperabilidad debe evaluarse conforme a la "
                "Sección 29 considerando la pérdida acumulada del período.",
                "Las cuentas de honorarios incluidas en los bloques de personal (5.1.2.05, 5.1.3.05, 6.1.1.05 y "
                "6.1.2.05) suman USD 121.889,44. Debe evaluarse si corresponden a servicios profesionales o "
                "encubren relación de dependencia, y verificarse la retención aplicable en cada caso.",
                "La cuenta 2.1.5.03 PARTICIPACIÓN TRABAJADORES presenta un saldo acreedor de USD 0,35, coherente "
                "con la pérdida del período, pero debe confirmarse el tratamiento aplicable al cierre anual."]),
    dict(ref="N-1", nias=[230, 315, 320, 330, 500, 520, 530, 240, 250], hoja="N-1 Ingresos", nombre="INGRESOS",
         marco="Sección 23 de la NIIF para las PYMES · NIA 240 · NIA 520 · LRTI y normativa SRI",
         asev="Ocurrencia · Integridad · Exactitud · Corte · Clasificación · Presentación",
         bloques=[("Ingresos, descuentos, devoluciones y otros ingresos", nivel2("4."))],
         control=("4.", []),
         notas=["El reconocimiento de ingresos constituye un riesgo de fraude presunto conforme a la NIA 240; su "
                "evaluación no puede omitirse ni sustituirse por procedimientos analíticos.",
                "Los descuentos (4.2.) y devoluciones (4.3.) acumulados a julio de 2026 suman USD 1.059.039,90, "
                "equivalentes al 17,7% de las ventas brutas del período. Debe verificarse la autorización, la "
                "política aplicable y el sustento documental de una muestra.",
                "Debe conciliarse el ingreso contable acumulado contra los formularios 104 y el ATS de cada mes "
                "del período, y documentarse toda diferencia."]),
    dict(ref="P-1", nias=[230, 315, 320, 330, 500, 520, 530, 240, 250, 550], hoja="P-1 Gastos", nombre="GASTOS",
         marco="Sección 2 y Sección 21 de la NIIF para las PYMES · NIA 240 · LRTI y normativa SRI",
         asev="Ocurrencia · Integridad · Exactitud · Corte · Clasificación",
         bloques=[("Gastos operacionales y no operacionales", nivel2("6."))],
         control=("6.", []),
         notas=["Este papel incluye la totalidad del grupo 6. Los rubros de personal contenidos en 6.1.1.01 a "
                "6.1.1.06 y 6.1.2.01 a 6.1.2.06 se analizan además en la sumaria K-4 Nómina; la referencia "
                "cruzada evita duplicar procedimientos sobre las mismas partidas.",
                "La cuenta 6.1.2.10 ARRENDAMIENTO OPERATIVO (USD 612.468,33) es el rubro individual más "
                "significativo del grupo. Debe evaluarse el tratamiento de los arrendamientos conforme a la "
                "Sección 20 de la NIIF para las PYMES y su consistencia con el pasivo por arrendamientos "
                "registrado en la cuenta 2.2.4.",
                "La cuenta 6.2.2.15 REGALÍAS: ROYALTY THE H.D. LEE CO (USD 225.000,00) corresponde a un pago al "
                "exterior. Debe verificarse el contrato de licencia, la retención en la fuente aplicable a pagos "
                "al exterior conforme a la normativa vigente y su deducibilidad.",
                "La cuenta 6.2.2.09 GASTOS NO DEDUCIBLES (USD 681,10) debe conciliarse con la conciliación "
                "tributaria del ejercicio (papel Z)."]),
]

COLS = ["Cuenta", "NOMBRE DE LA CUENTA", "Ref.", "31-dic-2025", "31-jul-2026",
        "Variación", "Variación %", "% del ciclo",
        "SELECCIÓN", "SIGNIFICATIVO", "Probabilidad", "Impacto", "Nivel de riesgo",
        "Marca", "Observación / procedimiento planificado"]
W = [15, 42, 7, 15, 15, 15, 11, 10, 12, 13, 12, 10, 13, 8, 38]
NC = len(COLS)

wb = Workbook()
wb.remove(wb.active)          # se elimina la hoja por defecto
resumen = []


def hijos(df_cat, padre):
    n = padre.rstrip(".").count(".") + 2
    return [c for c in df_cat if c.startswith(padre) and c != padre
            and c.rstrip(".").count(".") + 1 == n]


for spec in SUMARIAS:
    ws = wb.create_sheet(spec["hoja"])
    anchos(ws, W)
    r = encabezado(ws, spec["ref"], f"Cédula sumaria — {spec['nombre']}", NC)
    r = seccion(ws, r, "Objetivo", [
        f"Obtener el detalle de las cuentas que integran el ciclo, conciliarlo con el balance de comprobación, "
        f"verificar su cuadre aritmético, analizar las variaciones respecto del ejercicio anterior y planificar "
        f"los procedimientos sustantivos aplicables.",
        f"Aseveraciones cubiertas: {spec['asev']}.",
        f"Marco normativo aplicable: {spec['marco']}.",
    ], NC)
    r = seccion(ws, r, "Procedimiento", [
        "Se transcriben los saldos de las cuentas del ciclo al 31 de diciembre de 2025 y al 31 de julio de 2026, "
        "tomados del balance de comprobación de cada período (columnas en azul).",
        "Los subtotales y el total del ciclo son fórmulas que suman las cuentas de detalle; al pie se compara el "
        "total calculado contra el saldo de encabezado del balance de comprobación y la diferencia debe ser cero.",
        "Se marcan las cuentas cuyo saldo supera el error tolerable (selección) y la materialidad (significativo), "
        "determinados en el papel P-01.",
        "Las columnas de referencia cruzada, marca y observación se completan al ejecutar cada procedimiento; una "
        "prueba sin evidencia no se considera ejecutada.",
    ], NC)
    r = seccion(ws, r, "Análisis", [], NC)

    # umbrales visibles
    f_um = r
    ws.cell(r, 2, "Materialidad (P-01)").font = F(8, True)
    c = ws.cell(r, 4, MG); c.font = F(8, True, VERDE); c.number_format = FMT_USD
    c.comment = Comment("Importe determinado en el papel P-01 Determinación de la Materialidad: 3% del total de "
                        "activos al 31-jul-2026.", "Auditoría")
    ws.cell(r, 5, "Error tolerable (P-01)").font = F(8, True)
    c = ws.cell(r, 6, ME); c.font = F(8, True, VERDE); c.number_format = FMT_USD
    for k in range(1, 7): ws.cell(r, k).border = BOX
    r += 2

    r = bloque_normativa(ws, r, NC, spec["nias"], marco_niif=spec["marco"],
                         otras=[("Fuente",
                                 f"Balance de comprobación del cierre anterior y al corte de {CLIENTE}")])
    dvr = dv_riesgo(ws)
    dvm = dv_lista(ws, MARCAS_LISTA, "Marca de auditoría",
                   "Seleccione la marca que corresponde al procedimiento ejecutado.")
    r = cabecera(ws, r, COLS, alto=30)
    f_ini = r
    todas = []
    for _, padres in spec["bloques"]:
        for p in padres:
            todas.append(p)
            todas.extend(hijos([c for c in list(jul.cuenta) + list(dic.cuenta)], p))
    todas = sorted(set(todas), key=lambda c: [int(x) for x in c.rstrip(".").split(".")])
    nombres = {}
    for df in (jul, dic):
        for _, row in df[df.cuenta.isin(todas)].iterrows():
            nombres.setdefault(row.cuenta, row.nombre)

    filas = {}
    plan = []
    for titulo, padres in spec["bloques"]:
        plan.append(("bloque", titulo, None))
        for p in padres:
            hs = [c for c in todas if c.startswith(p) and c != p
                  and c.rstrip(".").count(".") + 1 == p.rstrip(".").count(".") + 2]
            for h in hs:
                plan.append(("det", h, None))
            plan.append(("sub", p, hs))
        if len(spec["bloques"]) > 1:
            plan.append(("subbloque", titulo, padres))
    plan.append(("total", spec["nombre"], [p for _, ps in spec["bloques"] for p in ps]))

    # reservar filas
    rr = r
    for tipo, cod, _ in plan:
        if tipo == "bloque":
            rr += 1
        else:
            filas[(tipo, cod)] = rr
            rr += 1

    f_total = None
    subbloques = {}
    for tipo, cod, extra in plan:
        if tipo == "bloque":
            ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=NC)
            c = ws.cell(r, 1, cod.upper()); c.font = F(8, True, MARCA_AMBAR)
            for k in range(1, NC + 1):
                ws.cell(r, k).fill = FILL_TITULO; ws.cell(r, k).border = BOT
            r += 1
            continue
        if tipo == "det":
            ws.cell(r, 1, cod).font = F(8, color=AZUL)
            ws.cell(r, 2, "   " + nombres.get(cod, "")).font = F(8)
            for col, df in ((4, dic), (5, jul)):
                c = ws.cell(r, col, v(df, cod)); c.font = F(8, color=AZUL)
                c.number_format = FMT_USD
        elif tipo == "sub":
            ws.cell(r, 1, cod).font = F(8, True)
            ws.cell(r, 2, nombres.get(cod, "")).font = F(8, True)
            for col, letra in ((4, "D"), (5, "E")):
                if extra:
                    rng = ",".join(f"{letra}{filas[('det', h)]}" for h in extra)
                    c = ws.cell(r, col, f"=SUM({rng})")
                    c.font = F(8, True)
                else:
                    c = ws.cell(r, col, v(dic if col == 4 else jul, cod))
                    c.font = F(8, True, AZUL)
                c.number_format = FMT_USD
        elif tipo == "subbloque":
            ws.cell(r, 2, f"SUBTOTAL — {cod}").font = F(9, True)
            for col, letra in ((4, "D"), (5, "E")):
                rng = ",".join(f"{letra}{filas[('sub', p)]}" for p in extra)
                c = ws.cell(r, col, f"=SUM({rng})"); c.font = F(9, True)
                c.number_format = FMT_USD
            subbloques[cod] = r
        elif tipo == "total":
            ws.cell(r, 2, f"TOTAL CICLO — {cod}").font = F(10, True)
            if len(spec["bloques"]) > 1:
                base = [f"{{L}}{subbloques[t]}" for t, _ in spec["bloques"]]
            else:
                base = [f"{{L}}{filas[('sub', p)]}" for p in extra]
            for col, letra in ((4, "D"), (5, "E")):
                rng = ",".join(b.format(L=letra) for b in base)
                c = ws.cell(r, col, f"=SUM({rng})"); c.font = F(10, True)
                c.number_format = FMT_USD
            f_total = r

        # columnas comunes
        ws.cell(r, 3).fill = FILL_AMARILLO; ws.cell(r, 3).border = BOX
        neg = tipo in ("sub", "subbloque", "total")
        c = ws.cell(r, 6, f"=E{r}-D{r}"); c.font = F(8, neg); c.number_format = FMT_USD
        c = ws.cell(r, 7, f'=IF(D{r}=0,"",F{r}/ABS(D{r}))'); c.font = F(8, neg)
        c.number_format = FMT_PCT
        c = ws.cell(r, 9, f'=IF(ABS(E{r})>=$F${f_um},"SÍ","")')
        c.font = F(8, True); c.alignment = Alignment(horizontal="center")
        c = ws.cell(r, 10, f'=IF(ABS(E{r})>=$D${f_um},"SÍ","")')
        c.font = F(8, True, ROJO); c.alignment = Alignment(horizontal="center")
        # calificación de riesgo: K probabilidad y L impacto con lista, M nivel por fórmula
        for k in (11, 12):
            cc = ws.cell(r, k); cc.fill = FILL_AMARILLO
            cc.alignment = Alignment(horizontal="center"); cc.font = F(8, True)
            dvr.add(cc)
        cc = ws.cell(r, 13, formula_nivel_riesgo("K", "L", r))
        cc.font = F(8, True); cc.alignment = Alignment(horizontal="center")
        cm = ws.cell(r, 14); cm.fill = FILL_AMARILLO
        cm.alignment = Alignment(horizontal="center"); cm.font = F(10, True)
        dvm.add(cm)
        ws.cell(r, 15).fill = FILL_AMARILLO
        for k in range(1, NC + 1):
            ws.cell(r, k).border = BOX
            if tipo == "sub": ws.cell(r, k).fill = FILL_SUB
            if tipo in ("subbloque", "total"): ws.cell(r, k).fill = FILL_TOT
        r += 1

    # % del ciclo
    for rr2 in range(f_ini, f_total + 1):
        if ws.cell(rr2, 5).value is not None:
            c = ws.cell(rr2, 8, f'=IF($E${f_total}=0,"",E{rr2}/$E${f_total})')
            c.font = F(8); c.number_format = FMT_PCT

    # control contra el balance de comprobación
    r += 1
    tot_cli_jul = sum(v(jul, p) for _, ps in spec["bloques"] for p in ps)
    tot_cli_dic = sum(v(dic, p) for _, ps in spec["bloques"] for p in ps)
    ws.cell(r, 2, "Saldo del ciclo según el balance de comprobación (suma de encabezados)").font = F(8, True)
    c = ws.cell(r, 4, tot_cli_dic); c.font = F(8, True, AZUL); c.number_format = FMT_USD
    c = ws.cell(r, 5, tot_cli_jul); c.font = F(8, True, AZUL); c.number_format = FMT_USD
    for k in range(1, NC + 1):
        ws.cell(r, k).border = BOX; ws.cell(r, k).fill = FILL_GRIS
    f_cli = r
    r += 1
    ws.cell(r, 2, "DIFERENCIA (debe ser cero)").font = F(9, True)
    for col, letra in ((4, "D"), (5, "E")):
        c = ws.cell(r, col, f"={letra}{f_total}-{letra}{f_cli}"); c.font = F(9, True)
        c.number_format = FMT_USD
    c = ws.cell(r, 9, f'=IF(AND(ABS(D{r})<0.01,ABS(E{r})<0.01),"CUADRA","≠ REVISAR")')
    c.font = F(8, True); c.alignment = Alignment(horizontal="center")
    for k in range(1, NC + 1):
        ws.cell(r, k).border = BOX; ws.cell(r, k).fill = FILL_TOT
    r += 1
    ctrl = spec.get("control")
    if ctrl:
        cta_ctrl, menos = ctrl
        etiqueta = f"Cuenta de control {cta_ctrl}"
        if menos:
            etiqueta += " menos " + ", ".join(menos)
        ws.cell(r, 2, f"CONTROL DE COMPLETITUD — {etiqueta} según el balance de comprobación").font = F(8, True)
        for col, df in ((4, dic), (5, jul)):
            val = v(df, cta_ctrl) - sum(v(df, m) for m in menos)
            c = ws.cell(r, col, val); c.font = F(8, True, AZUL); c.number_format = FMT_USD
        for k in range(1, NC + 1):
            ws.cell(r, k).border = BOX; ws.cell(r, k).fill = FILL_GRIS
        f_ctrl = r
        r += 1
        ws.cell(r, 2, "DIFERENCIA DE COMPLETITUD (debe ser cero: toda cuenta del grupo está incluida)").font = F(9, True)
        for col, letra in ((4, "D"), (5, "E")):
            c = ws.cell(r, col, f"={letra}{f_total}-{letra}{f_ctrl}"); c.font = F(9, True)
            c.number_format = FMT_USD
        c = ws.cell(r, 9, f'=IF(AND(ABS(D{r})<0.01,ABS(E{r})<0.01),"COMPLETO","≠ FALTAN CUENTAS")')
        c.font = F(8, True); c.alignment = Alignment(horizontal="center")
        for k in range(1, NC + 1):
            ws.cell(r, k).border = BOX; ws.cell(r, k).fill = FILL_TOT
        r += 2
    ws.cell(r, 2, "Saldo del ciclo / Materialidad global  (número de veces)").font = F(8, True)
    c = ws.cell(r, 5, f"=IF($D${f_um}=0,\"\",ABS(E{f_total})/$D${f_um})"); c.font = F(8, True)
    c.number_format = FMT_X
    for k in range(1, NC + 1): ws.cell(r, k).border = BOX
    r += 2

    # reconciliación especial de F-2 con el grupo 5
    if spec["ref"] == "F-2":
        ws.cell(r, 2, "Reconciliación con el total del grupo 5. del estado de resultados").font = F(9, True)
        for k in range(1, NC + 1):
            ws.cell(r, k).fill = FILL_CAB; ws.cell(r, k).border = CAB_BORDE
        ws.cell(r, 2).font = F(9, True, MARCA_NEGRO)
        r += 1
        for et, d, j in (("Total de este papel (F-2)", None, None),
                         ("Mano de obra directa e indirecta (ver K-4)",
                          v(dic, "5.1.2.") + v(dic, "5.1.3."), v(jul, "5.1.2.") + v(jul, "5.1.3.")),
                         ("Total grupo 5. según balance de comprobación", v(dic, "5."), v(jul, "5."))):
            ws.cell(r, 2, et).font = F(8, True)
            if d is None:
                ws.cell(r, 4, f"=D{f_total}").number_format = FMT_USD
                ws.cell(r, 5, f"=E{f_total}").number_format = FMT_USD
            else:
                c = ws.cell(r, 4, d); c.number_format = FMT_USD; c.font = F(8, color=AZUL)
                c = ws.cell(r, 5, j); c.number_format = FMT_USD; c.font = F(8, color=AZUL)
            for k in range(1, NC + 1): ws.cell(r, k).border = BOX
            r += 1
        ws.cell(r, 2, "DIFERENCIA (debe ser cero)").font = F(9, True)
        for col, letra in ((4, "D"), (5, "E")):
            c = ws.cell(r, col, f"={letra}{r-3}+{letra}{r-2}-{letra}{r-1}")
            c.font = F(9, True); c.number_format = FMT_USD
        c = ws.cell(r, 9, f'=IF(AND(ABS(D{r})<0.01,ABS(E{r})<0.01),"CUADRA","≠ REVISAR")')
        c.font = F(8, True); c.alignment = Alignment(horizontal="center")
        for k in range(1, NC + 1):
            ws.cell(r, k).border = BOX; ws.cell(r, k).fill = FILL_TOT
        r += 2

    formato_riesgo(ws, f"K{f_ini}:M{f_total}")
    r = seccion(ws, r, "Matriz de calificación del riesgo", [
        "Las columnas Probabilidad e Impacto se seleccionan de la lista desplegable ALTO / MEDIO / BAJO. El Nivel "
        "de riesgo NO se escribe: es una fórmula que aplica la matriz 3x3 asignando ALTO=3, MEDIO=2 y BAJO=1 y "
        "multiplicando ambos factores; un producto igual o mayor a 6 resulta ALTO, entre 3 y 4 MEDIO, y entre 1 y "
        "2 BAJO. Equivale a: Alto/Alto y Alto/Medio = ALTO; Alto/Bajo y Medio/Medio = MEDIO; Medio/Bajo y "
        "Bajo/Bajo = BAJO. El nivel resultante determina la naturaleza, oportunidad y extensión de los "
        "procedimientos sustantivos que se aplicarán a la cuenta (NIA 330).",
    ], NC)
    r = seccion(ws, r, "Observaciones del análisis preliminar", spec["notas"], NC)
    r = cierre(ws, r, NC,
        marcas=[("©", "Saldo tomado del balance de comprobación del período indicado."),
                ("√", "Cotejado contra documentación fuente del cliente."),
                ("®", "Recalculado de forma independiente por el auditor."),
                ("∑", "Sumado y verificado aritméticamente."),
                ("≠", "Diferencia detectada — documentar como excepción de auditoría."),
                ("P/I", "Pendiente de información del cliente.")],
        referencias=[
            "Balance de comprobación al 31 de diciembre de 2025 y al 31 de julio de 2026.",
            "Papel P-01 Determinación de la Materialidad (umbrales aplicados en este papel).",
            "Papeles A-1 y B-1 del libro de comparativos (los saldos deben coincidir con aquellos).",
        ])
    ws.freeze_panes = f"D{f_ini}"
    resumen.append((spec["ref"], spec["hoja"], spec["nombre"], tot_cli_dic, tot_cli_jul, f_total))
    print(f"  {spec['ref']:<5}{spec['nombre'][:44]:<46} dic-25={tot_cli_dic:>16,.2f}  jul-26={tot_cli_jul:>16,.2f}")

# ==================================================== ÍNDICE
ws0 = wb.create_sheet("Índice de sumarias", 0)
NC0 = 9
anchos(ws0, [10, 46, 16, 16, 16, 11, 12, 14, 30])
r = encabezado(ws0, "SUM", "Índice de cédulas sumarias por ciclo", NC0)
r = seccion(ws0, r, "Objetivo", [
    "Presentar el índice de las cédulas sumarias que integran el alcance autorizado del encargo, con el saldo de "
    "cada ciclo, su variación respecto del ejercicio anterior y su magnitud frente a la materialidad, para "
    "orientar la asignación del esfuerzo de auditoría.",
], NC0)
r = seccion(ws0, r, "Alcance autorizado", [
    "Ciclos comprendidos: efectivo, inventarios, cuentas por cobrar, cuentas por pagar, ingresos, compras y "
    "nómina. Quedan fuera del alcance de este libro los ciclos de inversiones (D), gastos anticipados (G), "
    "propiedades planta y equipo (H), otros activos (I), obligaciones financieras (L), patrimonio (M), impuestos "
    "(K-3) y la conciliación tributaria (Z), que forman parte del índice completo de la firma.",
], NC0)
dv_enf = dv_lista(ws0, ENFOQUE_LISTA, "Enfoque de auditoría",
                  "Seleccione el enfoque definido para el ciclo.")
r = cabecera(ws0, r, ["Ref.", "Cédula sumaria", "31-dic-2025", "31-jul-2026", "Variación",
                      "Variación %", "Veces la MG", "Enfoque", "Observación"], alto=30)
for ref, hoja, nombre, d25, j26, f_tot in resumen:
    ws0.cell(r, 1, ref).font = F(9, True, MARCA_AMBAR)
    ws0.cell(r, 1).alignment = Alignment(horizontal="center")
    c = ws0.cell(r, 2, nombre); c.font = F(8)
    c = ws0.cell(r, 3, f"='{hoja}'!D{f_tot}"); c.font = F(8, color=VERDE); c.number_format = FMT_USD
    c = ws0.cell(r, 4, f"='{hoja}'!E{f_tot}"); c.font = F(8, True, VERDE); c.number_format = FMT_USD
    c = ws0.cell(r, 5, f"=D{r}-C{r}"); c.font = F(8); c.number_format = FMT_USD
    c = ws0.cell(r, 6, f'=IF(C{r}=0,"",E{r}/ABS(C{r}))'); c.font = F(8); c.number_format = FMT_PCT
    c = ws0.cell(r, 7, f"=ABS(D{r})/{MG}"); c.font = F(8, True); c.number_format = FMT_X
    c = ws0.cell(r, 8, "Sustantivo"); c.font = F(8, True)
    c.alignment = Alignment(horizontal="center"); c.fill = FILL_AMARILLO
    dv_enf.add(c)
    ws0.cell(r, 9).fill = FILL_AMARILLO
    for k in range(1, NC0 + 1): ws0.cell(r, k).border = BOX
    r += 1
r += 1
ws0.cell(r, 2, "Materialidad global (P-01)").font = F(8, True)
c = ws0.cell(r, 4, MG); c.font = F(8, True, VERDE); c.number_format = FMT_USD
for k in range(1, NC0 + 1): ws0.cell(r, k).border = BOX
r += 1
ws0.cell(r, 2, "Error tolerable (P-01)").font = F(8, True)
c = ws0.cell(r, 4, ME); c.font = F(8, True, VERDE); c.number_format = FMT_USD
for k in range(1, NC0 + 1): ws0.cell(r, k).border = BOX
r += 2
r = nota_alerta(ws0, r, NC0,
    "El enfoque de todos los ciclos es SUSTANTIVO. La entidad no cuenta con narrativas ni con documentación de "
    "controles internos previamente levantada, por lo que conforme a la planificación no se deposita confianza en "
    "los controles y no se ejecutan pruebas de controles como base para reducir el alcance de las pruebas de "
    "detalle. Las narrativas y las pruebas de recorrido se levantan en el libro de narrativas de este mismo encargo.")
r = bloque_normativa(ws0, r, NC0, [200, 230, 300, 315, 320, 330, 450, 500, 510, 520, 530, 265],
                     marco_niif="NIIF para las PYMES — marco de información financiera aplicable a la entidad.",
                     otras=[("Societaria", "Ley de Compañías y normativa de la Superintendencia de Compañías, "
                                           "Valores y Seguros."),
                            ("Tributaria", "Ley de Régimen Tributario Interno, su Reglamento y resoluciones "
                                           "vigentes del Servicio de Rentas Internas.")])
r = cierre(ws0, r, NC0, marcas=[("©", "Saldo enlazado a la cédula sumaria correspondiente.")],
           referencias=["Cédulas sumarias C-1, E-1, F-1, F-2, J-1, K-4, N-1 y P-1 de este libro.",
                        "Papel P-01 Determinación de la Materialidad."])

for h in wb.sheetnames:
    w = wb[h]
    w.sheet_view.showGridLines = False
    w.page_setup.orientation = "landscape"
    w.page_setup.paperSize = 9
    w.sheet_properties.pageSetUpPr.fitToPage = True
    w.page_setup.fitToWidth = 1
    w.page_setup.fitToHeight = 0
    w.oddFooter.left.text = f"{CLIENTE} — {CORTE}"
    w.oddFooter.left.size = 7
    w.oddFooter.right.text = "&P / &N"
    w.oddFooter.right.size = 7

wb.save(f"{PREFIJO}_Sumarias.xlsx")
print("OK Sumarias:", wb.sheetnames)
