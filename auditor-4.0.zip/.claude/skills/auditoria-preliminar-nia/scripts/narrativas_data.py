# -*- coding: utf-8 -*-
"""Bancos de preguntas, riesgos y controles consolidados de las narrativas de la firma.

Origen: cuestionarios de entendimiento por proceso y hojas de identificación de
riesgos y controles (CA-02 / CC-02 / CA-03) del archivo de papeles de la firma,
complementados con NIA, el marco contable aplicable y referencias de Auditool.

REGLA: las respuestas del período anterior NO se trasladan. Las columnas de
respuesta salen SIEMPRE en blanco, para levantarse de nuevo en la entrevista del
ejercicio corriente. Un cuestionario prellenado con las respuestas del año pasado
no es evidencia de auditoría.
"""

# ---------------------------------------------------------------- TESORERÍA
TESORERIA = dict(
    ref="C-01", ref_2024="CE-01", confirmada=True, hoja="C-01 Tesorería",
    archivo="NAR_C-01_Tesoreria",
    nombre="TESORERÍA", ciclo_cuenta="C — Efectivo y equivalentes al efectivo",
    objetivo=("Garantizar la adecuada administración de los recursos financieros mediante la gestión integral de "
              "tesorería, asegurando la existencia, integridad, exactitud, oportunidad y revelación razonable de "
              "las transacciones de cobros y pagos en los estados financieros."),
    entrada=["Operación y/o requerimiento a seguir: solicitudes de pago, reposiciones, transferencias y "
             "movimientos de caja.",
             "Disponibilidad presupuestal: validación de fondos en cuentas bancarias o caja.",
             "Autorización de desembolso en caja menor: aprobación de gerencia o responsable financiero para "
             "ejecutar el pago."],
    etapas=[("1) Definición del flujo de caja",
             "Revisión de fondos disponibles y programación de pagos según prioridades operativas."),
            ("2) Gestión de recaudo",
             "Control y registro de ingresos provenientes de clientes o terceros, asegurando su correcta "
             "aplicación en contabilidad."),
            ("3) Gestión de pagos",
             "Ejecución de pagos a proveedores y obligaciones financieras conforme a las políticas internas."),
            ("4) Uso de tarjetas de crédito corporativas",
             "Control y registro de consumos realizados con tarjetas empresariales, incluyendo revisión y "
             "conciliación de respaldos."),
            ("5) Conciliaciones bancarias",
             "Revisión y conciliación periódica entre los saldos del sistema contable y los extractos bancarios, "
             "asegurando la integridad de la información.")],
    salida=["Soporte documentado de las transacciones (órdenes de pago, facturas, recibos, comprobantes bancarios).",
            "Registro contable de pagos y cobros en el sistema financiero.",
            "Conciliaciones bancarias mensuales aprobadas y archivadas.",
            "Evidencia documental de revisiones y aprobaciones internas."],
    sistemas=[("JIREH / ERP financiero — módulo Tesorería",
               "Sistema utilizado para registrar y controlar los pagos, cobros y conciliaciones bancarias."),
              ("Banca electrónica",
               "Plataforma para ejecución y validación de transferencias y pagos electrónicos."),
              ("Cash management / hojas de control interno",
               "Herramientas de planificación y control de flujos de efectivo y movimientos diarios.")],
    transacciones=[("1", "Pagos semanales", "Rutinarias", "Valuación"),
                   ("2", "Revisión de la documentación para pagos", "Rutinarias", "Existencia"),
                   ("3", "Documentación legal", "No rutinarias", "Propiedad")],
    riesgos_negocio=[("1", "Falta de actualización de los procesos y manuales de tesorería (el último aprobado "
                           "data de 2017).", "Integridad · Exactitud")],
    preguntas=[
        ("Políticas y procedimientos de tesorería", [
            "¿Existe un manual de políticas y procedimientos de tesorería aprobado? ¿Cuál es su fecha de "
            "aprobación y de última actualización?",
            "¿Con qué periodicidad se revisan y actualizan los manuales, y quién otorga la aprobación formal?",
            "¿Qué áreas participan en la revisión de los procedimientos (contabilidad, finanzas, auditoría "
            "interna)?"]),
        ("Definición del flujo de caja", [
            "¿Cómo se determina la disponibilidad de fondos antes de programar los pagos?",
            "¿Cómo se establecen las prioridades de pago y quién las aprueba?",
            "¿Se elabora un flujo de caja proyectado y quién lo revisa?"]),
        ("Gestión de recaudo", [
            "¿Cómo se reciben los cobros de clientes (efectivo, transferencia, tarjeta, depósito) y quién los "
            "recibe?",
            "¿Cómo y con qué oportunidad se depositan los valores recibidos, y quién verifica el depósito?",
            "¿Quién aplica los cobros a las facturas y cómo se controla que la aplicación sea correcta?"]),
        ("Gestión de pagos", [
            "¿Cómo se crea un proveedor en el sistema, qué documentación se exige y quién ejecuta la creación?",
            "¿Quién puede modificar los datos maestros del proveedor, en especial la cuenta bancaria de pago?",
            "¿Cómo se origina la orden de pago y qué documentación la respalda?",
            "¿Quiénes confirman que las facturas a pagar son correctas antes de procesar el pago?",
            "¿Con qué frecuencia se procesan los pagos y cómo se obtiene el reporte de cartera por vencer?",
            "¿El sistema presenta errores al descargar la cartera para pagos? ¿Cómo se controla el riesgo de "
            "pago duplicado?",
            "¿Quién autoriza la carga del pago en el banco y quién aprueba su liberación?",
            "¿Cómo se verifica posteriormente que todos los pagos se ejecutaron sin novedad?"]),
        ("Pagos a proveedores del exterior", [
            "¿Qué procedimiento adicional se aplica a los pagos al exterior y qué documentación los respalda?",
            "¿Cómo se determinan y practican las retenciones aplicables a los pagos al exterior?",
            "¿Cómo se controla la conversión y la diferencia en cambio de esas operaciones?"]),
        ("Uso de tarjetas de crédito corporativas", [
            "¿Quiénes son titulares de tarjetas corporativas y quién autoriza su asignación?",
            "¿Cómo se revisan, respaldan y concilian los consumos realizados con tarjetas empresariales?"]),
        ("Fondos de caja y caja chica", [
            "¿Cómo se asignan, reponen y sustentan los fondos de caja chica, y quién es responsable de cada "
            "fondo?",
            "¿Con qué frecuencia se realizan arqueos y quién los ejecuta?"]),
        ("Conciliaciones bancarias", [
            "¿Quién elabora la conciliación bancaria, con qué frecuencia y quién la revisa y aprueba?",
            "¿Cómo se evidencia la revisión y la aprobación de la conciliación?",
            "¿Cómo se investigan y depuran las partidas conciliatorias pendientes? ¿Existe un plazo máximo?",
            "¿Quién tiene acceso a todas las cuentas bancarias de la Compañía y cómo se controla?"]),
        ("Segregación de funciones y accesos", [
            "¿Están segregadas las funciones de recepción de valores, depósito, registro, autorización de pago, "
            "ejecución del pago y conciliación?",
            "¿Quiénes tienen firmas autorizadas y accesos (tokens, claves, banca electrónica) en cada cuenta, y "
            "cómo se custodian?"]),
    ],
    riesgos=[
        ("DEFINICIÓN DEL FLUJO DE CAJA Y GESTIÓN DE PAGOS", [
            ("TA", "Los manuales y procedimientos de tesorería no se encuentran actualizados: el último fue "
                   "aprobado en 2017 según el papel CE-01 del ejercicio anterior."),
            ("TB", "El sistema JIREH presenta un error al descargar la cartera para pagos, generando facturas "
                   "con el mismo número y arrojando la fecha más antigua, según consta en el papel CE-01 del "
                   "ejercicio anterior. Riesgo de pago duplicado y de integridad del pasivo."),
        ]),
        ("GESTIÓN DE RECAUDO", []),
        ("USO DE TARJETAS DE CRÉDITO CORPORATIVAS", []),
        ("CONCILIACIONES BANCARIAS", []),
    ],
    controles=[],
    notas=["El papel CE-01 del ejercicio anterior documentó que los manuales de procesos de tesorería fueron "
           "aprobados en 2017 y no han sido actualizados. Debe verificarse si esa condición persiste en 2026 y, "
           "de ser así, incluirla en la carta de control interno (NIA 265).",
           "El papel anterior documentó una falla del sistema JIREH al descargar la cartera para pagos: genera "
           "facturas con el mismo número y arroja la fecha más antigua. Debe evaluarse el efecto de esa falla en "
           "la integridad del pasivo y en el riesgo de pago duplicado.",
           "El saldo de efectivo disminuyó un 87,0% entre el 31 de diciembre de 2025 y el 31 de julio de 2026. "
           "El recorrido debe cubrir específicamente el destino de esos recursos."],
)

# ------------------------------------------------- VENTAS Y CUENTAS POR COBRAR
VENTAS = dict(
    ref="E-01", ref_2024="CA-01", confirmada=True, hoja="E-01 Ventas y CxC",
    archivo="NAR_E-01_Ventas_y_Cuentas_por_cobrar",
    nombre="VENTAS Y CUENTAS POR COBRAR", ciclo_cuenta="E — Cuentas por cobrar  ·  N — Ingresos",
    objetivo=("Iniciar, procesar y registrar el ingreso relacionado con la venta de los productos terminados para "
              "garantizar su integridad, existencia, exactitud y presentación y revelación en los estados "
              "financieros."),
    entrada=["Elaboración de la solicitud y negociación de los términos comerciales.",
             "Creación de clientes y acuerdos comerciales.",
             "Elaboración de la orden de producción y ventas.",
             "Otorgamiento de cupo de crédito.",
             "Solicitud de venta.",
             "Revisión del stock de inventario.",
             "Elaboración de la orden de compra del cliente."],
    etapas=[("1) Generación del pedido", ""),
            ("2) Elaboración de la factura de venta", ""),
            ("3) Registro de la venta", ""),
            ("4) Distribución y entrega", ""),
            ("5) Creación y administración de clientes", ""),
            ("6) Recaudo y aplicación de cobros", "")],
    salida=["Facturas de venta emitidas y guías de remisión.",
            "Registro contable del ingreso y del costo de ventas asociado.",
            "Cartera por cliente y reporte de antigüedad.",
            "Notas de crédito autorizadas y aplicadas."],
    sistemas=[("JIREH / ERP financiero — módulos de facturación y cartera",
               "Emisión de facturas, control de cupos de crédito y registro de la cartera.")],
    transacciones=[("1.1.2.01.", "Clientes no relacionados", "Rutinarias", "Integridad"),
                   ("1.1.2.10.", "Provisión cuentas incobrables y deterioro", "Rutinarias", "Valuación"),
                   ("4.1.1.", "Ventas de bienes", "Rutinarias", "Ocurrencia · Exactitud · Corte"),
                   ("4.2.1. / 4.3.1.", "Descuentos y devoluciones en ventas", "Rutinarias",
                    "Exactitud · Ocurrencia")],
    riesgos_negocio=[("1", "Deterioro de las cuentas por cobrar comerciales.", "Integridad · Valuación"),
                     ("2", "Recuperación de cartera.", "Valuación · Existencia"),
                     ("3", "Antigüedad de cartera de difícil recuperación.", "Integridad · Valuación")],
    preguntas=[
        ("Políticas del ciclo y administración de clientes", [
            "¿Existe una política de crédito y cobranza formalmente aprobada? ¿Cuál es su fecha de aprobación y "
            "de última actualización?",
            "¿Cómo se aprueba un nuevo cliente y su cupo de crédito, y qué documentación se exige? (control C1)",
            "¿El estudio de crédito considera reportes de centrales de riesgo y la situación financiera del "
            "cliente? (control C2)",
            "¿Quién administra el maestro de clientes y qué documentación soporta su creación y actualización? "
            "(control C3)",
            "¿Cómo se determina y soporta el tipo de contribuyente tributario con el que se crea cada cliente? "
            "(control C4)",
            "¿Con qué frecuencia se revisan y actualizan los cupos de crédito asignados?"]),
        ("Generación del pedido", [
            "¿Cómo se origina el pedido en cada canal de venta (distribuidores, mayoristas, almacenes, digital, "
            "exportación, clientes especiales)?",
            "¿El sistema verifica automáticamente el cupo de crédito disponible y la mora antes de aceptar el "
            "pedido? (riesgo C)",
            "¿Quién autoriza la liberación de pedidos bloqueados por crédito o por mora y cómo se documenta? "
            "(riesgo N)",
            "¿Las órdenes de venta pueden modificarse una vez generadas? ¿Quién puede hacerlo y queda registro? "
            "(riesgo A)",
            "¿Todas las órdenes deben diligenciarse completamente para poder generar la venta? (control C10)",
            "¿Cómo se identifican y corrigen las órdenes con información incompleta o errada? (control C11)",
            "¿Cómo se verifica que todos los pedidos solicitados se hayan despachado y facturado? (riesgo B, "
            "control C13)"]),
        ("Precios, descuentos y condiciones comerciales", [
            "¿Quién aprueba la lista de precios y con qué frecuencia se verifica su vigencia en el sistema? "
            "(control C7)",
            "¿El sistema tiene parametrizada una tabla de descuentos que impida otorgar descuentos fuera del "
            "rango aprobado? (control C6)",
            "¿Quién autoriza excepciones de precio o descuento y cómo se documentan? (riesgos F y G)",
            "¿Existe un control automático de aprobación para ventas que superan un monto definido? (control C5)",
            "¿Existen metas, comisiones o incentivos ligados al volumen de ventas? ¿Cómo podrían influir en el "
            "reconocimiento del ingreso? (NIA 240)"]),
        ("Facturación", [
            "¿Las facturas se generan automáticamente desde el pedido y llevan consecutivo electrónico asociado "
            "al pedido del cliente? (control C9)",
            "¿Cómo se controla la secuencia y la vigencia de los comprobantes de venta autorizados, y cómo se "
            "revisan los anulados? (riesgo NR3)",
            "¿Quién autoriza las anulaciones de facturas y cómo se monitorean? (control C18)",
            "¿El sistema tiene parametrizado el cálculo de impuestos y con qué frecuencia se verifica? "
            "(riesgo E, control C14)",
            "¿Cómo se previene el cruce de códigos de producto en la factura? (riesgo NR2)",
            "¿Se comparan la orden de compra del cliente, el pedido, la factura y las unidades despachadas para "
            "identificar diferencias? (control C12)"]),
        ("Despacho y entrega", [
            "¿En qué momento se considera transferido el control al cliente en cada canal y con qué evidencia se "
            "sustenta? (Sección 23 de la NIIF para las PYMES)",
            "¿Quién verifica que lo facturado corresponda con lo físico y con la orden de transporte antes de la "
            "salida? (control C19)",
            "¿Qué controles físicos existen sobre la mercadería despachada (sellos, muelles, cámaras)? "
            "(controles C20 y C21)",
            "¿Cómo se controla la entrega de mercadería a clientes que no corresponden o en cantidades distintas "
            "a las solicitadas? (riesgo L)",
            "¿Se monitorean indicadores de precisión en el alistamiento y las quejas de clientes por errores de "
            "entrega? (controles C22 y C23)"]),
        ("Devoluciones y notas de crédito", [
            "¿Quién autoriza las notas de crédito y con qué límites según el monto? (control C31)",
            "¿Las notas de crédito tienen consecutivo y se asocian siempre a una factura? (control C31)",
            "¿Se verifica el ingreso físico de la mercadería devuelta antes de emitir la nota de crédito? "
            "(control C24)",
            "¿Se monitorean periódicamente los saldos de notas de crédito por cliente para detectar "
            "comportamientos inusuales? (control C32)",
            "¿Qué volumen de notas de crédito se emite después del cierre de cada mes y sobre ventas de qué "
            "período?"]),
        ("Recaudo y aplicación de cobros", [
            "¿Cómo se reciben los cobros en cada modalidad y quién los recibe?",
            "¿Los recaudos en efectivo se consignan íntegramente en el banco y se mantienen importes mínimos en "
            "tesorería? (control C25)",
            "¿Las instalaciones de recaudo tienen controles de acceso, cámaras y caja fuerte? (control C26)",
            "¿Todo recaudo tiene asignado un recibo de caja con número consecutivo? (control C27)",
            "¿Quién aplica los cobros a las facturas y cómo se controla que la aplicación sea al cliente y a la "
            "factura correctos? (riesgo I)",
            "¿Se concilian diariamente los pagos y se investigan oportunamente las diferencias de recaudo? "
            "(control C29)",
            "¿Cómo se gestionan los cheques devueltos y en qué momento se bloquea al cliente? (control C28)",
            "¿Cómo se concilian los cobros con tarjeta de crédito contra las liquidaciones de las "
            "administradoras?"]),
        ("Cartera, deterioro y confirmaciones", [
            "¿Cómo se elabora y con qué frecuencia se revisa el reporte de antigüedad de cartera?",
            "¿Cómo se determina la provisión por deterioro de cartera, quién la calcula y quién la aprueba? "
            "(Sección 11 de la NIIF para las PYMES)",
            "¿Existe un procedimiento formal para las cuentas incobrables y quién autoriza su baja? (riesgo R)",
            "¿Se realizan confirmaciones periódicas de saldos con los clientes? (control C30)",
            "¿Cómo se gestionan y escalan los vencimientos, y quién da seguimiento a la cobranza?",
            "¿Cómo se controlan y aprueban las cuentas por cobrar a empleados, accionistas y partes "
            "relacionadas? (Sección 33)"]),
        ("Registro contable, corte y presentación", [
            "¿El registro del ingreso y del costo de venta asociado es automático desde la facturación?",
            "¿Quién puede modificar la documentación soporte o los registros de ventas una vez emitidos? "
            "(riesgo J)",
            "¿Qué controles aseguran que los estados financieros reflejen la totalidad de las ventas realizadas? "
            "(riesgo K)",
            "¿Cómo se controla el corte de ventas al cierre de cada período (últimas y primeras transacciones)?",
            "¿Se identifican los deudores con saldo acreedor para evaluar su reclasificación al pasivo?"]),
        ("Segregación de funciones y accesos", [
            "¿Están segregadas las funciones de custodia del inventario, facturación, despacho, contabilidad y "
            "tesorería? (riesgo M, control C15)",
            "¿Con qué frecuencia se revisan y actualizan los accesos a los aplicativos según funciones y cargos? "
            "(control C16)",
            "¿Cada colaborador tiene usuario y clave individual, sin usuarios genéricos? (control C17)"]),
        ("Cumplimiento tributario", [
            "¿Cómo se concilian las ventas contables contra el formulario 104 y el ATS de cada mes?",
            "¿Cómo se controlan las ventas a partes relacionadas, muestras, autoconsumo y ventas a empleados?",
            "¿Cómo se registran y controlan las retenciones que los clientes practican a la Compañía?"]),
    ],
    riesgos=[
        ("GENERACIÓN DEL PEDIDO", [
            ("A", "Las órdenes de venta son modificadas o alteradas."),
            ("B", "No se facturan las ventas o se incumple con la entrega de las órdenes de pedido."),
            ("C", "Creación de pedidos en el sistema de información con cupos y plazos no autorizados, por falta "
                  "de control manual y/o automático."),
            ("D", "La facturación al cliente difiere de las características comerciales autorizadas en la "
                  "solicitud de pedido."),
            ("NR1", "La facturación puede tener error por mala aplicación de un precio de venta."),
        ]),
        ("ELABORACIÓN DE LA FACTURA DE VENTA", [
            ("E", "Sanciones económicas por errores en el cálculo de los impuestos y deducciones a los clientes."),
            ("F", "Cambios en los precios y descuentos otorgados sin autorización, generando pérdida en los "
                  "resultados estimados sobre las ventas."),
            ("G", "Pérdidas económicas por ventas con precios por debajo de los establecidos."),
            ("H", "Los pagos no se registran completamente y existen faltantes de facturas."),
            ("NR2", "Error por cruce de códigos de productos en la factura."),
        ]),
        ("REGISTRO DE LA VENTA", [
            ("I", "Las entradas de efectivo no se registran con el cliente correcto ni contablemente."),
            ("J", "Modificaciones en la documentación soporte o en los registros de las ventas."),
            ("K", "Los estados financieros no reflejan la realidad de las ventas realizadas."),
            ("NR3", "Las facturas de venta no se autorizan oportunamente."),
        ]),
        ("DISTRIBUCIÓN Y ENTREGA", [
            ("L", "Entrega de la mercancía a clientes que no corresponden o en cantidades diferentes a las "
                  "solicitadas."),
            ("M", "Concentración de funciones entre ventas, contabilidad, inventario y/o tesorería."),
            ("N", "Liberación de pedidos bloqueados sin evaluación y autorización."),
            ("NR4", "Retraso en la entrega de productos."),
        ]),
        ("CREACIÓN Y ADMINISTRACIÓN DE CLIENTES", [
            ("O", "Ventas a crédito a clientes que no tienen capacidad de pago o que no han sido aprobados."),
            ("P", "Venta a clientes ficticios."),
            ("Q", "Venta de mercancía a clientes sin cupo disponible de crédito o con incumplimiento en los pagos."),
            ("R", "Pérdidas económicas por ausencia de un procedimiento para las cuentas incobrables."),
            ("S", "Otorgar créditos a clientes sin capacidad de pago y/o sin análisis de su situación financiera."),
        ]),
    ],
    controles=[
        ("C1", "Todos los clientes vinculados tienen un cupo de crédito aprobado previamente."),
        ("C2", "Los estudios de crédito consideran los reportes a las centrales de riesgos y la situación "
               "financiera, entre otros aspectos."),
        ("C3", "Los clientes son creados por el área que administra el maestro de clientes, previa documentación "
               "soporte y actualización de datos."),
        ("C4", "La asignación del tipo de contribuyente tributario con el cual son creados los clientes se "
               "encuentra soportada."),
        ("C5", "Se ha establecido un control de aprobación automático para las ventas que superan el monto "
               "aprobado."),
        ("C6", "En el sistema se ha parametrizado una tabla de descuentos, asegurando que los descuentos "
               "otorgados se encuentran dentro del rango aprobado."),
        ("C7", "La tabla de precios es autorizada, registrada y verificada periódicamente."),
        ("C8", "La creación, modificación y retiro de las referencias en el sistema es verificada periódicamente."),
        ("C9", "Todas las órdenes de venta y/o facturas son generadas automáticamente y llevan un consecutivo "
               "electrónico, y están asociadas a un número de pedido del cliente."),
        ("C10", "Todas las órdenes de compra deben ser diligenciadas con la información en cada uno de sus campos "
                "para poder generar la venta."),
        ("C11", "Todas las órdenes con información incompleta o errada son identificadas con un formato especial "
                "para su seguimiento y corrección."),
        ("C12", "Se comparan los registros de la orden de compra con los del pedido asociado, la factura y las "
                "unidades despachadas para identificar diferencias."),
        ("C13", "Se verifica regularmente que todos los pedidos solicitados hayan sido despachados y que todos "
                "los pedidos y/u órdenes de despacho estén facturados."),
        ("C14", "El sistema tiene parametrizado el cálculo de los impuestos y el mismo es verificado de forma "
                "regular."),
        ("C15", "Segregación de funciones en la custodia del inventario, facturación, despacho, contabilidad y "
                "tesorería, entre otros."),
        ("C16", "Periódicamente se revisan y actualizan los accesos a los aplicativos, de acuerdo con las "
                "funciones y cargos desempeñados."),
        ("C17", "Se tiene asignado un usuario y una clave para cada colaborador que hace registros en el sistema, "
                "por lo cual no se tienen usuarios genéricos."),
        ("C18", "Todas las anulaciones de facturas y órdenes de transporte son realizadas por un nivel superior "
                "al que las prepara, y se lleva un monitoreo periódico de las mismas."),
        ("C19", "Toda la mercancía despachada es verificada por el área de seguridad validando que lo facturado "
                "corresponda con lo físico y con la orden de transporte."),
        ("C20", "Los vehículos son sellados tanto al momento de su retiro como durante su etapa de "
                "estacionamiento."),
        ("C21", "Los muelles de embarque únicamente son habilitados para el cargue de mercancía y cuentan con "
                "cámaras de seguridad."),
        ("C22", "Se han implementado indicadores de seguimiento para reducir el margen de error al alistar los "
                "productos a despachar de acuerdo con los pedidos."),
        ("C23", "Se monitorean las quejas y reclamos de los clientes sobre los errores en la entrega de los "
                "productos."),
        ("C24", "La devolución de mercancía tiene asignada un área especial y cuenta con controles de "
                "verificación físicos y de ubicación en inventario."),
        ("C25", "Los recaudos de los pagos en efectivo deben ser consignados en el banco y las cantidades "
                "entregadas en tesorería son mínimas."),
        ("C26", "Las instalaciones asignadas para recibir el recaudo en efectivo tienen controles de acceso, "
                "cámaras de seguridad y caja fuerte, entre otros."),
        ("C27", "Todos los recaudos de dinero tienen asignado un recibo de caja con número consecutivo."),
        ("C28", "Los pagos con cheques que no son efectivos son reportados después de tres veces al área jurídica "
                "para que inicie su cobro, y las ventas son bloqueadas."),
        ("C29", "Se realiza diariamente la conciliación de los pagos y se identifican e investigan las "
                "diferencias de recaudo oportunamente."),
        ("C30", "Se realizan confirmaciones periódicas de los saldos de cuentas por cobrar con los clientes."),
        ("C31", "Las notas de crédito tienen control de consecutivo, son asociadas a una factura y son aprobadas "
                "de acuerdo al monto por un nivel superior."),
        ("C32", "Periódicamente se monitorean los saldos de notas de crédito por cliente, analizando "
                "comportamientos inusuales en su registro."),
    ],
    notas=["El reconocimiento de ingresos constituye un riesgo de fraude presunto conforme a la NIA 240.",
           "Los descuentos y devoluciones acumulados a julio de 2026 representan el 17,7% de las ventas brutas: "
           "el recorrido debe cubrir específicamente los controles de autorización de descuentos (C6, C7) y de "
           "notas de crédito (C31, C32).",
           "El riesgo M «Concentración de funciones entre ventas, contabilidad, inventario y/o tesorería» debe "
           "evaluarse antes de concluir sobre la confiabilidad de cualquier otro control del ciclo."],
)

# ------------------------------------------------- COMPRAS Y CUENTAS POR PAGAR
COMPRAS = dict(
    ref="J-01", ref_2024=None, confirmada=True, hoja="J-01 Compras y CxP",
    archivo="NAR_J-01_Compras_y_Cuentas_por_pagar",
    nombre="COMPRAS Y CUENTAS POR PAGAR", ciclo_cuenta="J — Cuentas por pagar  ·  F-2 — Costo de ventas",
    objetivo=("Garantizar el control eficiente, preciso y seguro de las materias primas desde su adquisición "
              "hasta su disposición final, asegurando su disponibilidad oportuna, minimizando pérdidas y "
              "cumpliendo con las políticas operativas, contables y fiscales de la organización."),
    entrada=["Facturas de compra.", "Órdenes de compra.",
             "Política contable para el manejo de materia prima.", "Kardex."],
    etapas=[("1) Área de producción / solicitante",
             "Identificación de la necesidad de materia prima, elaboración de la solicitud de compra, validación "
             "de disponibilidad presupuestaria y envío al área de compras."),
            ("2) Área de compras",
             "Recepción de la solicitud, solicitud de cotizaciones a proveedores registrados, evaluación técnica "
             "y económica de ofertas, selección del proveedor y generación de la orden de compra."),
            ("3) Bodega / recepción",
             "Recepción física de la materia prima, verificación contra la orden de compra y la guía de remisión, "
             "y registro de ingreso en el sistema de inventarios."),
            ("4) Finanzas / pago",
             "Recepción de la factura del proveedor, validación contra la orden de compra y el acta de recepción, "
             "aprobación del pago y ejecución por transferencia bancaria."),
            ("5) Contabilidad",
             "Registro contable de la compra con la cuenta adecuada, aplicación de retenciones tributarias, "
             "conciliación bancaria y archivo de comprobantes.")],
    salida=["Documentación soporte organizada (facturas, guías, ajustes, actas de toma física).",
            "Inventario actualizado para toma de decisiones y reabastecimiento.",
            "Ajustes de inventario autorizados y registrados contablemente.",
            "Alertas y acciones correctivas sobre desviaciones, mermas o riesgos.",
            "Reportes de rotación, cobertura, vencimiento y discrepancias."],
    sistemas=[("JIREH / ERP financiero — módulos de compras e inventarios",
               "Órdenes de compra, ingreso de mercadería y registro del pasivo.")],
    transacciones=[("2.1.2.01.", "Proveedores locales", "Rutinarias", "Integridad · Obligaciones"),
                   ("2.1.2.02.", "Proveedores del exterior", "Rutinarias", "Valuación · Obligaciones"),
                   ("5.1.1.", "Materia prima", "Rutinarias", "Exactitud · Valuación"),
                   ("5.1.7.", "Producción subcontratada y tercerizada", "No rutinarias",
                    "Ocurrencia · Presentación")],
    riesgos_negocio=[("1", "Dependencia de producción subcontratada con una entidad del mismo grupo económico "
                           "(cuenta 5.1.7.02 RUABLUCO).", "Presentación · Exactitud"),
                     ("2", "Deterioro de la liquidez y alargamiento del plazo de pago a proveedores.",
                      "Integridad · Valuación")],
    preguntas=[
        ("Políticas y procedimientos", [
            "¿Existe una política formal de compras aprobada por la alta dirección?",
            "¿La política establece criterios para selección de proveedores, límites de autorización y "
            "condiciones de pago?",
            "¿Se cuenta con un procedimiento documentado para la solicitud, evaluación, aprobación y ejecución "
            "de compras?",
            "¿Se revisan y actualizan periódicamente las políticas y procedimientos?"]),
        ("Planificación y presupuesto", [
            "¿Las compras de materias primas se realizan en función de un plan de producción o demanda "
            "proyectada?",
            "¿Existe un presupuesto anual o mensual para compras? ¿Se controla su ejecución?",
            "¿Se documentan las desviaciones entre lo presupuestado y lo ejecutado?",
            "¿Se coordinan las compras con el área de inventarios para evitar sobrestock o desabastecimiento?"]),
        ("Solicitud y autorización", [
            "¿Las solicitudes de compra se originan desde áreas autorizadas?",
            "¿Se utiliza un formato estandarizado para la solicitud de materias primas?",
            "¿Las órdenes de compra requieren aprobación según niveles jerárquicos definidos?",
            "¿Se verifica que la solicitud esté respaldada por necesidades reales de producción?"]),
        ("Selección y evaluación de proveedores", [
            "¿Se exige un mínimo de tres cotizaciones para compras relevantes?",
            "¿Se evalúan los proveedores en función de calidad, precio, plazo y cumplimiento?",
            "¿Se cuenta con un registro actualizado de proveedores aprobados?",
            "¿Se realiza seguimiento a proveedores críticos o estratégicos?"]),
        ("Recepción y control de materias primas", [
            "¿Se verifica la conformidad entre lo solicitado, lo recibido y lo facturado?",
            "¿Se documenta la recepción mediante actas, guías o registros de ingreso?",
            "¿Se realiza control de calidad sobre las materias primas recibidas?",
            "¿Se registran las devoluciones o no conformidades?"]),
        ("Facturación y pago", [
            "¿Las facturas se validan contra la orden de compra y el acta de recepción?",
            "¿Se aplican controles para evitar pagos duplicados o fuera de plazo?",
            "¿Los pagos se realizan conforme a las condiciones pactadas con el proveedor?",
            "¿Se documenta la autorización de pagos por parte de responsables financieros?"]),
        ("Seguridad y segregación de funciones", [
            "¿Las funciones de solicitud, aprobación, recepción y pago están segregadas?",
            "¿Se controla el acceso a los sistemas de compras y proveedores?",
            "¿Se auditan periódicamente los registros de compras y pagos?",
            "¿Existen controles para prevenir conflictos de interés o compras indebidas?"]),
        ("Indicadores y seguimiento", [
            "¿Se monitorean indicadores como cumplimiento de plazos, calidad recibida y eficiencia "
            "presupuestaria?",
            "¿Se generan reportes periódicos para la gerencia sobre el desempeño del proceso de compras?",
            "¿Se realiza seguimiento a observaciones de auditorías anteriores?",
            "¿Se aplican planes de mejora continua en el proceso?"]),
        ("Cumplimiento tributario (compras)", [
            "¿Se verifica la validez del comprobante de venta antes de registrar la compra?",
            "¿Se practican y registran las retenciones en la fuente y de IVA que corresponden a cada compra?",
            "¿Se concilian las compras registradas contra el ATS y los formularios presentados al SRI?",
            "¿Cómo se identifican y controlan los gastos no deducibles?"]),
    ],
    riesgos=[],
    controles=[],
    notas=["ADVERTENCIA DE REFERENCIA: las referencias CE-01 (tesorería), CA-01 (ventas y cuentas por cobrar) y "
           "CC-01 (nómina) constan expresamente en los papeles de la firma. La referencia CB-01 asignada a este "
           "papel es PROVISIONAL y debe ser confirmada por el auditor responsable.",
           "El papel de tesorería del ejercicio anterior documentó que la creación de proveedores se solicita "
           "desde el área de compras y se ejecuta en tesorería. Esa separación debe verificarse en el recorrido, "
           "junto con el control de modificación de la cuenta bancaria del proveedor.",
           "Los días de cuentas por pagar aumentaron de 39 a 71 entre diciembre de 2025 y julio de 2026: el "
           "recorrido debe cubrir la integridad del pasivo y la búsqueda de pasivos no registrados."],
)

# ------------------------------------------------------------------ PRODUCCIÓN
PRODUCCION = dict(
    ref="F-01", ref_2024=None, confirmada=True, hoja="F-01 Producción",
    archivo="NAR_F-01_Produccion",
    nombre="PRODUCCIÓN", ciclo_cuenta="F — Inventarios  ·  F-2 — Costo de producción",
    objetivo=("Garantizar la fabricación eficiente, estandarizada y con calidad controlada de pantalones tipo "
              "Jean, cumpliendo con los requerimientos de diseño, cantidad y tiempo establecidos por el área "
              "comercial, asegurando el uso óptimo de recursos, el cumplimiento de especificaciones técnicas y "
              "la satisfacción del cliente final."),
    entrada=["Tela denim (materia prima principal); hilo, botones, cierres, etiquetas y accesorios.",
             "Ficha técnica del modelo, orden de producción y programación de producción.",
             "Personal operativo (corte, confección, lavado, planchado, empaque).",
             "Maquinaria y equipos; parámetros de calidad y criterios de inspección.",
             "Registro de pedidos o demanda comercial; procedimientos operativos estandarizados."],
    etapas=[("1) Planificación / comercial",
             "Recepción del pedido comercial o proyección de demanda, generación de la orden de producción con "
             "especificaciones técnicas y validación de disponibilidad de materia prima y capacidad operativa."),
            ("2) Corte", "Recepción de tela y ficha técnica, trazado y corte según patrón, clasificación y "
                         "entrega de piezas cortadas a confección."),
            ("3) Confección", "Ensamble de piezas, control de calidad en proceso y registro de avances por lote."),
            ("4) Lavado y acabado", "Lavado industrial según diseño, planchado, revisión final, empaque "
                                    "individual y etiquetado."),
            ("5) Almacén / logística", "Registro de ingreso de producto terminado, actualización de inventario y "
                                       "preparación para despacho.")],
    salida=["Pantalones terminados y empacados; registro de producción por lote.",
            "Reportes de eficiencia y productividad; registro de defectos y reprocesos.",
            "Productos ingresados al inventario de producto terminado.",
            "Trazabilidad del lote desde producción hasta entrega.",
            "Documentación de control de calidad final e información para facturación y despacho."],
    sistemas=[("JIREH / ERP financiero — módulo de producción e inventarios",
               "Órdenes de producción, consumo de insumos y registro del producto terminado.")],
    transacciones=[("1.1.4.02.", "Bodega de productos en proceso", "Rutinarias", "Existencia · Valuación"),
                   ("5.1.1.", "Materia prima consumida", "Rutinarias", "Exactitud · Valuación"),
                   ("5.3.1. / 5.4.1.", "Costo de producción terminada y en proceso", "Rutinarias",
                    "Exactitud · Valuación")],
    riesgos_negocio=[("1", "Acumulación de inventario de lenta rotación: los días de inventario aumentaron de "
                           "245 a 393 entre diciembre de 2025 y julio de 2026.", "Valuación · Existencia"),
                     ("2", "Ausencia de medidas de seguridad industrial documentada en el ejercicio anterior.",
                      "Integridad")],
    preguntas=[
        ("Planificación y programación de producción", [
            "¿Se cuenta con un plan maestro de producción basado en pedidos, demanda o proyecciones comerciales?",
            "¿La programación de producción considera disponibilidad de materias primas, capacidad instalada y "
            "tiempos estándar?",
            "¿Se documentan las órdenes de producción con especificaciones técnicas del modelo?",
            "¿Se realiza seguimiento al cumplimiento del cronograma de producción?"]),
        ("Control de materias primas e insumos", [
            "¿Las materias primas se verifican contra especificaciones antes de ingresar a producción?",
            "¿Se realiza control de calidad sobre los lotes de tela y accesorios?",
            "¿Se documenta el consumo de insumos por lote o por orden de producción?",
            "¿Existen procedimientos para devolución o reclamo por insumos defectuosos?"]),
        ("Procesos técnicos de producción", [
            "¿Se encuentran definidos los procesos operativos: corte, confección, lavado, planchado y empaque?",
            "¿Cada etapa cuenta con instrucciones técnicas, tiempos estándar y responsables asignados?",
            "¿Se aplican controles de calidad en cada fase del proceso?",
            "¿Se documentan las incidencias o reprocesos durante la producción?"]),
        ("Control de calidad", [
            "¿Se realiza inspección final del producto antes del empaque?",
            "¿Existen criterios definidos para aceptación, rechazo o reproceso?",
            "¿Se lleva registro de defectos por tipo, frecuencia y responsable?",
            "¿Se realiza retroalimentación al personal sobre errores detectados?"]),
        ("Personal y seguridad industrial", [
            "¿El personal cuenta con capacitación técnica para el proceso productivo?",
            "¿Se aplican medidas de seguridad industrial en el uso de maquinaria y herramientas?",
            "¿Se realiza control de asistencia y productividad por operario?",
            "¿Se documentan accidentes o incidentes laborales en planta?"]),
        ("Almacenamiento y entrega", [
            "¿Los productos terminados se almacenan en condiciones adecuadas antes de su despacho?",
            "¿Se verifica la cantidad y calidad antes de entregar al área comercial o logística?",
            "¿Se documenta la trazabilidad del lote desde producción hasta entrega?",
            "¿Se realiza conciliación entre producción terminada y pedidos despachados?"]),
        ("Costeo del producto", [
            "¿Cómo se determina el costo unitario de cada orden de producción y quién lo revisa?",
            "¿Qué componentes se incorporan al costo (materia prima, mano de obra directa, costos indirectos) y "
            "cómo se distribuyen?",
            "¿Cómo se tratan las mermas normales y anormales del proceso?",
            "¿Cómo se valoran los productos en proceso al cierre de cada mes?"]),
        ("Indicadores y seguimiento", [
            "¿Se monitorean indicadores como eficiencia, productividad, tasa de defectos y cumplimiento de "
            "tiempos?",
            "¿Se generan reportes periódicos para la gerencia sobre el desempeño del proceso?",
            "¿Se realiza seguimiento a observaciones de auditorías internas o externas?",
            "¿Se aplican planes de mejora continua en el área de producción?"]),
    ],
    riesgos=[],
    controles=[],
    notas=["ADVERTENCIA DE REFERENCIA: la referencia CD-01 es PROVISIONAL y debe ser confirmada por el auditor "
           "responsable.",
           "El cuestionario del ejercicio anterior identificó como riesgo ALTO la ausencia de medidas de "
           "seguridad industrial y como riesgo MEDIO la falta de controles de calidad entre fases intermedias. "
           "Debe verificarse si esas condiciones persisten.",
           "El bloque de costeo del producto fue añadido al cuestionario de la firma porque el papel del "
           "ejercicio anterior no cubría la determinación del costo unitario, que es la aseveración de valuación "
           "crítica del ciclo de inventarios (Sección 13 de la NIIF para las PYMES)."],
)

# ------------------------------ RECEPCIÓN, ALMACENAMIENTO Y DESPACHO
BODEGA = dict(
    ref="F-02", ref_2024=None, confirmada=True, hoja="F-02 Recep. y despacho",
    archivo="NAR_F-02_Recepcion_almacenamiento_despacho",
    nombre="RECEPCIÓN, ALMACENAMIENTO Y DESPACHO", ciclo_cuenta="F — Inventarios",
    objetivo=("Garantizar el control eficiente, preciso y seguro de los bienes comercializables y no "
              "comercializables, desde su adquisición hasta su disposición final, asegurando su disponibilidad "
              "oportuna, minimizando pérdidas y cumpliendo con las políticas operativas, contables y fiscales de "
              "la organización."),
    entrada=["Producto terminado proveniente del área de producción.",
             "Guía de remisión interna o acta de entrega de producción; ficha técnica del producto terminado.",
             "Sistema de inventario físico y digital; solicitudes de despacho del área comercial o clientes.",
             "Personal operativo de bodega y logística; materiales de empaque y transporte.",
             "Procedimientos internos de recepción y despacho."],
    etapas=[("1) Producción / entrega",
             "Preparación del lote terminado, generación de la guía de remisión interna y entrega física al área "
             "de bodega."),
            ("2) Bodega / recepción y almacenamiento",
             "Recepción física, verificación contra la guía de remisión y la ficha técnica, registro de ingreso "
             "en el sistema de inventario, etiquetado y ubicación en estantería."),
            ("3) Comercial / logística",
             "Recepción de la solicitud de despacho, verificación de disponibilidad de stock, preparación del "
             "pedido (picking y embalaje) y generación de la guía de remisión externa."),
            ("4) Distribución / entrega",
             "Coordinación de transporte y ruta, entrega física al cliente o punto de distribución, firma de "
             "recepción y registro de salida en el sistema de inventario.")],
    salida=["Registro de ingreso al inventario de producto terminado y reportes de stock actualizado.",
            "Guías de remisión y documentos de despacho; productos entregados a clientes o distribuidores.",
            "Indicadores de rotación, precisión de entrega y cumplimiento de tiempos.",
            "Retroalimentación sobre devoluciones o rechazos; archivo documental de movimientos logísticos."],
    sistemas=[("JIREH / ERP financiero — módulo de inventarios",
               "Registro de ingresos, egresos y ajustes de inventario por bodega.")],
    transacciones=[("1.1.4.30.", "Bodega Lee — primeras", "Rutinarias", "Existencia · Valuación"),
                   ("1.1.4.12. / .13. / .14.", "Bodegas de terceros", "No rutinarias",
                    "Derechos y obligaciones"),
                   ("1.1.4.00.", "Provisión por valor neto de realización", "No rutinarias", "Valuación")],
    riesgos_negocio=[("1", "Ausencia de conciliación entre el inventario físico y el contable, documentada en "
                           "el ejercicio anterior.", "Existencia · Integridad"),
                     ("2", "Condiciones de almacenamiento inadecuadas (ventilación y separación de lotes).",
                      "Valuación")],
    preguntas=[
        ("Recepción de producto terminado", [
            "¿Se cuenta con un procedimiento documentado para la recepción de producto terminado desde "
            "producción?",
            "¿Se verifica la cantidad y calidad de los productos recibidos contra la orden de producción?",
            "¿Se realiza inspección visual o técnica antes de ingresar al almacén?",
            "¿Se documentan las novedades, defectos o diferencias detectadas en la recepción?",
            "¿Se genera un acta o registro de ingreso por lote?"]),
        ("Almacenamiento y control de inventario", [
            "¿Los productos se almacenan en condiciones adecuadas (limpieza, ventilación, seguridad)?",
            "¿Se aplica un sistema de codificación o etiquetado para facilitar la trazabilidad?",
            "¿Se realiza inventario físico y lógico de productos terminados?",
            "¿Se cuenta con un sistema automatizado o manual para registrar movimientos de inventario?",
            "¿Se aplican controles para evitar pérdidas, deterioro o robo de mercancía?"]),
        ("Preparación y despacho", [
            "¿Las solicitudes de despacho se originan desde el área comercial o clientes autorizados?",
            "¿Se verifica la disponibilidad de stock antes de preparar el pedido?",
            "¿Se documenta la preparación del despacho (picking, embalaje, guía de remisión)?",
            "¿Se realiza control de calidad final antes del envío?",
            "¿Se cuenta con un procedimiento para devoluciones o rechazos por parte del cliente?"]),
        ("Documentación y trazabilidad", [
            "¿Cada movimiento (ingreso, salida, ajuste) está respaldado por documentos verificables?",
            "¿Se conserva la trazabilidad del lote desde producción hasta entrega?",
            "¿Se archivan las guías de remisión, facturas y registros de entrega?",
            "¿Se realiza conciliación entre inventario físico y contable?",
            "¿Se cuenta con reportes periódicos de rotación, obsolescencia o quiebre de stock?"]),
        ("Inventarios de terceros y en tránsito", [
            "¿Cómo se identifican y controlan las bodegas de mercadería de terceros y la mercadería propia en "
            "poder de terceros?",
            "¿Qué documentación respalda la mercadería en consignación o maquila?",
            "¿Cómo se controlan las importaciones en tránsito y en qué momento se reconocen como inventario "
            "propio?"]),
        ("Indicadores y seguimiento", [
            "¿Se monitorean indicadores como tiempo de despacho, precisión en entregas y rotación de inventario?",
            "¿Se generan reportes para la gerencia sobre el desempeño logístico?",
            "¿Se realiza seguimiento a observaciones de auditorías internas o externas?",
            "¿Se aplican planes de mejora continua en el proceso de almacenamiento y distribución?"]),
    ],
    riesgos=[],
    controles=[],
    notas=["ADVERTENCIA DE REFERENCIA: la referencia CF-01 es PROVISIONAL y debe ser confirmada por el auditor "
           "responsable.",
           "El cuestionario del ejercicio anterior calificó como riesgo ALTO: condiciones de almacenamiento sin "
           "ventilación adecuada y sin separación entre lotes; ausencia de controles para evitar pérdidas, "
           "deterioro o robo; falta de conciliación entre inventario físico y contable; ausencia de reportes de "
           "desempeño logístico; y falta de seguimiento a observaciones de auditoría. Todas deben verificarse "
           "en 2026 y, de persistir, comunicarse conforme a la NIA 265.",
           "Los inventarios son el componente crítico del encargo (61,0% del activo). La ausencia de "
           "conciliación físico–contable es una deficiencia que afecta directamente la aseveración de "
           "existencia y condiciona el alcance de la toma física (NIA 501)."],
)

# --------------------------------------------------------------------- NÓMINA
NOMINA = dict(
    ref="K4-01", ref_2024="CC-01", confirmada=True, hoja="K4-01 Nómina",
    archivo="NAR_K4-01_Nomina",
    nombre="NÓMINA Y BENEFICIOS A EMPLEADOS", ciclo_cuenta="K-4 — Nómina y beneficios a empleados",
    objetivo=("Iniciar, procesar y registrar debidamente la compensación que se pague a los empleados y a las "
              "agencias reguladoras, para garantizar su integridad, existencia, exactitud y presentación y "
              "revelación en los estados financieros."),
    entrada=["Solicitud de recursos.", "Búsqueda y selección del candidato.",
             "Disponibilidad presupuestal.", "Contrato de trabajo y aviso de entrada al IESS.",
             "Registro de asistencia, novedades, horas extra y comisiones."],
    etapas=[("1) Vinculación", "Contratación, creación del colaborador en el sistema de nómina y aviso de "
                               "entrada al IESS."),
            ("2) Administración de colaboradores", "Registro de novedades, asistencia, horas extra, anticipos y "
                                                   "modificaciones salariales."),
            ("3) Liquidación de la nómina", "Cálculo del rol de pagos, deducciones, aportes y retenciones."),
            ("4) Pago", "Generación del archivo de pago, aprobación y ejecución de la transferencia."),
            ("5) Registro y contabilización", "Registro contable del rol, de las provisiones y de los pasivos "
                                              "laborales; conciliación con planillas del IESS."),
            ("6) Ajustes y cierre", "Ajustes posteriores, provisiones de beneficios sociales, jubilación "
                                    "patronal y desahucio."),
            ("7) Documentación", "Archivo y respaldo de la documentación soporte del proceso.")],
    salida=["Rol de pagos aprobado y comprobantes de pago.",
            "Planillas del IESS presentadas y pagadas.",
            "Registro contable de gastos de personal, provisiones y pasivos laborales.",
            "Formulario 103 con las retenciones en relación de dependencia."],
    sistemas=[("JIREH / ERP financiero — módulo de nómina",
               "Datos maestros de colaboradores, liquidación del rol y registro contable."),
              ("Portal del IESS", "Generación y pago de planillas de aportes."),
              ("Portal del SRI", "Presentación del formulario 103 de retenciones.")],
    transacciones=[("2.1.5.", "Obligaciones laborales", "Rutinarias", "Valuación"),
                   ("2.1.4.", "Obligaciones con el IESS", "Rutinarias", "Integridad · Valuación"),
                   ("2.3.1. / 2.3.2.", "Provisión de jubilación patronal e indemnización laboral",
                    "No rutinarias", "Valuación · Presentación")],
    riesgos_negocio=[("1", "Incumplimiento con lo establecido por el Ministerio del Trabajo.",
                      "Existencia · Exactitud"),
                     ("2", "Omisión de los beneficios laborales.", "Valuación · Presentación"),
                     ("3", "Incumplimiento de las obligaciones con el IESS.", "Integridad · Valuación")],
    preguntas=[
        ("Vinculación y datos maestros", [
            "¿Cómo se autoriza la contratación de un colaborador y quién aprueba el cargo y la remuneración?",
            "¿Quién ingresa al colaborador en el sistema de nómina y quién verifica que los datos correspondan "
            "al contrato aprobado?",
            "¿Quién puede modificar sueldos y datos maestros de nómina y quién revisa el reporte de cambios?",
            "¿Cómo se registra el aviso de entrada y de salida en el IESS?"]),
        ("Administración de novedades", [
            "¿Cómo se controla la asistencia y cómo se autorizan y validan las horas extra, permisos y "
            "ausencias?",
            "¿Cómo se calculan las comisiones, bonos y remuneración variable y quién valida la base de cálculo?",
            "¿Cómo se autorizan y registran los anticipos a colaboradores?",
            "¿Cómo se descuentan las faltas injustificadas?"]),
        ("Liquidación y pago", [
            "¿Quién elabora el rol de pagos y quién lo revisa y aprueba antes de ejecutar el pago?",
            "¿Se compara el archivo de pago contra el rol aprobado antes de liberar la transferencia?",
            "¿Quién autoriza la liberación de la transferencia de la nómina?",
            "¿Existen comprobantes manuales de nómina y cómo se autorizan?"]),
        ("Beneficios sociales y provisiones", [
            "¿Cómo se calculan y registran la décima tercera y décima cuarta remuneración, las vacaciones y los "
            "fondos de reserva?",
            "¿Cómo se determina la provisión de jubilación patronal y desahucio? ¿Quién contrata al actuario y "
            "quién revisa las hipótesis del informe?",
            "¿Cómo se determina la participación de trabajadores en utilidades?"]),
        ("Registro contable y conciliaciones", [
            "¿Cómo y con qué frecuencia se concilia el rol de pagos contra el mayor contable y contra las "
            "planillas del IESS?",
            "¿Se realizan verificaciones que validen la exactitud de las tasas y deducciones aplicadas en la "
            "nómina?",
            "¿Cómo se hace seguimiento a las modificaciones de la legislación laboral para actualizarlas en el "
            "sistema?",
            "¿Quién tiene accesos al aplicativo de nómina y cómo se controlan?"]),
        ("Cumplimiento tributario", [
            "¿Cómo se calcula la retención del impuesto a la renta en relación de dependencia y quién revisa la "
            "proyección de gastos personales?",
            "¿Cómo se controla la contratación de servicios profesionales (honorarios) frente a la relación de "
            "dependencia?"]),
        ("Salida de colaboradores", [
            "¿Cómo se autoriza y liquida la salida de un colaborador y cuándo se lo retira de la nómina?",
            "¿Quién revisa y aprueba el acta de finiquito?"]),
    ],
    riesgos=[
        ("VINCULACIÓN", [
            ("A", "Incremento de los colaboradores temporales."),
            ("NR1", "Incremento de colaboradores con discapacidad."),
        ]),
        ("ADMINISTRACIÓN DE COLABORADORES", [
            ("B", "Horas reportadas como laboradas que no corresponden con las horas trabajadas de los "
                  "colaboradores."),
            ("C", "Se generan anticipos sin tener un nivel de aprobación y no son registrados oportunamente."),
            ("D", "Se registran pagos que no corresponden a la nómina y que no tienen documentación soporte."),
            ("E", "Se realizan pagos a trabajadores no autorizados o no laborados."),
            ("F", "Giros a cuentas bancarias que no corresponden con las autorizadas por los colaboradores."),
            ("G", "Incumplimiento en los pagos de nómina por errores en la liquidación y/o falta de oportunidad "
                  "en la entrega de novedades."),
            ("H", "Las horas extras no tienen un nivel de autorización."),
            ("I", "Fallas en el software y los aplicativos que se utilizan para la liquidación de la nómina."),
            ("J", "Pagos de nómina sin las deducciones de seguridad social correspondientes."),
            ("K", "Pagos a colaboradores por días no trabajados o actividades no realizadas."),
            ("L", "Modificaciones a la asignación salarial inicialmente pactada, sin autorización."),
            ("M", "Colaboradores sin aumento de salario, o con más de dos aumentos dentro de un año."),
            ("N", "Generación de comprobantes manuales de nómina."),
            ("NR2", "Faltas injustificadas no descontadas de los ingresos del trabajador."),
        ]),
        ("REGISTRO Y CONTABILIZACIÓN", [
            ("O", "No se realizan verificaciones que permitan validar la exactitud de las tasas y deducciones "
                  "que se aplican en la nómina, generando mayores o menores deducciones."),
            ("P", "No se hace seguimiento a las modificaciones de la legislación local en cuanto a deducciones "
                  "para ser registradas en el sistema."),
            ("Q", "Se lleva una doble contabilidad en el registro de los pagos de nómina."),
            ("R", "La contabilización de los pagos de nómina difiere del valor realmente pagado."),
            ("S", "Anticipos a trabajadores no registrados o no autorizados por el nivel que corresponde."),
            ("T", "Accesos no autorizados al aplicativo de nómina."),
            ("U", "Las cuentas y registros de nómina son modificados por personal no autorizado."),
            ("V", "No se tiene la información completa de nómina para el cierre de los estados financieros."),
            ("W", "No se cuenta con un procedimiento efectivo para el registro de horas extras, bonificaciones y "
                  "comisiones."),
            ("X", "El presupuesto de nómina no corresponde con los valores pagados."),
            ("Y", "No se tienen controles de monitoreo por parte del responsable de gestión humana para "
                  "verificar la exactitud, completitud e integridad de la nómina."),
            ("NR3", "Los valores que se mantienen en libros varían respecto de los registrados en los entes de "
                    "control por notas de crédito no recurrentes."),
        ]),
        ("AJUSTES EN LA NÓMINA", [
            ("Z", "Los ajustes realizados a pagos de empleados no tienen niveles de autorización de acuerdo al "
                  "monto."),
            ("AA", "Se ingresan deducciones y/o novedades después del cierre de la nómina, realizando "
                   "modificaciones en las fechas de registro."),
            ("AB", "Deficiencias en el proceso de nómina dada la ausencia de indicadores de gestión en las "
                   "operaciones."),
            ("AC", "Los cambios hechos en la configuración de los parámetros no son autorizados por el encargado "
                   "y no cumplen con las políticas y procedimientos."),
            ("NR4", "Se registran ajustes a los saldos de nómina por notas de crédito emitidas por entes de "
                    "control."),
        ]),
        ("DOCUMENTACIÓN", [
            ("AD", "Pérdida de la documentación soporte de las operaciones registradas contablemente."),
            ("NR5", "La documentación se respalda física y digitalmente."),
        ]),
        ("PROVISIONES DE LARGO PLAZO", [
            ("NR6", "El informe actuarial de jubilación patronal y desahucio no está vigente, o sus hipótesis "
                    "(tasa de descuento, rotación, mortalidad e incrementos salariales) no son razonables."),
            ("NR7", "El activo por impuestos diferidos originado en las provisiones laborales no es recuperable "
                    "considerando la pérdida acumulada del período."),
        ]),
    ],
    controles=[],
    notas=["Las provisiones laborales de largo plazo suman USD 1.385.433,34 al 31 de julio de 2026, equivalentes "
           "a 6,06 veces la materialidad global. Son el área de mayor riesgo del ciclo.",
           "Los riesgos NR6 y NR7 fueron añadidos al banco de la firma porque el papel del ejercicio anterior no "
           "cubría el informe actuarial ni la recuperabilidad del impuesto diferido, y ambos son significativos "
           "en este encargo conforme a las Secciones 28 y 29 de la NIIF para las PYMES.",
           "El riesgo E «pagos a trabajadores no autorizados o no laborados» corresponde al riesgo de empleados "
           "inexistentes y debe responderse con la conciliación de la nómina contra el listado de afiliados "
           "activos del IESS."],
)

# ----------------------------------------------------------------------- TICS
TICS = dict(
    ref="TIC-01", ref_2024=None, confirmada=False, hoja="TIC-01 TICs",
    archivo="NAR_TIC-01_Tecnologias_informacion",
    nombre="TECNOLOGÍAS DE LA INFORMACIÓN (CONTROLES GENERALES)",
    ciclo_cuenta="Transversal a todos los ciclos",
    objetivo=("Evaluar el grado de conocimiento, control interno y cumplimiento normativo de la gestión "
              "tecnológica, con el fin de identificar riesgos que afecten la confiabilidad de la información "
              "financiera generada por los sistemas."),
    entrada=["Plan estratégico de la empresa, objetivos del negocio y presupuesto asignado.",
             "Infraestructura (hardware, software, redes), licencias y proveedores de TI.",
             "Evaluaciones de seguridad, auditorías previas y análisis de vulnerabilidades.",
             "Personal técnico, competencias y estructura del área de sistemas.",
             "Indicadores tecnológicos, métricas de disponibilidad y tiempos de respuesta."],
    etapas=[("1) Gobierno de TI y organización", "Políticas, roles, responsabilidades y evaluación del área."),
            ("2) Seguridad de la información", "Gestión de accesos, contraseñas, cifrado y respuesta a "
                                               "incidentes."),
            ("3) Gestión de infraestructura y equipos", "Servidores, ambientes seguros e inventario de activos "
                                                        "tecnológicos."),
            ("4) Gestión de software y acceso a aplicaciones", "Actualizaciones, licencias, control de cambios y "
                                                               "pruebas."),
            ("5) Respaldo, recuperación y continuidad", "Respaldos, plan de recuperación y continuidad "
                                                        "operativa."),
            ("6) Soporte técnico y atención de incidentes", "Tiempos de respuesta, documentación y análisis de "
                                                            "causa raíz."),
            ("7) Riesgos tecnológicos y auditoría", "Evaluación de riesgos, controles frente a amenazas y "
                                                    "seguimiento de hallazgos.")],
    salida=["Sistemas implementados, actualizaciones, integraciones y automatizaciones.",
            "Manuales, políticas de seguridad, procedimientos operativos e informes de gestión.",
            "Accesos restringidos, respaldos, monitoreo y planes de recuperación.",
            "Personal entrenado, usuarios atendidos y documentación de incidentes resueltos."],
    sistemas=[("JIREH INFORMATION — ERP local",
               "Sistema contable y operativo de la Compañía, con modificaciones sobre sus bases de datos.")],
    transacciones=[("—", "Controles generales de TI que soportan la integridad de todos los ciclos",
                    "Transversal", "Integridad · Exactitud")],
    riesgos_negocio=[("1", "El ERP JIREH opera con bases de datos adquiridas hace más de 18 años y con "
                           "modificaciones, sin documentación de control de versiones.",
                      "Integridad · Exactitud"),
                     ("2", "Ausencia de manual de políticas y procedimientos del área de tecnología.",
                      "Integridad")],
    preguntas=[
        ("Gobierno de TI y organización", [
            "¿Existe un manual de políticas y procedimientos tecnológicos aprobado por la alta dirección?",
            "¿El área de sistemas tiene definidos sus roles, responsabilidades y niveles de autoridad?",
            "¿Se realiza evaluación periódica del desempeño del área de TI?",
            "¿La empresa cuenta con un comité de tecnología o participa en decisiones estratégicas de TI?"]),
        ("Seguridad de la información", [
            "¿Qué políticas de seguridad de la información están actualmente implementadas?",
            "¿Cómo se gestionan los accesos a los sistemas críticos? ¿Se aplican controles de acceso basados en "
            "roles?",
            "¿Qué mecanismos existen para detectar y responder a incidentes de seguridad?",
            "¿Se aplican políticas de contraseñas seguras (complejidad, caducidad, bloqueo por intentos)?",
            "¿Se realiza cifrado de información sensible en tránsito y en reposo?",
            "¿Las redes cuentan con bloqueos para determinadas páginas?"]),
        ("Gestión de infraestructura y equipos", [
            "¿Los servidores están alojados en ambientes seguros (control de temperatura, acceso restringido)?",
            "¿Se realiza inventario físico y lógico de los activos tecnológicos?"]),
        ("Gestión de software y acceso a aplicaciones", [
            "¿Los sistemas utilizados están actualizados y libres de vulnerabilidades conocidas?",
            "¿Se cuenta con licencias válidas para todo el software instalado?",
            "¿Se documentan los cambios realizados en sistemas (control de versiones)?",
            "¿Se realizan pruebas de funcionalidad antes de liberar nuevas versiones?",
            "¿Quién puede modificar directamente las bases de datos del ERP y cómo se controla?"]),
        ("Respaldo, recuperación y continuidad", [
            "¿Existe un plan formal de recuperación ante desastres (DRP)?",
            "¿Se han realizado simulacros de restauración de información?",
            "¿Los respaldos se almacenan en ubicaciones distintas al centro de operaciones?",
            "¿Se cuenta con un plan de continuidad operativa en caso de falla tecnológica?",
            "¿Con qué frecuencia se realizan respaldos de la información crítica?"]),
        ("Datos personales y terceros", [
            "¿Qué controles existen para evitar accesos no autorizados a los datos en la nube?",
            "¿Se cuenta con acuerdos de nivel de servicio (SLA) y cláusulas de confidencialidad con los "
            "proveedores?",
            "¿Se han clasificado los datos según su nivel de sensibilidad?",
            "¿Se aplican controles para evitar fuga de información (DLP, monitoreo)?",
            "¿Se cuenta con consentimiento para el tratamiento de datos personales?",
            "¿Se han reportado incidentes de seguridad o brechas de datos en el último año?"]),
        ("Soporte técnico y atención de incidentes", [
            "¿Se mide el tiempo de respuesta y solución de problemas tecnológicos?",
            "¿Se documentan los incidentes críticos y se realiza análisis de causa raíz?",
            "¿Se capacita al personal en buenas prácticas de uso de tecnología?"]),
        ("Riesgos tecnológicos y auditoría", [
            "¿Se ha realizado una evaluación de riesgos tecnológicos en los últimos 12 meses?",
            "¿Se cuenta con controles para mitigar riesgos como ransomware, phishing o malware?",
            "¿Se han recibido observaciones de auditorías anteriores relacionadas con TI?",
            "¿Se realiza seguimiento a planes de acción derivados de hallazgos tecnológicos?"]),
    ],
    riesgos=[],
    controles=[],
    notas=["ADVERTENCIA DE REFERENCIA: la referencia CG-01 es PROVISIONAL y debe ser confirmada por el auditor "
           "responsable.",
           "El cuestionario del ejercicio anterior calificó como riesgo ALTO, entre otros: ausencia de manual de "
           "políticas y procedimientos de TI; ausencia de doble factor de autenticación; ausencia de bloqueo por "
           "contraseñas en todas las máquinas; ERP con bases de datos de más de 18 años y con modificaciones; "
           "ausencia de bloqueos de red; falta de pruebas de accesos a redes o aplicaciones maliciosas; y "
           "ausencia de auditoría al área de TI. Todas deben verificarse en 2026.",
           "Los controles generales de TI condicionan la confiabilidad de todos los controles automatizados de "
           "los demás ciclos. Si estos controles generales no son efectivos, no puede depositarse confianza en "
           "ningún control dependiente del sistema."],
)

PROCESOS = [TESORERIA, VENTAS, COMPRAS, PRODUCCION, BODEGA, NOMINA, TICS]


# ------------------------------------------- PROPIEDAD, PLANTA Y EQUIPO
PPE = dict(
    ref="H-01", ref_2024=None, confirmada=True, hoja="H-01 Prop. planta y equipo",
    archivo="NAR_H-01_Propiedad_planta_equipo",
    nombre="PROPIEDAD, PLANTA Y EQUIPO",
    ciclo_cuenta="H — Activo fijo  (1.2.1 terrenos · 1.2.2 PPE · 1.2.3 depreciación acumulada · "
                 "1.2.8 intangibles · 1.4.1 derecho de uso)",
    objetivo=("Asegurar el control integral, eficiente y normativamente adecuado de los activos fijos de la "
              "entidad, desde su adquisición hasta su baja, garantizando su correcta identificación, registro "
              "contable, uso operativo, mantenimiento, depreciación y disposición final, en cumplimiento de las "
              "políticas internas, de la Sección 17 de la NIIF para las PYMES y de la legislación tributaria "
              "vigente."),
    entrada=["Orden de compra o contrato de adquisición del activo y factura del proveedor con datos válidos.",
             "Autorización de inversión por parte de la gerencia o del comité financiero.",
             "Clasificación contable del activo (tipo, cuenta, centro de costo) y datos técnicos "
             "(marca, modelo, serie, ubicación).",
             "Política contable de la entidad: vida útil, método de depreciación y umbral de capitalización.",
             "Acta de recepción física y funcional del activo; información sobre seguros, garantías y "
             "mantenimiento.",
             "Normativa contable aplicable (Sección 17 de la NIIF para las PYMES) y normativa tributaria vigente."],
    etapas=[("1) Área solicitante / operativa",
             "Identificación de la necesidad de adquisición o mejora, elaboración de la solicitud con "
             "especificaciones técnicas y validación de que el bien cumple los criterios de reconocimiento como "
             "PPE (uso superior a un año y costo igual o mayor al umbral de capitalización)."),
            ("2) Gerencia / aprobación",
             "Revisión técnica y presupuestaria de la solicitud, autorización de la adquisición o mejora y "
             "definición de condiciones de pago y proveedor autorizado."),
            ("3) Administración / compras",
             "Generación de la orden de compra o contrato, recepción del bien y verificación contra la factura, "
             "revisión de la documentación soporte y envío al área contable."),
            ("4) Contabilidad — reconocimiento",
             "Evaluación del cumplimiento de los criterios de reconocimiento, registro del activo, "
             "determinación de vida útil, valor residual y método de depreciación, e inclusión de los costos "
             "atribuibles (transporte, instalación, desmantelamiento)."),
            ("5) Contabilidad — medición posterior",
             "Registro de la depreciación, revisión anual de vida útil y valor residual, evaluación de indicios "
             "de deterioro y registro de costos posteriores como activo o como gasto."),
            ("6) Custodia y control físico",
             "Codificación y etiquetado, asignación de responsable y ubicación, levantamiento físico periódico y "
             "conciliación con el registro contable."),
            ("7) Bajas y disposiciones",
             "Identificación de activos obsoletos o inservibles, autorización de la baja, retiro del registro, "
             "determinación del resultado de la disposición y archivo del acta.")],
    salida=["Activo registrado contable y patrimonialmente, con ficha técnica que indica ubicación, responsable "
            "y estado.",
            "Depreciación mensual registrada en el sistema contable.",
            "Documentación soporte archivada (factura, contrato, acta de recepción).",
            "Provisión por deterioro, obsolescencia o baja, cuando corresponda.",
            "Inventario físico actualizado y conciliado con la contabilidad.",
            "Notas explicativas para los estados financieros y alertas sobre activos en mal estado o sin uso."],
    sistemas=[("JIREH / ERP financiero — módulo de activos fijos",
               "Registro del activo, cálculo y contabilización de la depreciación y control de la ficha "
               "técnica."),
              ("Archivo extracontable en hoja de cálculo",
               "Comparación del cálculo de depreciación del módulo del sistema; según el papel del ejercicio "
               "anterior, no detalla la proporción de gasto no deducible.")],
    transacciones=[("1.2.2.", "Propiedades, planta y equipo (USD 1.250.061,62 al 31-jul-2026)", "Rutinarias",
                    "Existencia · Propiedad · Valuación"),
                   ("1.2.3.", "Depreciación acumulada (USD −677.322,03 al 31-jul-2026)", "Rutinarias",
                    "Exactitud · Valuación"),
                   ("1.2.1.", "Terrenos (USD 48.553,34, sin movimiento en el período)", "No rutinarias",
                    "Propiedad · Valuación"),
                   ("1.2.8.", "Activo intangible (USD 6.042,48)", "No rutinarias", "Valuación · Presentación"),
                   ("1.4.1. / 1.4.2.", "Derecho de uso por concesión y su amortización acumulada",
                    "No rutinarias", "Valuación · Presentación"),
                   ("5.1.4.06. / 6.1.1.12. / 6.1.2.12.",
                    "Gasto de depreciación del período (USD 64.578,53 en siete meses)", "Rutinarias",
                    "Exactitud · Clasificación")],
    riesgos_negocio=[("1", "Activos fijos y bienes de control no codificados en su totalidad, según el "
                           "cuestionario del ejercicio anterior.", "Existencia · Integridad"),
                     ("2", "Ausencia de registro de movimientos de activos fijos: la información se extrae de "
                           "mayores, según el cuestionario del ejercicio anterior.", "Existencia · Propiedad"),
                     ("3", "Activos sin revalorización desde 2011 y política contable pendiente de actualizar a "
                           "la NIIF para las PYMES.", "Valuación · Presentación"),
                     ("4", "Coexistencia de varias vidas útiles para una misma clase de activo.",
                      "Exactitud · Valuación")],
    preguntas=[
        ("Políticas y procedimientos", [
            "¿Se han establecido procedimientos y políticas claras para la gestión de activos fijos?",
            "¿Se han comunicado esos procedimientos y políticas a todo el personal involucrado en la gestión de "
            "activos fijos?",
            "¿Se revisan y actualizan periódicamente los procedimientos y políticas para asegurar que sean "
            "efectivos y relevantes?",
            "¿La política establece períodos o plazos para la toma física o el levantamiento de información?",
            "¿Se realizan evaluaciones periódicas para asegurar que se cumplan los procedimientos y políticas?",
            "¿La política contable está alineada con la Sección 17 de la NIIF para las PYMES o continúa "
            "referenciando la NIC 16?"]),
        ("Reconocimiento y capitalización", [
            "¿Se registran todos los activos fijos adquiridos en un registro detallado?",
            "¿Se clasifican los activos fijos según su naturaleza (terrenos, edificios, maquinaria, equipo)?",
            "¿Se ha establecido un umbral de capitalización y cómo se aplica a cada clase de activo?",
            "¿Cómo se verifican las facturas y documentos de compra para asegurar que los activos estén "
            "correctamente registrados?",
            "¿Qué componentes se incorporan al costo del activo (precio, transporte, instalación, aranceles, "
            "desmantelamiento) y quién los determina?",
            "¿Cómo se decide si un desembolso posterior se capitaliza como mejora o se reconoce como gasto de "
            "mantenimiento?",
            "¿Se han capitalizado costos por préstamos y, de ser así, con qué criterio?",
            "¿Se tienen codificados todos los activos fijos que ingresan al sistema contable?"]),
        ("Medición posterior — depreciación", [
            "¿Se tiene un cálculo estandarizado de la depreciación y qué método se aplica?",
            "¿Cómo se determinan la vida útil y el valor residual de cada clase de activo, y quién los aprueba?",
            "¿Se revisan anualmente la vida útil, el valor residual y el método de depreciación?",
            "¿Existen varias vidas útiles asignadas a una misma clase de activo? ¿Cómo se justifica?",
            "¿Se verifica que las depreciaciones estén correctamente registradas y en qué cuenta de costo o "
            "gasto se asignan?",
            "¿Cómo se controla el inicio de la depreciación (fecha de disponibilidad para el uso) y su cese?",
            "¿Cómo se tratan los activos totalmente depreciados que continúan en uso?"]),
        ("Modelo de medición y revalorización", [
            "¿Qué modelo de medición posterior aplica la entidad: costo o revaluación?",
            "¿Se lleva un registro de los activos fijos revalorizados con sus respectivos sustentos "
            "documentales?",
            "Si existen revaluaciones anteriores, ¿cómo se tratan el superávit y su depreciación?",
            "¿Quién realiza las valuaciones y cómo se evalúa la competencia y objetividad del valuador?"]),
        ("Deterioro del valor", [
            "¿Se evalúan al cierre de cada período los indicios de deterioro del valor de los activos "
            "(Sección 27 de la NIIF para las PYMES)?",
            "¿Existen activos ociosos, en mal estado o retirados del uso, y cómo se miden?",
            "¿Se ha considerado la pérdida acumulada del período como indicio de deterioro?",
            "¿Quién calcula y quién aprueba una pérdida por deterioro y cómo se reversa?"]),
        ("Arrendamientos y derecho de uso", [
            "¿Qué contratos de arrendamiento mantiene la entidad y cómo se clasifican conforme a la Sección 20 "
            "de la NIIF para las PYMES?",
            "¿Cómo se determinó el derecho de uso por concesión registrado en la cuenta 1.4.1 y su "
            "amortización?",
            "¿Cómo se concilia el pasivo por arrendamientos de la cuenta 2.2.4 con los contratos vigentes y con "
            "el gasto de arrendamiento operativo?"]),
        ("Bajas y disposiciones", [
            "¿Se han establecido procedimientos para dar de baja activos fijos que ya no sean necesarios o que "
            "estén en mal estado?",
            "¿Se verifican los registros de activos fijos para asegurar que estén actualizados y sean precisos?",
            "¿Se registra la baja de activos fijos en un registro detallado?",
            "¿Cuál es el tratamiento de los activos totalmente depreciados dados de baja y pendientes de venta, "
            "donación o chatarrización?",
            "¿Se cuenta con las actas o informes de las bajas de activos fijos?",
            "¿Se evalúa el impacto financiero de la baja de activos fijos en los estados financieros?",
            "¿Quién autoriza la venta o disposición de un activo y cómo se determina el resultado de la "
            "operación?"]),
        ("Control físico, custodia y seguros", [
            "¿Se limita el acceso a los activos fijos y al módulo del sistema solo al personal autorizado?",
            "¿Se lleva un registro de los accesos y de los movimientos de activos fijos entre ubicaciones y "
            "responsables?",
            "¿Se realizan levantamientos físicos de activos fijos de acuerdo con la política contable?",
            "¿Cómo se investigan y aprueban las diferencias entre el inventario físico y el registro contable?",
            "¿Los activos se encuentran asegurados y las pólizas cubren su valor y los riesgos relevantes?",
            "¿Existen activos entregados en garantía, prendados o con restricciones de propiedad?",
            "¿Se conserva la documentación que acredita la titularidad de los activos (títulos, matrículas, "
            "escrituras)?"]),
        ("Cumplimiento tributario", [
            "¿Cómo se determina la depreciación deducible y cómo se identifica la porción no deducible?",
            "¿Se conserva el detalle de la proporción de gasto no deducible por cada clase de activo?",
            "¿Cómo se tratan las diferencias entre la depreciación contable y la tributaria en la conciliación "
            "tributaria y en el impuesto diferido (Sección 29)?",
            "¿Cómo se soportan tributariamente las bajas de activos (actas, denuncias, chatarrización)?"]),
    ],
    riesgos=[
        ("SOLICITUD Y AUTORIZACIÓN DE LA ADQUISICIÓN", [
            ("HA", "Adquisición de activos sin autorización del nivel facultado o sin disponibilidad "
                   "presupuestaria."),
            ("HB", "Bienes que no cumplen los criterios de reconocimiento como PPE se capitalizan, o bienes que "
                   "sí los cumplen se registran como gasto."),
        ]),
        ("RECONOCIMIENTO Y MEDICIÓN INICIAL", [
            ("HC", "El costo del activo se registra incompleto por omisión de costos atribuibles (transporte, "
                   "instalación, aranceles) o inflado por inclusión de costos no capitalizables."),
            ("HD", "Los desembolsos posteriores de mantenimiento se capitalizan como mejoras, sobrevalorando el "
                   "activo y subvalorando el gasto."),
            ("HE", "Activos adquiridos y no registrados, o registrados en un período distinto al de su "
                   "disponibilidad para el uso."),
            ("HF", "Activos fijos y bienes de control sin codificación individual, lo que impide su "
                   "identificación y su verificación física."),
        ]),
        ("MEDICIÓN POSTERIOR — DEPRECIACIÓN", [
            ("HG", "Vidas útiles o valores residuales inadecuados, o distintos para una misma clase de activo "
                   "sin justificación técnica."),
            ("HH", "Errores en el cálculo de la depreciación, o depreciación no registrada, registrada dos "
                   "veces o asignada a una cuenta de costo o gasto incorrecta."),
            ("HI", "Vida útil, valor residual y método de depreciación no revisados anualmente."),
            ("HJ", "Activos totalmente depreciados que continúan en uso sin reevaluación de su vida útil "
                   "remanente."),
        ]),
        ("REVALORIZACIÓN Y DETERIORO", [
            ("HK", "Activos medidos a valores desactualizados: sin revalorización desde 2011 y con política "
                   "contable pendiente de actualizar al marco vigente."),
            ("HL", "Indicios de deterioro no evaluados al cierre, pese a la pérdida acumulada del período "
                   "(Sección 27)."),
            ("HM", "Activos ociosos, obsoletos o en mal estado mantenidos a su valor en libros."),
        ]),
        ("CUSTODIA Y CONTROL FÍSICO", [
            ("HN", "Activos registrados que no existen físicamente, o activos existentes no registrados."),
            ("HO", "Ausencia de registro de movimientos de activos entre ubicaciones y responsables, lo que "
                   "impide establecer la custodia."),
            ("HP", "Activos sin cobertura de seguro suficiente, o activos prendados o entregados en garantía no "
                   "revelados."),
            ("HQ", "Falta de conciliación entre el levantamiento físico y el registro contable, o diferencias no "
                   "investigadas ni aprobadas."),
            ("HR", "Documentación de titularidad inexistente o a nombre de terceros."),
        ]),
        ("BAJAS Y DISPOSICIONES", [
            ("HS", "Bajas o ventas de activos sin autorización del nivel facultado o sin acta que las sustente."),
            ("HT", "Activos dados de baja en el sistema pero físicamente existentes y aún en uso, o viceversa."),
            ("HU", "Resultado de la disposición mal determinado por no retirar simultáneamente el costo y la "
                   "depreciación acumulada."),
            ("HV", "Bajas registradas cerca del cierre para ajustar resultados (indicio de fraude — NIA 240)."),
        ]),
        ("ARRENDAMIENTOS Y DERECHO DE USO", [
            ("HW", "Contratos de arrendamiento mal clasificados conforme a la Sección 20, con efecto en el "
                   "activo, el pasivo y el gasto."),
            ("HX", "El derecho de uso por concesión y su amortización no se corresponden con las condiciones y "
                   "el plazo del contrato."),
        ]),
        ("CUMPLIMIENTO TRIBUTARIO", [
            ("HY", "Depreciación deducible determinada sin sustento, o porción no deducible no identificada por "
                   "clase de activo."),
            ("HZ", "Diferencias entre la depreciación contable y la tributaria no reconocidas como impuesto "
                   "diferido (Sección 29)."),
        ]),
    ],
    controles=[
        ("H1", "Toda adquisición de activo fijo nace de una solicitud con especificaciones técnicas, aprobada "
               "por el nivel facultado y con validación de disponibilidad presupuestaria."),
        ("H2", "El área contable evalúa, antes del registro, si el bien cumple los criterios de reconocimiento "
               "como propiedad, planta y equipo y el umbral de capitalización definido en la política."),
        ("H3", "El costo del activo se conforma con la factura y con los documentos de los costos atribuibles, y "
               "es revisado por una persona distinta de quien lo registra."),
        ("H4", "Existe una matriz aprobada de vidas útiles y valores residuales por clase de activo, y el "
               "sistema no permite asignar valores fuera de esa matriz sin autorización."),
        ("H5", "La depreciación se calcula automáticamente en el módulo de activos fijos y se concilia "
               "mensualmente contra el mayor contable."),
        ("H6", "El cálculo de la depreciación del módulo se compara con un recálculo independiente, con "
               "identificación de la porción no deducible por clase de activo."),
        ("H7", "Cada activo recibe un código individual y una etiqueta física al momento de su ingreso, y el "
               "código consta en la ficha técnica y en el registro contable."),
        ("H8", "Toda transferencia de activo entre ubicaciones o responsables se documenta en un acta de "
               "movimiento autorizada, y el registro de activos se actualiza."),
        ("H9", "Se realiza un levantamiento físico de activos fijos con la periodicidad definida en la política, "
               "ejecutado por personal independiente de su custodia."),
        ("H10", "Las diferencias del levantamiento físico se investigan, se documentan y su ajuste es aprobado "
                "formalmente antes de registrarse."),
        ("H11", "Al cierre de cada período se evalúan los indicios de deterioro por clase de activo y el "
                "resultado de la evaluación se documenta, aun cuando no se reconozca pérdida."),
        ("H12", "Toda baja o venta de activo requiere acta autorizada por el nivel facultado, con retiro "
                "simultáneo del costo y de la depreciación acumulada y determinación del resultado."),
        ("H13", "El acceso al módulo de activos fijos está restringido a los responsables designados, con "
                "usuario individual, y los cambios en datos maestros quedan registrados."),
        ("H14", "Las pólizas de seguro se revisan periódicamente contra el registro de activos para verificar "
                "que la cobertura corresponda a su valor y a los riesgos relevantes."),
        ("H15", "La documentación de titularidad de los activos se custodia de forma centralizada y su "
                "existencia se verifica periódicamente."),
        ("H16", "Los contratos de arrendamiento se analizan al inicio y ante cada modificación para determinar "
                "su clasificación conforme a la Sección 20, y el análisis es revisado por contabilidad."),
        ("H17", "La conciliación entre el módulo de activos fijos y el mayor contable es revisada y aprobada "
                "mensualmente por una persona distinta de quien la elabora."),
    ],
    notas=["ADVERTENCIA DE MARCO NORMATIVO: verifica qué norma cita el papel de activos fijos del ejercicio "
           "anterior y contrástala con el marco confirmado por la administración. Si la entidad aplica NIIF para "
           "las PYMES, la norma es la SECCIÓN 17 (propiedades, planta y equipo), complementada por la Sección 27 "
           "(deterioro del valor de los activos) y la Sección 20 (arrendamientos), y una cita a la NIC 16 es un "
           "error de criterio que invalida el hallazgo; si aplica NIIF completas, la norma es la NIC 16 con NIC 36 "
           "y NIIF 16. Cuando el papel del año anterior cite la norma del otro marco, déjalo como hallazgo y pide "
           "la actualización de la política contable de la entidad.",
           "Cifras al 31 de julio de 2026: propiedad, planta y equipo bruto USD 1.298.614,96 (incluye terrenos "
           "por USD 48.553,34), depreciación acumulada USD 677.322,03 y valor neto USD 621.292,93, equivalente a "
           "2,72 veces la materialidad global. El grado de depreciación acumulada sobre los activos depreciables "
           "es del 54,2%.",
           "El gasto de depreciación de los siete meses asciende a USD 64.578,53, distribuido entre costo de "
           "fabricación (USD 40.288,31), gastos de administración (USD 2.833,32) y gastos de comercialización "
           "(USD 21.456,90). Anualizado equivale a aproximadamente USD 110.706, frente a USD 116.436 registrados "
           "en el ejercicio 2025: la variación es consistente y no presenta indicios de error.",
           "El cuestionario del ejercicio anterior calificó como riesgo ALTO: activos fijos y bienes de control "
           "sin codificación completa; ausencia de revalorización desde 2011; y ausencia de registro de "
           "movimientos de activos fijos. Como riesgo MEDIO: umbral de capitalización de USD 500 con excepción "
           "para equipos de computación; varias vidas útiles para una misma clase de activo; y ausencia del "
           "detalle de la proporción de gasto no deducible. Todas deben verificarse en 2026 y, de persistir, "
           "comunicarse conforme a la NIA 265.",
           "El derecho de uso por concesión (cuenta 1.4.1, USD 198.622,70) no registró movimiento en el período, "
           "mientras su amortización acumulada aumentó de USD 96.852,83 a USD 116.960,44. El pasivo por "
           "arrendamientos (cuenta 2.2.4) disminuyó de USD 32.710,19 a USD 15.848,35. Debe verificarse la "
           "correspondencia entre el activo, el pasivo y el gasto de arrendamiento operativo de la cuenta "
           "6.1.2.10 (USD 612.468,33), que es el rubro individual más significativo del grupo de gastos."],
)

# NIA aplicables a cada narrativa
NIAS_PROC = {
    "C-01":   [230, 240, 265, 315, 330, 402, 500, 501, 505],
    "E-01":   [230, 240, 265, 315, 330, 500, 505, 530, 540, 550],
    "J-01":   [230, 240, 250, 265, 315, 330, 500, 505, 560],
    "F-01":   [230, 240, 265, 315, 330, 500, 501, 540],
    "F-02":   [230, 240, 265, 315, 330, 500, 501, 505],
    "K4-01":  [230, 240, 250, 265, 315, 330, 500, 540, 580],
    "TIC-01": [230, 240, 265, 315, 330, 402, 500],
    "H-01":   [230, 240, 250, 265, 315, 330, 500, 501, 540, 550],
}
for _p in [TESORERIA, VENTAS, COMPRAS, PRODUCCION, BODEGA, NOMINA, TICS, PPE]:
    _p["nias"] = NIAS_PROC[_p["ref"]]

PROCESOS = [TESORERIA, VENTAS, COMPRAS, PRODUCCION, BODEGA, NOMINA, PPE, TICS]
