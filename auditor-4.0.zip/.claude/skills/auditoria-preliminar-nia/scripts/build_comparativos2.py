# -*- coding: utf-8 -*-
"""B-1 Estado de Resultados acumulado y B-2 Estado de Resultados mensual."""
from openpyxl import load_workbook
from openpyxl.styles import Alignment
from openpyxl.utils import get_column_letter
from firma import *

dic, mes = cargar_todo()
wb = load_workbook("wb_comp1.xlsx")

MARCAS_STD = [
    ("√", "Cotejado contra el balance de comprobación del cliente y verificado aritméticamente."),
    ("∑", "Sumado y verificado; el total corresponde a la suma de las cuentas de detalle."),
    ("©", "Cifra tomada directamente del balance de comprobación del período indicado."),
    ("≠", "Diferencia detectada — documentar y escalar como excepción de auditoría."),
    ("P/I", "Pendiente de información del cliente; el procedimiento no pudo ejecutarse."),
]
FUENTES = [
    "Balance de comprobación al 31 de diciembre de 2025 — archivo AUD_2025_BAL_COMP_DIC2025_Final.xls.",
    "Balances de comprobación mensuales de enero a julio de 2026 — archivos "
    "AUD_2026_<MES>_Balance de comprobacion.xls.",
]
GRUPOS_ERI = ("4", "5", "6", "7")


def val(df, cta, col="act"):
    r = df[df.cuenta == cta]
    return float(r.iloc[0][col]) if len(r) else 0.0


def movimiento(df, cta):
    """Movimiento del mes de una cuenta de resultado: débitos menos créditos."""
    r = df[df.cuenta == cta]
    return float(r.iloc[0]["deb"] - r.iloc[0]["cred"]) if len(r) else 0.0


def hijos_directos(items, padre):
    n = padre.rstrip(".").count(".") + 2
    return [c for c, _ in items
            if c.startswith(padre) and c != padre and c.rstrip(".").count(".") + 1 == n]


# anclas verificadas en la hoja A-1 ESF: fila 27 = importes de materialidad,
# fila 218 = resultado del período incorporado en la comprobación del balance.
A1_FILA_MAT = 27
A1_FILA_RESULTADO = 218

cat = catalogo(dic, mes, grupos=GRUPOS_ERI)
hijos_de = {c: hijos_directos(cat, c) for c, _ in cat}

# ==================================================== B-1  ERI ACUMULADO
ws = wb.create_sheet("B-1 ERI Acumulado")
COLS = ["x", "CÓDIGO", "NOMBRE DE LA CUENTA", "Ref.",
        "Ene–Dic 2025 (12 meses)", "Ene–Jul 2025 (7 meses)",
        "ENE 2026", "FEB 2026", "MAR 2026", "ABR 2026", "MAY 2026", "JUN 2026", "JUL 2026",
        "Variación 7m-2026 vs 7m-2025", "Variación %",
        "SELECCIÓN", "SIGNIFICATIVO", "REFERENCIA"]
W = [4, 14, 40, 7, 15, 15, 13, 13, 13, 13, 13, 13, 14, 15, 10, 12, 13, 12]
NC = len(COLS)
anchos(ws, W)

r = encabezado(ws, "B-1", "Estado de Resultados comparativo — saldos acumulados", NC)
r = seccion(ws, r, "Objetivo", [
    "Conciliar el estado de resultados con el balance de comprobación, verificar el cuadre aritmético de cada "
    "cuenta y de cada grupo, analizar la evolución de los saldos acumulados del ejercicio 2026 y seleccionar las "
    "cuentas que serán objeto de revisión de acuerdo con la materialidad calculada.",
    "Aseveraciones cubiertas: ocurrencia, integridad, exactitud, corte, clasificación y presentación.",
], NC)
r = seccion(ws, r, "Procedimiento", [
    "Se transcriben los saldos acumulados de las cuentas de los grupos 4. INGRESOS, 5. COSTO DE VENTAS Y "
    "PRODUCCIÓN, 6. GASTOS y 7. NO OPERACIONALES, hasta el cuarto nivel del catálogo (columnas en azul).",
    "La columna Ene–Dic 2025 corresponde al saldo actual del balance de comprobación de diciembre de 2025, es "
    "decir el acumulado de doce meses del ejercicio anterior; las columnas de 2026 corresponden al saldo actual "
    "acumulado de cada balance mensual.",
    "Los subtotales y totales son fórmulas que suman las cuentas de detalle.",
    "Se seleccionan las cuentas a ser revisadas comparando su saldo acumulado al 31 de julio de 2026 contra la "
    "materialidad y el error tolerable determinados en el papel A-1.",
], NC)
r = bloque_normativa(ws, r, NC, [230, 300, 315, 320, 500, 510, 520],
    marco_niif="Estado de resultados conforme a la Sección 5 de la NIIF para las PYMES.",
    otras=[("Fuente", "Balance de comprobación al 31-dic-2025 y balances mensuales de enero a julio de 2026.")])

r = seccion(ws, r, "Análisis", [], NC)

r = nota_alerta(ws, r, NC,
    "ADVERTENCIA DE COMPARABILIDAD — La columna Ene–Dic 2025 comprende doce meses y las columnas de 2026 "
    "comprenden de uno a siete meses. Ambas magnitudes NO son directamente comparables y la variación no debe "
    "interpretarse como una caída o un aumento del resultado. Para el análisis de variaciones exigido por la "
    "NIA 520 se requiere el acumulado de enero a julio de 2025, que está PENDIENTE DE INFORMACIÓN DEL CLIENTE: "
    "al ingresarlo en la columna amarilla, la variación y su porcentaje se calculan automáticamente.")

f_cab = r
r = cabecera(ws, r, COLS)
f_ini = r

filas = {}
MESCOL = {m: 7 + i for i, m in enumerate(MESES)}   # G..M
for cta, _ in cat:
    filas[cta] = r
    r += 1

r = f_ini
for cta, nombre in cat:
    h = hijos_de[cta]
    grupo = bool(h)
    lvl = cta.rstrip(".").count(".") + 1
    ws.cell(r, 2, cta).font = F(8, grupo, NEGRO if grupo else AZUL)
    c = ws.cell(r, 3, ("   " * (lvl - 1)) + nombre)
    c.font = F(9 if lvl == 1 else 8, grupo)
    d = ws.cell(r, 4, ""); d.fill = FILL_AMARILLO; d.border = BOX
    if grupo:
        rng = ",".join(f"E{filas[x]}" for x in h)
        c = ws.cell(r, 5, f"=SUM({rng})"); c.font = F(8, True)
        rng6 = ",".join(f"F{filas[x]}" for x in h)
        c6 = ws.cell(r, 6, f"=SUM({rng6})"); c6.font = F(8, True)
    else:
        c = ws.cell(r, 5, val(dic, cta)); c.font = F(8, color=AZUL)
        c6 = ws.cell(r, 6, None); c6.fill = FILL_AMARILLO; c6.font = F(8, color=AZUL)
    c.number_format = FMT_USD; c6.number_format = FMT_USD
    for m in MESES:
        col = MESCOL[m]; L = get_column_letter(col)
        if grupo:
            rng = ",".join(f"{L}{filas[x]}" for x in h)
            cc = ws.cell(r, col, f"=SUM({rng})"); cc.font = F(8, True)
        else:
            cc = ws.cell(r, col, val(mes[m], cta)); cc.font = F(8, color=AZUL)
        cc.number_format = FMT_USD
    cc = ws.cell(r, 14, f'=IF(F{r}=0,"",M{r}-F{r})'); cc.font = F(8, grupo)
    cc.number_format = FMT_USD
    cc = ws.cell(r, 15, f'=IF(OR(F{r}=0,N{r}=""),"",N{r}/ABS(F{r}))'); cc.font = F(8, grupo)
    cc.number_format = FMT_PCT
    cc = ws.cell(r, 16, f"=IF(ABS(M{r})>='A-1 ESF'!$G${A1_FILA_MAT},\"SÍ\",\"\")")
    cc.font = F(8, True); cc.alignment = Alignment(horizontal="center")
    cc = ws.cell(r, 17, f"=IF(ABS(M{r})>='A-1 ESF'!$F${A1_FILA_MAT},\"SÍ\",\"\")")
    cc.font = F(8, True, ROJO); cc.alignment = Alignment(horizontal="center")
    ws.cell(r, 18).fill = FILL_AMARILLO
    for k in range(1, NC + 1):
        ws.cell(r, k).border = BOX
        if grupo:
            ws.cell(r, k).fill = FILL_TOT if lvl == 1 else FILL_SUB
    r += 1
f_fin = r - 1

# resultado del periodo
r += 1
f_resultado = r
ws.cell(r, 3, "RESULTADO DEL PERÍODO  (4. + 5. + 6. + 7.)   —   saldo positivo = pérdida").font = F(9, True)
for col in [5, 6] + [MESCOL[m] for m in MESES]:
    L = get_column_letter(col)
    partes = "+".join(f"{L}{filas[g]}" for g in ("4.", "5.", "6.", "7.") if g in filas)
    c = ws.cell(r, col, f"={partes}"); c.font = F(9, True); c.number_format = FMT_USD
for k in range(1, NC + 1):
    ws.cell(r, k).border = BOX; ws.cell(r, k).fill = FILL_TOT
r += 1
ws.cell(r, 3, "Cuadre contra A-1 (resultado del período incorporado en la comprobación del balance)").font = F(8, True, VERDE)
c = ws.cell(r, 13, f"=M{f_resultado}-'A-1 ESF'!L{A1_FILA_RESULTADO}"); c.font = F(8, True, VERDE)
c.number_format = FMT_USD
c = ws.cell(r, 16, f'=IF(ABS(M{r})<0.01,"CUADRA","≠ REVISAR")')
c.font = F(8, True); c.alignment = Alignment(horizontal="center")
for k in range(1, NC + 1):
    ws.cell(r, k).border = BOX; ws.cell(r, k).fill = FILL_SUB
r += 2

r = cierre(ws, r, NC, marcas=MARCAS_STD, referencias=FUENTES)
ws.freeze_panes = ws.cell(f_ini, 5)
print(f"B-1: {len(cat)} cuentas, filas {f_ini}-{f_fin}, resultado fila {f_resultado}")

# ==================================================== B-2  ERI MENSUAL
ws2 = wb.create_sheet("B-2 ERI Mensual")
COLS2 = ["x", "CÓDIGO", "NOMBRE DE LA CUENTA", "Ref.",
         "ENE 2026", "FEB 2026", "MAR 2026", "ABR 2026", "MAY 2026", "JUN 2026", "JUL 2026",
         "TOTAL ene–jul 2026", "Acumulado s/ balance jul-2026", "Diferencia de cuadre",
         "Promedio mensual", "Mes más alto", "OBSERVACIÓN"]
W2 = [4, 14, 40, 7, 13, 13, 13, 13, 13, 13, 13, 15, 16, 14, 13, 12, 34]
NC2 = len(COLS2)
anchos(ws2, W2)

r = encabezado(ws2, "B-2", "Estado de Resultados comparativo — movimientos mensuales", NC2)
r = seccion(ws2, r, "Objetivo", [
    "Analizar el comportamiento mensual de los ingresos, costos y gastos del ejercicio 2026, identificar meses con "
    "movimientos inusuales o atípicos y verificar que la suma de los movimientos mensuales coincida con el saldo "
    "acumulado del balance de comprobación (procedimientos analíticos — NIA 520).",
], NC2)
r = seccion(ws2, r, "Procedimiento", [
    "Para cada cuenta de resultado se toma el movimiento del mes de cada balance de comprobación mensual, "
    "calculado como débitos menos créditos del período (columnas en azul).",
    "La columna TOTAL es una fórmula que suma los siete movimientos mensuales; se compara contra el saldo "
    "acumulado al 31 de julio de 2026 tomado del balance de comprobación de julio, y la diferencia de cuadre debe "
    "ser cero en todas las filas.",
    "El balance de comprobación de enero de 2026 abre en cero en todas las cuentas, por lo que la suma de los "
    "movimientos de enero a julio equivale al acumulado del ejercicio a esa fecha; este hecho fue verificado.",
    "Se identifica el mes de mayor movimiento de cada cuenta para orientar la selección de partidas y los cortes "
    "de auditoría.",
], NC2)
r = seccion(ws2, r, "Análisis", [], NC2)

r = cabecera(ws2, r, COLS2)
g_ini = r
filas2 = {}
M2 = {m: 5 + i for i, m in enumerate(MESES)}   # E..K
for cta, _ in cat:
    filas2[cta] = r
    r += 1

r = g_ini
for cta, nombre in cat:
    hij = hijos_de[cta]
    grupo = bool(hij)
    lvl = cta.rstrip(".").count(".") + 1
    ws2.cell(r, 2, cta).font = F(8, grupo, NEGRO if grupo else AZUL)
    c = ws2.cell(r, 3, ("   " * (lvl - 1)) + nombre)
    c.font = F(9 if lvl == 1 else 8, grupo)
    d = ws2.cell(r, 4, ""); d.fill = FILL_AMARILLO; d.border = BOX
    for m in MESES:
        col = M2[m]; L = get_column_letter(col)
        if grupo:
            rng = ",".join(f"{L}{filas2[x]}" for x in hij)
            cc = ws2.cell(r, col, f"=SUM({rng})"); cc.font = F(8, True)
        else:
            cc = ws2.cell(r, col, movimiento(mes[m], cta)); cc.font = F(8, color=AZUL)
        cc.number_format = FMT_USD
    cc = ws2.cell(r, 12, f"=SUM(E{r}:K{r})"); cc.font = F(8, True); cc.number_format = FMT_USD
    if grupo:
        rng = ",".join(f"M{filas2[x]}" for x in hij)
        cc = ws2.cell(r, 13, f"=SUM({rng})"); cc.font = F(8, True)
    else:
        cc = ws2.cell(r, 13, val(mes["JULIO"], cta)); cc.font = F(8, color=AZUL)
    cc.number_format = FMT_USD
    cc = ws2.cell(r, 14, f"=L{r}-M{r}"); cc.font = F(8, grupo); cc.number_format = FMT_USD
    cc = ws2.cell(r, 15, f"=L{r}/7"); cc.font = F(8, grupo); cc.number_format = FMT_USD
    h = g_ini - 1          # fila de encabezados con los nombres de los meses
    mx = f"MAX(MAX(E{r}:K{r}),-MIN(E{r}:K{r}))"
    cc = ws2.cell(r, 16,
        f'=IF(AND(MAX(E{r}:K{r})=0,MIN(E{r}:K{r})=0),"",'
        f'IFERROR(INDEX($E${h}:$K${h},1,MATCH({mx},E{r}:K{r},0)),'
        f'INDEX($E${h}:$K${h},1,MATCH(-{mx},E{r}:K{r},0))))')
    cc.font = F(8); cc.alignment = Alignment(horizontal="center")
    ws2.cell(r, 17).fill = FILL_AMARILLO
    for k in range(1, NC2 + 1):
        ws2.cell(r, k).border = BOX
        if grupo:
            ws2.cell(r, k).fill = FILL_TOT if lvl == 1 else FILL_SUB
    r += 1
g_fin = r - 1

r += 1
ws2.cell(r, 3, "Suma de diferencias absolutas de cuadre de todas las cuentas (debe ser cero)").font = F(9, True)
c = ws2.cell(r, 14, f"=SUMPRODUCT(ABS(N{g_ini}:N{g_fin}))"); c.font = F(9, True)
c.number_format = FMT_USD
c = ws2.cell(r, 16, f'=IF(ABS(N{r})<0.01,"CUADRA","≠ REVISAR")')
c.font = F(8, True); c.alignment = Alignment(horizontal="center")
for k in range(1, NC2 + 1):
    ws2.cell(r, k).border = BOX; ws2.cell(r, k).fill = FILL_TOT
r += 1
f_res2 = r
ws2.cell(r, 3, "RESULTADO DEL PERÍODO POR MES  (4. + 5. + 6. + 7.)   —   positivo = pérdida del mes").font = F(9, True)
for col in list(M2.values()) + [12, 13]:
    L = get_column_letter(col)
    partes = "+".join(f"{L}{filas2[g]}" for g in ("4.", "5.", "6.", "7.") if g in filas2)
    c = ws2.cell(r, col, f"={partes}"); c.font = F(9, True); c.number_format = FMT_USD
for k in range(1, NC2 + 1):
    ws2.cell(r, k).border = BOX; ws2.cell(r, k).fill = FILL_TOT
r += 2

r = cierre(ws2, r, NC2, marcas=MARCAS_STD, referencias=FUENTES)
ws2.freeze_panes = ws2.cell(g_ini, 5)
print(f"B-2: filas {g_ini}-{g_fin}, resultado mensual fila {f_res2}")

# orden de hojas y presentación
for h in wb.sheetnames:
    w = wb[h]
    w.sheet_view.showGridLines = False
    w.page_setup.orientation = "landscape"
    w.page_setup.paperSize = 9
    w.sheet_properties.pageSetUpPr.fitToPage = True
    w.page_setup.fitToWidth = 1
    w.page_setup.fitToHeight = 0
    w.print_title_rows = "1:7"
    w.oddFooter.left.text = f"{CLIENTE} — {CORTE}"
    w.oddFooter.left.size = 7
    w.oddFooter.right.text = "&P / &N"
    w.oddFooter.right.size = 7

wb.save(f"{PREFIJO}_A-B_Comparativos.xlsx")
print("OK  hojas:", wb.sheetnames)
