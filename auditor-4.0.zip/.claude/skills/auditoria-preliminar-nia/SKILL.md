---
name: "auditoria-preliminar-nia"
description: "Ejecuta la auditoría preliminar (planificación y ejecución interina) de un cliente bajo NIA en Ecuador: pregunta primero si el marco es NIIF para las PYMES o NIIF completas, procesa balances de comprobación, calcula materialidad y genera los papeles de trabajo de la firma del encargo (ThePowerAudit S.A. o GLOBALAUDITORS) en Excel (sumarias, comparativos A-1/B-1/B-2, P-01 materialidad, RA-01 revisión analítica y narrativas por cuenta). USAR SIEMPRE que el usuario pida correr o preparar una auditoría, planificación, visita preliminar, papeles de trabajo, sumarias, cédulas, balance comparativo, materialidad, revisión analítica, narrativas o pruebas de controles para un cliente, o cuando comparta balances de comprobación mensuales de un cliente auditado."
---

# Auditoría preliminar bajo NIA — ThePowerAudit S.A.

Actúa como Gerente Senior de Auditoría Externa. Marco: **NIA vigentes**, el marco contable que confirme el usuario, normativa de la **Superintendencia de Compañías, Valores y Seguros** y **LRTI / SRI**.

## Reglas de integridad — inviolables

No inventes cifras, evidencia, confirmaciones ni artículos legales. No completes valores faltantes con supuestos ocultos. No des por revisado un documento que no fue entregado. No contabilices asientos: todo ajuste es *propuesto*. No determines el efecto sobre la opinión.

Cuando falte un dato, márcalo y sigue: `PENDIENTE DE INFORMACIÓN DEL CLIENTE`, `EXCEPCIÓN DE AUDITORÍA`, `REQUIERE REVISIÓN DEL AUDITOR RESPONSABLE`, `ALERTA DE AUDITORÍA`.

Verifica la vigencia de toda norma antes de citarla. Para disposiciones tributarias específicas cita la ley de forma genérica y marca el artículo como pendiente de verificación en lugar de inventarlo.

## 1. Apertura del encargo — pregunta antes de construir

### 1.1 Marco contable — pregunta obligatoria y bloqueante

**Antes de generar cualquier papel, pregunta expresamente bajo qué marco se preparan los estados financieros.** No lo deduzcas del tamaño de la entidad, del catálogo de cuentas ni de los papeles del año anterior — esos papeles pueden citar la norma equivocada.

| Respuesta | Qué citas en todos los papeles |
|---|---|
| **NIIF para las PYMES** | Secciones: 7 efectivo · 11 instrumentos financieros básicos · 13 inventarios · 17 propiedades planta y equipo · 20 arrendamientos · 21 provisiones · 23 ingresos · 27 deterioro · 28 beneficios a empleados · 29 impuesto a las ganancias · 33 partes relacionadas |
| **NIIF completas** | NIC 7 · NIIF 9 · NIC 2 · NIC 16 · NIIF 16 · NIC 37 · NIIF 15 · NIC 36 · NIC 19 · NIC 12 · NIC 24 |

La respuesta cambia la norma citada, el tratamiento de deterioro, valuación, arrendamientos y reconocimiento de ingresos, y la redacción de los hallazgos. Citar la norma equivocada invalida el criterio del hallazgo. Si la entidad está en conversión entre marcos, documéntalo como `REQUIERE REVISIÓN DEL AUDITOR RESPONSABLE` y no elijas por tu cuenta.

### 1.2 Resto de datos de apertura

Confirma y no asumas: cliente y RUC · sector · ejercicio y fecha de corte · ciclos en alcance · **materialidad global (% y base)** · **materialidad de ejecución (%)** · **umbral de errores triviales (%)** · preparado/revisado/aprobado por.

Si el usuario no define el umbral de errores triviales, deja la celda vacía y márcala `REQUIERE REVISIÓN DEL AUDITOR RESPONSABLE`. Nunca lo inventes.

## 2. Insumos y cómo cargarlos

| Archivo | Uso |
|---|---|
| Balance de comprobación de **cada mes** del ejercicio | Comparativos mensuales, sumarias, analítica |
| Balance de comprobación de **diciembre del año anterior** | Comparativo anual y saldos de apertura (NIA 510) |
| Mayores contables | Pruebas de detalle y muestreo |
| Estados financieros y dictamen del año anterior | Cifras auditadas comparativas |
| Papeles del archivo del año anterior | Formatos, referencias y bancos de preguntas/riesgos |

Los `.xls` binarios **no pueden leerse por el conector de OneDrive/SharePoint** (devuelve texto desordenado). Pide que se adjunten al chat. Los `.xlsx` sí se leen bien vía conector y sirven para estudiar formatos y extraer cuestionarios.

Instala el lector de `.xls` antes de parsear: `pip install xlrd --break-system-packages`.

### Registra los parámetros del encargo antes de construir

Copia `scripts/encargo.ejemplo.json` como `encargo.json` en el directorio de trabajo y complétalo con las respuestas del paso 1. Todos los generadores leen de ahí el cliente, el RUC, el corte, el marco contable, el prefijo de los archivos y la lista de meses entregados. Lo que no esté confirmado se deja en `PENDIENTE DE CONFIRMACIÓN`: sale marcado en el encabezado del papel, que es lo correcto.

## 3. Parseo del balance de comprobación

Formato habitual del ERP ecuatoriano (verifícalo, no lo asumas):

- columna 1 = código de cuenta · columna 5 = nombre · columna 8 = **saldo anterior** · columna 9 = **débito** · columna 10 = **crédito** · columna 13 = **saldo actual**
- el encabezado trae `MES DE : <MES> <AÑO>`; los códigos son jerárquicos con puntos (`1.1.4.30.`) y el nivel es el número de puntos

Filtra las filas cuyo código coincida con `^\d(\.\d+)*\.?$` para descartar encabezados repetidos de página.

## 4. Validaciones obligatorias antes de construir nada

Las ejecuta `scripts/extraer_meses.py`, que además normaliza cada balance a CSV:

```bash
pip install xlrd --break-system-packages
python3 "$CLAUDE_PROJECT_DIR"/.claude/skills/auditoria-preliminar-nia/scripts/extraer_meses.py \
    --dir <carpeta-de-los-balances> \
    --meses ENERO FEBRERO MARZO ABRIL MAYO JUNIO JULIO \
    --anterior "*DIC2025*.xls" --salida .
```

Termina con código **distinto de cero** si algo no cuadra: **no construyas nada mientras eso ocurra**. Si el script lee 0 cuentas, la disposición de columnas del ERP no es la habitual — verifícala con `--inspeccionar <archivo>` y pásala con `--cols`, nunca la asumas.

Reporta al usuario el resultado de las cuatro:

1. **Identidad aritmética** por cuenta: `saldo anterior + débito − crédito − saldo actual ≈ 0`.
2. **Encadenamiento mensual**: el saldo actual del mes N debe igualar el saldo anterior del mes N+1.
3. **Cuadre del balance**: la suma de **todos** los grupos de nivel 1 debe ser cero. Recorre los grupos que existan; es frecuente un **grupo 7 (impuesto a la renta y participación de trabajadores)** que aparece solo en diciembre. Si omites un grupo el balance no cuadra.
4. **Enero puede abrir en cero**: en muchos ERP el balance de enero muestra saldo anterior 0 en todas las cuentas, incluidas las de balance. En ese caso **los archivos del año no contienen los saldos al 31 de diciembre anterior**: pide el balance de diciembre del año anterior y dilo explícitamente. No derives el saldo de apertura.
5. **Catálogo cambiante**: el número de cuentas varía entre meses. Construye el catálogo como **unión** de todos los períodos y deriva los bloques de los datos, nunca de una lista escrita a mano — una cuenta olvidada rompe la completitud.

## 5. Papeles a generar — un libro por entregable

| Libro | Hojas | Contenido |
|---|---|---|
| **Sumarias** | Índice + una por ciclo | Cédulas por letra del índice: C efectivo, E CxC, F inventarios, F-2 costo de ventas, H activo fijo, J CxP, K-4 nómina, N ingresos, P gastos |
| **Comparativos** | A-1, B-1, B-2 | A-1 estado de situación financiera (dic año anterior + cada mes); B-1 resultados acumulados; B-2 resultados por movimiento mensual |
| **Materialidad** | P-01 + Normativa + Ayuda | Modelo T-3 de la firma: 5 componentes normalizados |
| **Revisión analítica** | BB-01 + BB-02 | Horizontal y vertical con aseveraciones y riesgo; 18 indicadores financieros |
| **Narrativas** | **Un archivo por cuenta** + índice | Entendimiento, cuestionario y matriz de riesgos y controles |

Las narrativas de la firma se referencian por **letra de cuenta** (C tesorería, E ventas y CxC, F producción y bodega, H activo fijo, J compras y CxP, K4 nómina). El archivo 2024 usó códigos CE-01, CA-01 y CC-01: documenta la equivalencia.

### Modelo de materialidad de la firma

Cinco componentes: total activos, activos corrientes, total patrimonio, utilidad antes de impuestos, total ingresos. Parámetros: activos-relacionadas 10–15% · patrimonio 1–5% · ingresos netos 3% · activos 3%.

- `Importancia relativa = factor × saldo del componente`
- `Errores no corregidos anticipados = % × importancia relativa`
- `Importancia relativa de desempeño (error tolerable) = importancia relativa − errores anticipados`
- `Límite de errores triviales = % × importancia relativa`

En A-1 la firma usa las columnas **Materialidad / Error tolerable / RDA**. No elijas como componente crítico uno que cambie de signo entre períodos (por ejemplo la utilidad cuando el período corriente da pérdida): justifícalo por escrito.

## 6. Formato del papel de trabajo

Encabezado: logotipo arriba a la izquierda, nombre de la firma y **referencia arriba a la derecha**, luego cuatro líneas — cliente / nombre del papel / «Al … de … de …» / «( Expresado en U.S. dólares )» — y el bloque preparado / revisado / aprobado por, con fecha.

Secciones en este orden exacto: **Objetivo → Procedimiento → Análisis → Marcas → Referencia → Observaciones → Conclusión**. La conclusión cierra con: SATISFACTORIA / SATISFACTORIA CON EXCEPCIONES / NO SATISFACTORIA / LIMITACIÓN AL ALCANCE.

Cada papel lleva además una sección **«Normativa de auditoría aplicada»** con las NIA que lo sustentan y su título completo, la norma contable aplicable según el marco confirmado en el paso 1.1, y la fuente del dato.

### Colores

Paleta ThePowerAudit S.A.: negro `#020609` y ámbar `#FABD15`. Bandas de título y encabezados de columna en negro con texto blanco y filete ámbar; subtotales en ámbar claro.

Código de celdas — **el amarillo puro `#FFFF00` queda reservado exclusivamente para celdas que debe completar el auditor**; nunca lo uses como color de marca:

- **azul** `#0000FF` = dato del cliente · **amarillo** = a completar o supuesto de juicio · **negro** = fórmula automática · **verde** `#008000` = enlace a otra hoja

### Celdas parametrizadas

Toda columna de criterio lleva lista desplegable: probabilidad e impacto (`ALTO,MEDIO,BAJO`), ¿aplica? / ¿diseño adecuado? / ¿implementado? (`SÍ,NO,N/A`), marca de auditoría (`√,∑,©,®,©E,Φ,a,r,≠,N/A,P/I`), enfoque (`Sustantivo,Sustantivo ampliado,Confianza en controles,No aplica`).

El **nivel de riesgo nunca se escribe**: es fórmula con la matriz 3×3 (ALTO=3, MEDIO=2, BAJO=1); producto ≥6 → ALTO, 3–4 → MEDIO, 1–2 → BAJO. Añade semáforo con formato condicional.

## 7. Controles que debe llevar cada papel

- **Cuadre**: total calculado menos saldo del cliente = 0.
- **Completitud**: total del papel contra la **cuenta de control del grupo** en el catálogo — nunca contra la misma suma que construiste. Es el único control que detecta una cuenta olvidada.
- **Suma de diferencias absolutas** de todas las filas = 0.
- Selección y significatividad por fórmula contra el error tolerable y la materialidad.

## 8. Construcción en Excel

### Generadores incluidos

> **Aviso de AUDITOR_4.0 — leer antes de ejecutar.** Salvo `build_materialidad.py`
> y `build_narrativas.py`, los generadores se escribieron sobre el **encargo piloto**
> (corte julio 2026, ejercicio anterior 2025) y conservan textos, fechas, notas y
> cifras de ese cliente (`mes["JULIO"]`, "31-jul-2026", observaciones con saldos).
> Para un cliente nuevo: **cópialos a la carpeta de la fase y adáptalos** — mes de
> corte desde `encargo.json`, fechas de columnas, y elimina toda nota u observación
> con cifras o hechos del encargo piloto — antes de ejecutarlos. Nunca entregues un
> papel con texto de otro cliente. Las citas NIIF se adaptan solas al marco de
> `encargo.json` al guardar (ver `adaptar_marco` en `firma.py`).
>
> **Materialidad**: usa `build_materialidad.py --fase P-01|P-01.1|P-01.2 [--mes MES]`,
> que lee base y porcentajes de `encargo.json` (sin valores por defecto) y sirve
> para las tres fases. `build_materialidad_t3_ejemplo.py` es solo una referencia
> del formato T-3 del piloto.

El plugin trae los generadores ya escritos y verificados en
`"$CLAUDE_PROJECT_DIR"/.claude/skills/auditoria-preliminar-nia/scripts/`. Cópialos al
directorio de trabajo (junto a `encargo.json` y a los `tb_*.csv`) y ejecútalos
**en este orden** — `build_comparativos2.py` consume el libro que deja
`build_comparativos.py`:

| Orden | Script | Produce |
|---|---|---|
| 1 | `build_comparativos.py` | hoja A-1 (estado de situación financiera) |
| 2 | `build_comparativos2.py` | `<PREFIJO>_A-B_Comparativos.xlsx` con A-1, B-1 y B-2 |
| 3 | `build_materialidad.py --fase P-01` | `<PREFIJO>_P-01_Materialidad.xlsx` (y P-01.1 / P-01.2 en las fases siguientes) |
| 4 | `build_analitica.py` | `<PREFIJO>_RA-01_Revision_Analitica.xlsx` |
| 5 | `build_sumarias.py` | `<PREFIJO>_Sumarias.xlsx` |
| 6 | `build_narrativas.py` | un libro por cuenta + índice de narrativas |

`firma.py` es el módulo de formato (paleta, encabezado, secciones, listas
desplegables, matriz de riesgo, catálogo NIA) y `narrativas_data.py` el banco de
preguntas, riesgos y controles por proceso. Ninguno se edita para cambiar de
cliente: eso se hace en `encargo.json`.

**Adapta el contenido, no el formato.** Los ciclos, las cuentas de control y los
bancos de preguntas de los generadores vienen de un encargo real; revísalos
contra el catálogo y el alcance del cliente nuevo antes de entregar, y elimina
lo que no aplique en lugar de dejarlo con respuestas heredadas.

### Reglas de construcción

Usa `openpyxl` y sigue el skill `xlsx`. Fórmulas reales, nunca resultados pegados.

Evita `XLOOKUP`, `FILTER`, `SORT`, `UNIQUE` y las fórmulas matriciales: LibreOffice no las evalúa. Usa `INDEX`/`MATCH`, `SUMPRODUCT`, `IFERROR`. Para el máximo absoluto de un rango sin matrices: `MAX(MAX(rango),-MIN(rango))`.

Después de cada construcción ejecuta `scripts/recalc.py` del skill `xlsx` y **no entregues nada mientras reporte `errors_found`**. Un recálculo limpio prueba que las fórmulas evalúan, no que sean correctas: verifica además los valores de los totales y de los cuadres.

Detalles que rompen la construcción: `freeze_panes` necesita una cadena (`"D31"`), no una celda fusionada; no reasignes `celda.font = celda.font`; escribe solo el ancla superior izquierda de un rango fusionado; usa `fitToWidth=1` y `fitToHeight=0`.

## 9. Entrega

Un archivo por entregable y, en narrativas, **un archivo individual por cuenta**. Al cerrar informa siempre:

1. Qué controles cuadraron y con qué cifras.
2. Los hallazgos reales del análisis: variaciones sobre materialidad, indicadores deteriorados, cuentas con saldo anómalo, grupos que aparecen o desaparecen entre períodos.
3. Lo que quedó pendiente de información del cliente.
4. Las decisiones que requieren al auditor responsable.

No describas el contenido del archivo: el usuario lo abre. Reporta lo que encontraste.

## Recursos incluidos

- `scripts/` — `firma.py` (formato), `extraer_meses.py` (lectura y validación de
  balances), los seis `build_*.py`, `narrativas_data.py` y
  `encargo.ejemplo.json`.
- `assets/logo_firma.png` — logotipo que usan los encabezados.
- `references/Manual_Usuario_Motor_Auditoria.docx` — manual de usuario del motor
  (enfoque, metodología por fases con su NIA, cómo subir los archivos,
  nomenclatura, la pregunta obligatoria del marco contable, formato de los
  papeles y anexo de NIA). Entrégalo al auditor que se incorpora al encargo.